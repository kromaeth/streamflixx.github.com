import React from 'react';
import { Link } from 'wouter';
import { ContentCard, ChannelCard } from './content-card';
import { Media } from '@shared/schema';
import { Users } from 'lucide-react';

interface ContentRowProps {
  title: string;
  contents: Media[];
  viewAllLink?: string;
  onContentClick?: (content: Media) => void;
  onWatchTogetherClick?: (content: Media) => void;
}

export function ContentRow({ title, contents, viewAllLink, onContentClick, onWatchTogetherClick }: ContentRowProps) {
  if (!contents || contents.length === 0) {
    return null;
  }
  
  const renderCard = (content: Media) => {
    if (content.type === 'channel') {
      return (
        <ChannelCard 
          key={content.id} 
          content={content} 
          onClick={onContentClick}
        />
      );
    }
    
    return (
      <ContentCard 
        key={content.id} 
        content={content} 
        onClick={onContentClick}
        onWatchTogetherClick={onWatchTogetherClick}
      />
    );
  };
  
  return (
    <div className="mb-14 relative group">
      <div className="flex justify-between items-center mb-5">
        <h2 className="text-xl font-bold bg-gradient-to-r from-white to-white/70 bg-clip-text text-transparent group-hover:from-white group-hover:to-primary/70 transition-all duration-500">
          {title}
        </h2>
        {viewAllLink && (
          <Link href={viewAllLink} className="text-white/70 hover:text-primary transition text-sm flex items-center">
            Voir plus
            <svg className="ml-1 w-4 h-4 transform group-hover:translate-x-1 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        )}
      </div>
      
      <div className="overflow-x-auto custom-scrollbar pb-4 -mx-4 px-4">
        <div className="flex space-x-5 min-w-max">
          {contents.map(renderCard)}
        </div>
      </div>
      
      {/* Gradient fades on the sides for better scrolling UX */}
      <div className="absolute top-12 bottom-4 left-0 w-8 bg-gradient-to-r from-background to-transparent pointer-events-none"></div>
      <div className="absolute top-12 bottom-4 right-0 w-8 bg-gradient-to-l from-background to-transparent pointer-events-none"></div>
    </div>
  );
}

interface FeaturedContentProps {
  content: Media;
  onWatchClick?: (content: Media) => void;
  onInfoClick?: (content: Media) => void;
  onWatchTogetherClick?: (content: Media) => void;
}

export function FeaturedContent({ content, onWatchClick, onInfoClick, onWatchTogetherClick }: FeaturedContentProps) {
  return (
    <section className="relative w-full h-[80vh] overflow-hidden mt-16">
      {/* Background blurred circles for visual effect */}
      <div className="absolute -top-20 -left-20 w-[40rem] h-[40rem] bg-primary/10 rounded-full filter blur-[120px] opacity-40 z-0"></div>
      <div className="absolute -bottom-32 -right-32 w-[30rem] h-[30rem] bg-purple-700/20 rounded-full filter blur-[100px] opacity-30 z-0"></div>
      
      {/* Custom gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent z-10"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-background/80 z-10"></div>
      
      <img 
        src={content.thumbnailUrl} 
        alt={content.title} 
        className="w-full h-full object-cover scale-105 animate-slow-zoom"
      />
      
      <div className="absolute bottom-0 left-0 p-8 md:p-16 z-20 w-full md:max-w-3xl">
        {/* Genre badge */}
        <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/20 backdrop-blur-md border border-primary/30 text-primary text-xs font-medium mb-4">
          {content.genre}
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
          {content.title}
        </h1>
        
        <p className="text-lg mb-8 text-white/80 max-w-2xl leading-relaxed">
          {content.description}
        </p>
        
        <div className="flex flex-wrap items-center gap-4">
          <button 
            className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white font-medium py-3.5 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-primary/30 flex items-center"
            onClick={() => onWatchClick && onWatchClick(content)}
          >
            <PlayIcon className="h-5 w-5 mr-2" /> 
            Regarder maintenant
          </button>
          
          <button 
            className="bg-black/30 hover:bg-black/50 backdrop-blur-md text-white border border-white/10 font-medium py-3.5 px-8 rounded-full transition-all duration-300 flex items-center"
            onClick={() => onInfoClick && onInfoClick(content)}
          >
            <InfoIcon className="h-5 w-5 mr-2" /> 
            Plus d'infos
          </button>
          
          {content.year && (
            <div className="text-white/70 flex items-center ml-2">
              <span className="mr-3 text-sm font-medium">{content.year}</span>
            </div>
          )}
          
          {content.type === 'series' && content.seasons && (
            <div className="text-white/70 flex items-center">
              <span className="text-sm font-medium">{content.seasons} Saison{content.seasons > 1 ? 's' : ''}</span>
            </div>
          )}
          
          {/* Bouton Regarder ensemble */}
          {onWatchTogetherClick && content.type !== 'channel' && (
            <button 
              className="mt-4 bg-purple-600/40 hover:bg-purple-600/60 backdrop-blur-md text-white border border-purple-500/30 font-medium py-3 px-6 rounded-full transition-all duration-300 flex items-center"
              onClick={() => onWatchTogetherClick(content)}
            >
              <Users className="h-5 w-5 mr-2" /> 
              Regarder ensemble
            </button>
          )}
        </div>
      </div>
    </section>
  );
}

function InfoIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  );
}

function PlayIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      {...props}
    >
      <path d="M8 5.14v14l11-7-11-7z" />
    </svg>
  );
}
