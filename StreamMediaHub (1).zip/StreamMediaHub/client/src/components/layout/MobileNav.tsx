import { Link, useLocation } from "wouter";
import { Home, Tv, Film, Video } from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";

const MobileNav = () => {
  const isMobile = useMobile();
  const [location] = useLocation();
  
  if (!isMobile) return null;
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 z-10">
      <div className="flex justify-around">
        <Link href="/">
          <a className={`py-3 flex flex-col items-center w-full ${location === '/' ? 'text-primary' : 'text-gray-400 hover:text-white'}`}>
            <Home className="text-lg h-5 w-5" />
            <span className="text-xs mt-1">Accueil</span>
          </a>
        </Link>
        
        <Link href="/tv">
          <a className={`py-3 flex flex-col items-center w-full ${location === '/tv' ? 'text-primary' : 'text-gray-400 hover:text-white'}`}>
            <Tv className="text-lg h-5 w-5" />
            <span className="text-xs mt-1">TV</span>
          </a>
        </Link>
        
        <Link href="/movies">
          <a className={`py-3 flex flex-col items-center w-full ${location === '/movies' ? 'text-primary' : 'text-gray-400 hover:text-white'}`}>
            <Film className="text-lg h-5 w-5" />
            <span className="text-xs mt-1">Films</span>
          </a>
        </Link>
        
        <Link href="/series">
          <a className={`py-3 flex flex-col items-center w-full ${location === '/series' ? 'text-primary' : 'text-gray-400 hover:text-white'}`}>
            <Video className="text-lg h-5 w-5" />
            <span className="text-xs mt-1">Séries</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default MobileNav;
