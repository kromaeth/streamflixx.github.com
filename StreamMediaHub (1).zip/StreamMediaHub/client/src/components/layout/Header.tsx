import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Bell, User, Settings, LogOut, ShieldCheck } from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";

const Header = () => {
  const { user, logoutMutation, isAdmin } = useAuth();
  const [location, navigate] = useLocation();
  const isMobile = useMobile();
  const [showSearchInput, setShowSearchInput] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (!user) return null;

  return (
    <header className="bg-gray-900 shadow-lg border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <a className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  StreamFlex
                </a>
              </Link>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {isMobile ? (
              showSearchInput ? (
                <div className="relative">
                  <Input 
                    type="text"
                    placeholder="Rechercher..."
                    className="w-full bg-gray-800 border-gray-700 rounded-full text-sm text-white"
                    autoFocus
                    onBlur={() => setShowSearchInput(false)}
                  />
                </div>
              ) : (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="p-2 rounded-full hover:bg-gray-800 text-gray-300"
                  onClick={() => setShowSearchInput(true)}
                >
                  <Search className="h-5 w-5" />
                </Button>
              )
            ) : (
              <div className="relative">
                <Input 
                  type="text"
                  placeholder="Rechercher..."
                  className="w-64 bg-gray-800 border-gray-700 rounded-full py-2 px-4 text-sm text-white"
                />
                <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>
            )}
            
            <Button variant="ghost" size="icon" className="p-2 rounded-full hover:bg-gray-800 text-gray-300">
              <Bell className="h-5 w-5" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="relative flex items-center rounded-full focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <img 
                    src={user.profileImage || `https://ui-avatars.com/api/?name=${user.username}&background=random`}
                    alt="Profile" 
                    className="h-8 w-8 rounded-full object-cover" 
                  />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center justify-start p-2">
                  <div className="ml-2">
                    <p className="text-sm font-medium text-gray-200">{user.fullName || user.username}</p>
                    <p className="text-xs text-gray-400 truncate">{user.email}</p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("/profile")}>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profil</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/settings")}>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Paramètres</span>
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem onClick={() => navigate("/admin")}>
                    <ShieldCheck className="mr-2 h-4 w-4" />
                    <span>Administration</span>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Déconnexion</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
