import { Link } from "wouter";
import { Facebook, Twitter, Instagram } from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";

const Footer = () => {
  const isMobile = useMobile();
  
  if (isMobile) return null;
  
  return (
    <footer className="bg-gray-900 py-6 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <span className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              StreamFlex
            </span>
            <p className="text-sm text-gray-400 mt-1">© {new Date().getFullYear()} StreamFlex. Tous droits réservés.</p>
          </div>
          
          <div className="flex space-x-8">
            <Link href="/about">
              <a className="text-gray-400 hover:text-white text-sm">À propos</a>
            </Link>
            <Link href="/help">
              <a className="text-gray-400 hover:text-white text-sm">Aide</a>
            </Link>
            <Link href="/privacy">
              <a className="text-gray-400 hover:text-white text-sm">Confidentialité</a>
            </Link>
            <Link href="/terms">
              <a className="text-gray-400 hover:text-white text-sm">Conditions d'utilisation</a>
            </Link>
          </div>
          
          <div className="mt-4 md:mt-0 flex space-x-4">
            <a href="#" className="text-gray-400 hover:text-white">
              <Facebook className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Twitter className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Instagram className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
