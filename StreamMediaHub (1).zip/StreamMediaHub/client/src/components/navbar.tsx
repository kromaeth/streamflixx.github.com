import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from './ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from './ui/dropdown-menu';
import { Logo } from './ui/icons';
import { useAuth } from '@/hooks/use-auth';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';
import { Search, Menu, User, LogOut, Settings, Home, Film, Tv, ListVideo, CreditCard } from 'lucide-react';

export function Navbar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  
  // Detect scroll for glass effect
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20;
      setScrolled(isScrolled);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const isActive = (path: string) => location === path;
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-black/75 backdrop-blur-md shadow-lg py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <div className="text-white flex items-center group cursor-pointer">
            <Link href="/" className="flex items-center">
              <Logo className={`h-8 w-auto transition-all duration-300 ${scrolled ? 'text-primary' : 'text-white group-hover:text-primary'}`} />
              <span className={`ml-2 font-bold text-lg transition-colors duration-300 ${scrolled ? 'opacity-100' : 'opacity-0 md:opacity-100'}`}>
                StreamFlix
              </span>
            </Link>
          </div>
        </div>

        {/* Main Nav for Desktop */}
        <div className="hidden md:flex items-center">
          <nav className="flex rounded-full bg-black/30 backdrop-blur-sm p-1 mx-auto">
            <Link href="/" className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                isActive('/') 
                  ? 'bg-primary text-white' 
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}>
                <Home className="h-4 w-4 mr-2" />
                Accueil
            </Link>
            <Link href="/tv" className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                isActive('/tv') 
                  ? 'bg-primary text-white' 
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}>
                <Tv className="h-4 w-4 mr-2" />
                Télévision
            </Link>
            <Link href="/movies" className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                isActive('/movies') 
                  ? 'bg-primary text-white' 
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}>
                <Film className="h-4 w-4 mr-2" />
                Films
            </Link>
            <Link href="/series" className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                isActive('/series') 
                  ? 'bg-primary text-white' 
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}>
                <ListVideo className="h-4 w-4 mr-2" />
                Séries
            </Link>
          </nav>
        </div>

        {/* User Controls */}
        <div className="flex items-center space-x-3">
          <Link href="/search">
            <Button 
              variant="ghost" 
              size="icon" 
              className={`text-white hover:bg-white/10 rounded-full ${isActive('/search') ? 'bg-primary/20 text-primary' : ''}`}
            >
              <Search className="h-5 w-5" />
            </Button>
          </Link>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className={`relative rounded-full h-9 w-9 p-0 overflow-hidden flex items-center justify-center hover:bg-white/10 border ${
                  user?.isAdmin ? 'border-primary/50' : 'border-white/20'
                }`}
              >
                <span className="sr-only">Mon compte</span>
                <div className="flex items-center justify-center text-white h-full w-full">
                  <User className="h-5 w-5" />
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-black/90 backdrop-blur-xl border-white/10">
              <div className="px-3 py-2 border-b border-white/10">
                <p className="text-sm font-medium text-white">{user?.username}</p>
                <p className="text-xs text-white/60">{user?.email}</p>
              </div>
              
              {user?.isAdmin && (
                <>
                  <Link href="/admin">
                    <DropdownMenuItem className="cursor-pointer text-primary hover:text-primary hover:bg-primary/10">
                      Panel Administrateur
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuSeparator className="bg-white/10" />
                </>
              )}
              <DropdownMenuItem className="cursor-pointer hover:bg-white/10">
                <User className="mr-2 h-4 w-4" />
                <span>Mon Profil</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer hover:bg-white/10">
                <Settings className="mr-2 h-4 w-4" />
                <span>Paramètres</span>
              </DropdownMenuItem>
              <Link href="/subscription">
                <DropdownMenuItem className="cursor-pointer hover:bg-white/10">
                  <CreditCard className="mr-2 h-4 w-4" />
                  <span>Mon Abonnement</span>
                </DropdownMenuItem>
              </Link>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem 
                onClick={handleLogout} 
                className="cursor-pointer text-red-400 hover:text-red-400 hover:bg-red-500/10"
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Se déconnecter</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* Mobile Menu Button */}
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-white hover:bg-white/10 rounded-full">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] p-0 bg-black/95 border-l border-white/10 backdrop-blur-xl">
              <div className="py-6 px-4">
                <div className="mb-8">
                  <Logo className="h-8 w-auto text-primary mx-auto mb-2" />
                  <p className="text-center text-sm text-white/60 mt-2">
                    {user ? `Connecté en tant que ${user.username}` : 'Non connecté'}
                  </p>
                </div>
                
                <div className="space-y-1 mb-6">
                  <div className="text-xs font-semibold text-white/40 uppercase tracking-wider px-3 mb-2">
                    Navigation
                  </div>
                  <Link 
                    href="/"
                    className={`flex items-center rounded-lg text-sm transition-all duration-200 py-2.5 px-3 ${
                      isActive('/') 
                        ? 'bg-primary/20 text-primary' 
                        : 'text-white hover:text-white hover:bg-white/10'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Home className="h-4 w-4 mr-3" />
                    Accueil
                  </Link>
                  <Link 
                    href="/tv"
                    className={`flex items-center rounded-lg text-sm transition-all duration-200 py-2.5 px-3 ${
                      isActive('/tv') 
                        ? 'bg-primary/20 text-primary' 
                        : 'text-white hover:text-white hover:bg-white/10'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Tv className="h-4 w-4 mr-3" />
                    Télévision
                  </Link>
                  <Link 
                    href="/movies"
                    className={`flex items-center rounded-lg text-sm transition-all duration-200 py-2.5 px-3 ${
                      isActive('/movies') 
                        ? 'bg-primary/20 text-primary' 
                        : 'text-white hover:text-white hover:bg-white/10'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Film className="h-4 w-4 mr-3" />
                    Films
                  </Link>
                  <Link 
                    href="/series"
                    className={`flex items-center rounded-lg text-sm transition-all duration-200 py-2.5 px-3 ${
                      isActive('/series') 
                        ? 'bg-primary/20 text-primary' 
                        : 'text-white hover:text-white hover:bg-white/10'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <ListVideo className="h-4 w-4 mr-3" />
                    Séries
                  </Link>
                  <Link 
                    href="/search"
                    className={`flex items-center rounded-lg text-sm transition-all duration-200 py-2.5 px-3 ${
                      isActive('/search') 
                        ? 'bg-primary/20 text-primary' 
                        : 'text-white hover:text-white hover:bg-white/10'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Search className="h-4 w-4 mr-3" />
                    Rechercher
                  </Link>
                  
                  <Link 
                    href="/subscription"
                    className={`flex items-center rounded-lg text-sm transition-all duration-200 py-2.5 px-3 ${
                      isActive('/subscription') 
                        ? 'bg-primary/20 text-primary' 
                        : 'text-white hover:text-white hover:bg-white/10'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <CreditCard className="h-4 w-4 mr-3" />
                    Mon Abonnement
                  </Link>
                </div>
                
                {user?.isAdmin && (
                  <div className="mb-6">
                    <div className="text-xs font-semibold text-white/40 uppercase tracking-wider px-3 mb-2">
                      Administration
                    </div>
                    <Link 
                      href="/admin"
                      className={`flex items-center rounded-lg text-sm transition-all duration-200 py-2.5 px-3 ${
                        isActive('/admin') 
                          ? 'bg-primary/20 text-primary' 
                          : 'text-white hover:text-white hover:bg-white/10'
                      }`}
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Settings className="h-4 w-4 mr-3" />
                      Dashboard
                    </Link>
                  </div>
                )}
                
                <div className="pt-4 mt-6 border-t border-white/10">
                  <Button
                    variant="outline"
                    className="w-full bg-transparent border-white/20 text-white hover:bg-white/10 hover:text-white"
                    onClick={() => {
                      handleLogout();
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Se déconnecter
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
