import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Media } from "@shared/schema";
import { useWatchTogether } from "@/hooks/use-watch-together";
import { useToast } from "@/hooks/use-toast";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";

// Schéma de validation du formulaire
const invitationSchema = z.object({
  handle: z.string().min(1, "Le nom d'utilisateur est requis"),
  message: z.string().optional(),
});

type InvitationFormValues = z.infer<typeof invitationSchema>;

interface InvitationModalProps {
  isOpen: boolean;
  onClose: () => void;
  content: Media | null;
}

export default function InvitationModal({ isOpen, onClose, content }: InvitationModalProps) {
  const { toast } = useToast();
  const { searchUserByHandle, sendInvitation } = useWatchTogether();
  const [foundUser, setFoundUser] = useState<any | null>(null);
  const [searchPerformed, setSearchPerformed] = useState(false);

  // Initialiser le formulaire
  const form = useForm<InvitationFormValues>({
    resolver: zodResolver(invitationSchema),
    defaultValues: {
      handle: "",
      message: content ? `J'aimerais regarder "${content.title}" avec toi. Rejoins-moi !` : "",
    },
  });

  const isSearching = searchUserByHandle.isPending;
  const isSending = sendInvitation.isPending;

  // Recherche d'utilisateur
  const handleSearch = async (handle: string) => {
    setFoundUser(null);
    setSearchPerformed(true);
    
    try {
      const user = await searchUserByHandle.mutateAsync(handle);
      setFoundUser(user);
    } catch (error) {
      // L'erreur est déjà gérée par le hook
    }
  };

  // Soumission du formulaire
  const onSubmit = async (values: InvitationFormValues) => {
    if (!foundUser) {
      // Rechercher l'utilisateur s'il n'a pas encore été trouvé
      await handleSearch(values.handle);
      return;
    }

    if (!content) {
      toast({
        title: "Erreur",
        description: "Aucun contenu sélectionné pour l'invitation",
        variant: "destructive",
      });
      return;
    }

    // Envoyer l'invitation
    await sendInvitation.mutateAsync({
      receiverId: foundUser.id,
      mediaId: content.id,
      message: values.message,
    });

    // Fermer la modale après l'envoi
    onClose();
    form.reset();
    setFoundUser(null);
    setSearchPerformed(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-600 bg-clip-text text-transparent">
            Inviter à regarder ensemble
          </DialogTitle>
          <DialogDescription>
            {content ? (
              <div className="flex items-center mt-2">
                <div className="w-16 h-16 overflow-hidden rounded-md mr-3">
                  <img
                    src={content.thumbnailUrl}
                    alt={content.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-semibold text-foreground">{content.title}</p>
                  <p className="text-sm text-muted-foreground capitalize">{content.type}</p>
                </div>
              </div>
            ) : (
              "Invitez un ami à regarder ce contenu avec vous."
            )}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="handle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nom d'utilisateur (@handle)</FormLabel>
                  <div className="flex space-x-2">
                    <FormControl>
                      <Input
                        placeholder="@username"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          // Réinitialiser les résultats de recherche lorsque l'entrée change
                          if (searchPerformed) {
                            setFoundUser(null);
                            setSearchPerformed(false);
                          }
                        }}
                      />
                    </FormControl>
                    <Button
                      type="button"
                      variant={foundUser ? "outline" : "default"}
                      onClick={() => handleSearch(form.getValues().handle)}
                      disabled={isSearching || !form.getValues().handle}
                    >
                      {isSearching ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : foundUser ? (
                        "Trouvé ✓"
                      ) : (
                        "Rechercher"
                      )}
                    </Button>
                  </div>
                  <FormMessage />
                  {searchPerformed && !foundUser && !isSearching && (
                    <p className="text-sm text-red-500 mt-1">
                      Utilisateur non trouvé. Vérifiez l'orthographe.
                    </p>
                  )}
                  {foundUser && (
                    <p className="text-sm text-green-500 mt-1">
                      Utilisateur trouvé: {foundUser.username}
                    </p>
                  )}
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message personnel (optionnel)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Écrivez un message personnalisé ici..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isSending}
              >
                Annuler
              </Button>
              <Button type="submit" disabled={isSending}>
                {isSending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Envoi en cours...
                  </>
                ) : foundUser ? (
                  "Envoyer l'invitation"
                ) : (
                  "Rechercher"
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}