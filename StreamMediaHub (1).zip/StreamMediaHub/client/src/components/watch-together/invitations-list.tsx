import React from "react";
import { useWatchTogether, WatchInvitation } from "@/hooks/use-watch-together";
import { formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Check, X, Clock } from "lucide-react";

interface InvitationsListProps {
  type: "received" | "sent";
}

export default function InvitationsList({ type }: InvitationsListProps) {
  const { 
    receivedInvitations, 
    sentInvitations, 
    isLoadingInvitations,
    respondToInvitation
  } = useWatchTogether();

  const invitations = type === "received" ? receivedInvitations : sentInvitations;
  
  if (isLoadingInvitations) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (invitations.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>
          {type === "received"
            ? "Vous n'avez reçu aucune invitation pour le moment."
            : "Vous n'avez envoyé aucune invitation pour le moment."}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {invitations.map((invitation) => (
        <InvitationCard 
          key={invitation.id} 
          invitation={invitation} 
          type={type}
          onAccept={() => respondToInvitation.mutate({ invitationId: invitation.id, status: 'accepted' })}
          onDecline={() => respondToInvitation.mutate({ invitationId: invitation.id, status: 'declined' })}
          isRespondingToInvitation={respondToInvitation.isPending}
        />
      ))}
    </div>
  );
}

interface InvitationCardProps {
  invitation: WatchInvitation;
  type: "received" | "sent";
  onAccept?: () => void;
  onDecline?: () => void;
  isRespondingToInvitation?: boolean;
}

function InvitationCard({ 
  invitation, 
  type, 
  onAccept, 
  onDecline,
  isRespondingToInvitation
}: InvitationCardProps) {
  const isExpired = new Date(invitation.expiresAt) < new Date();
  const isPending = invitation.status === "pending";
  
  // Déterminer la couleur du badge de statut
  const getBadgeVariant = () => {
    if (isExpired) return "destructive";
    switch (invitation.status) {
      case "pending": return "outline";
      case "accepted": return "success";
      case "declined": return "destructive";
      case "expired": return "destructive";
      default: return "secondary";
    }
  };

  // Déterminer le texte du badge de statut
  const getStatusText = () => {
    if (isExpired) return "Expirée";
    switch (invitation.status) {
      case "pending": return "En attente";
      case "accepted": return "Acceptée";
      case "declined": return "Refusée";
      case "expired": return "Expirée";
      default: return invitation.status;
    }
  };

  // Pour obtenir l'autre personne impliquée dans l'invitation
  const otherPerson = type === "received" ? invitation.sender : invitation.receiver;

  return (
    <div className="border rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="p-4 flex flex-wrap md:flex-nowrap gap-4">
        {/* Miniature du média */}
        <div className="w-full md:w-1/5 flex-shrink-0">
          {invitation.media?.thumbnailUrl ? (
            <img
              src={invitation.media.thumbnailUrl}
              alt={invitation.media?.title || "Média"}
              className="w-full h-24 object-cover rounded-md"
            />
          ) : (
            <div className="w-full h-24 bg-muted rounded-md flex items-center justify-center">
              <span className="text-muted-foreground">Aucune image</span>
            </div>
          )}
        </div>

        {/* Informations de l'invitation */}
        <div className="flex-grow space-y-2">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold">
                {invitation.media?.title || "Contenu sans titre"}
              </h3>
              <p className="text-sm text-muted-foreground">
                {type === "received" ? "De" : "À"}: <span className="font-medium">{otherPerson?.username || "Utilisateur inconnu"}</span>
                {otherPerson?.handle && <span className="ml-1 text-muted-foreground">@{otherPerson.handle}</span>}
              </p>
            </div>
            <Badge variant={getBadgeVariant() as any}>
              {getStatusText()}
            </Badge>
          </div>

          {/* Message et métadonnées */}
          <p className="text-sm border-l-2 border-primary/20 pl-2 py-1 italic">
            {invitation.message || "Aucun message"}
          </p>
          
          <div className="flex justify-between items-center">
            <p className="text-xs text-muted-foreground">
              {type === "received" ? "Reçue" : "Envoyée"} le {formatDate(new Date(invitation.createdAt))}
            </p>
            
            {/* Actions pour les invitations reçues et en attente */}
            {type === "received" && isPending && !isExpired && (
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onDecline}
                  disabled={isRespondingToInvitation}
                  className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                >
                  <X className="h-4 w-4 mr-1" />
                  Refuser
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={onAccept}
                  disabled={isRespondingToInvitation}
                  className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white"
                >
                  {isRespondingToInvitation ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-1" />
                  ) : (
                    <Check className="h-4 w-4 mr-1" />
                  )}
                  Accepter
                </Button>
              </div>
            )}
            
            {/* Informations d'expiration */}
            {isPending && !isExpired && (
              <p className="text-xs flex items-center text-amber-600">
                <Clock className="h-3 w-3 mr-1" />
                Expire le {formatDate(new Date(invitation.expiresAt))}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}