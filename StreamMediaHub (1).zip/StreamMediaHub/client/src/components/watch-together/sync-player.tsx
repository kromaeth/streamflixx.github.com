import React, { useEffect, useRef, useState } from "react";
import { useWatchTogether } from "@/hooks/use-watch-together";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  PlayCircle,
  PauseCircle,
  Send,
  Users,
  User,
  Clock,
  MessageSquare,
} from "lucide-react";

const formatTime = (seconds: number) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  return [
    hours > 0 ? String(hours).padStart(2, '0') : null,
    String(minutes).padStart(2, '0'),
    String(secs).padStart(2, '0')
  ].filter(Boolean).join(':');
};

export default function SyncPlayer() {
  const {
    currentSession,
    participants,
    chatMessages,
    isConnectedToSession,
    playMedia,
    pauseMedia,
    seekMedia,
    sendChatMessage,
    leaveSession,
    isPlaying,
    currentTime,
  } = useWatchTogether();
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const [chatInput, setChatInput] = useState("");
  const [localTime, setLocalTime] = useState(0);
  const [isSeeking, setIsSeeking] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [showParticipants, setShowParticipants] = useState(false);
  
  // Scroll automatiquement vers le bas du chat quand il y a de nouveaux messages
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);
  
  // Synchroniser le lecteur vidéo avec l'état partagé
  useEffect(() => {
    if (!videoRef.current || isSeeking) return;
    
    // Mettre à jour le temps
    if (Math.abs(videoRef.current.currentTime - currentTime) > 1) {
      videoRef.current.currentTime = currentTime;
    }
    
    // Mettre à jour l'état de lecture/pause
    if (isPlaying && videoRef.current.paused) {
      videoRef.current.play().catch(err => console.error('Erreur lors de la lecture:', err));
    } else if (!isPlaying && !videoRef.current.paused) {
      videoRef.current.pause();
    }
  }, [isPlaying, currentTime, isSeeking]);
  
  // Gestionnaires d'événements pour le lecteur vidéo
  const handleTimeUpdate = () => {
    if (videoRef.current && !isSeeking) {
      setLocalTime(videoRef.current.currentTime);
    }
  };
  
  const handleSeekStart = () => {
    setIsSeeking(true);
  };
  
  const handleSeekEnd = () => {
    if (videoRef.current) {
      seekMedia(videoRef.current.currentTime);
    }
    setIsSeeking(false);
  };
  
  const handlePlayPause = () => {
    if (isPlaying) {
      pauseMedia();
    } else {
      playMedia();
    }
  };
  
  // Gestionnaire pour l'envoi de messages chat
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (chatInput.trim()) {
      sendChatMessage(chatInput);
      setChatInput("");
    }
  };
  
  if (!currentSession || !currentSession.media) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center p-6">
        <p className="text-muted-foreground">Aucune session active</p>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col lg:flex-row gap-4 h-full max-h-[800px]">
      {/* Colonne de gauche: lecteur vidéo et contrôles */}
      <div className="w-full lg:w-3/4 flex flex-col">
        <div className="relative bg-black rounded-md overflow-hidden">
          {!isConnectedToSession && (
            <div className="absolute inset-0 bg-black/80 z-10 flex items-center justify-center">
              <div className="text-center text-white p-4">
                <p className="mb-4">Connexion à la session en cours...</p>
                <div className="w-10 h-10 border-t-2 border-purple-500 border-solid rounded-full animate-spin mx-auto"></div>
              </div>
            </div>
          )}
          
          <video
            ref={videoRef}
            src={currentSession.media.contentUrl}
            className="w-full max-h-[500px] object-contain"
            onTimeUpdate={handleTimeUpdate}
            onSeeking={handleSeekStart}
            onSeeked={handleSeekEnd}
            onClick={handlePlayPause}
            onPlay={() => !isPlaying && playMedia()}
            onPause={() => isPlaying && pauseMedia()}
            controls={false}
          />
        </div>
        
        {/* Contrôles du lecteur */}
        <div className="bg-card rounded-md mt-2 p-4 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={handlePlayPause}
                disabled={!isConnectedToSession}
              >
                {isPlaying ? (
                  <PauseCircle className="h-8 w-8 text-primary" />
                ) : (
                  <PlayCircle className="h-8 w-8 text-primary" />
                )}
              </Button>
              <span className="text-sm font-mono">{formatTime(localTime)}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowParticipants(!showParticipants)}
                className="text-xs"
              >
                <Users className="h-4 w-4 mr-1" />
                {participants.length} 
              </Button>
              
              <Badge variant="outline" className="font-mono text-xs gap-1 flex items-center">
                <Clock className="h-3 w-3" />
                {formatTime(currentSession.currentTime || 0)}
              </Badge>
              
              <Badge 
                variant={isConnectedToSession ? "default" : "outline"}
                className={`${isConnectedToSession ? 'bg-green-500' : 'text-amber-500'}`}
              >
                {isConnectedToSession ? "Connecté" : "Connexion..."}
              </Badge>
            </div>
          </div>
          
          {/* Informations sur le contenu */}
          <div className="mt-4">
            <h3 className="text-lg font-semibold">{currentSession.media.title}</h3>
            <div className="flex items-center text-sm text-muted-foreground mt-1">
              <span className="capitalize">{currentSession.media.type}</span>
            </div>
          </div>
          
          {/* Participants (affichage conditionnel) */}
          {showParticipants && (
            <div className="mt-4 p-2 bg-muted/50 rounded-md">
              <h4 className="text-sm font-medium mb-2 flex items-center">
                <Users className="h-4 w-4 mr-1" />
                Participants
              </h4>
              <div className="space-y-1">
                {participants.map(participant => (
                  <div key={participant.id} className="flex items-center text-sm">
                    <div className={`h-2 w-2 rounded-full mr-2 ${participant.isConnected ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                    <span>{participant.username}</span>
                    {participant.handle && (
                      <span className="text-xs text-muted-foreground ml-1">@{participant.handle}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="mt-4 flex justify-end">
            <Button
              variant="destructive"
              size="sm"
              onClick={leaveSession}
            >
              Quitter la session
            </Button>
          </div>
        </div>
      </div>
      
      {/* Colonne de droite: Chat et participants */}
      <div className="w-full lg:w-1/4 flex flex-col bg-card rounded-md shadow-sm overflow-hidden">
        <div className="p-3 bg-muted/30 border-b">
          <h3 className="text-sm font-medium flex items-center">
            <MessageSquare className="h-4 w-4 mr-1" />
            Chat en direct
          </h3>
        </div>
        
        {/* Messages du chat */}
        <div 
          ref={chatContainerRef}
          className="flex-grow overflow-y-auto p-3 space-y-2"
          style={{ maxHeight: "350px" }}
        >
          {chatMessages.length === 0 ? (
            <p className="text-xs text-center text-muted-foreground py-4">
              Aucun message. Commencez à discuter !
            </p>
          ) : (
            chatMessages.map((msg, index) => (
              <div key={index} className="flex flex-col">
                <div className="flex items-baseline gap-1">
                  <span className="font-medium text-xs">{msg.senderName || `User ${msg.userId}`}</span>
                  <span className="text-[10px] text-muted-foreground">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <p className="text-sm">{msg.message}</p>
              </div>
            ))
          )}
        </div>
        
        {/* Formulaire de saisie de message */}
        <div className="p-3 border-t">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              className="text-sm"
              placeholder="Votre message..."
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              disabled={!isConnectedToSession}
            />
            <Button 
              type="submit" 
              size="icon" 
              disabled={!isConnectedToSession || !chatInput.trim()}
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}