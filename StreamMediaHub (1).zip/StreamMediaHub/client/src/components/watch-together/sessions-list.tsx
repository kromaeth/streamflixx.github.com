import React from "react";
import { useWatchTogether, WatchSession } from "@/hooks/use-watch-together";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Play, Clock } from "lucide-react";
import { formatDate } from "@/lib/utils";

export default function SessionsList() {
  const { activeSessions, isLoadingSessions, joinSession, currentSession } = useWatchTogether();

  if (isLoadingSessions) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (activeSessions.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>Vous n'avez aucune session active pour le moment.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {activeSessions.map((session) => (
        <SessionCard
          key={session.id}
          session={session}
          onJoin={() => joinSession(session.id)}
          isCurrentSession={currentSession?.id === session.id}
        />
      ))}
    </div>
  );
}

interface SessionCardProps {
  session: WatchSession;
  onJoin: () => void;
  isCurrentSession: boolean;
}

function SessionCard({ session, onJoin, isCurrentSession }: SessionCardProps) {
  // Formatage du temps de visionnage actuel
  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return [
      hours > 0 ? String(hours).padStart(2, '0') : null,
      String(minutes).padStart(2, '0'),
      String(secs).padStart(2, '0')
    ].filter(Boolean).join(':');
  };

  // Déterminer le statut de la session
  const getStatusBadge = () => {
    switch (session.status) {
      case "active":
        return <Badge className="bg-green-500">En cours</Badge>;
      case "paused":
        return <Badge variant="outline" className="text-amber-500">En pause</Badge>;
      case "ended":
        return <Badge variant="outline" className="text-red-500">Terminée</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="border rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="p-4 flex flex-wrap md:flex-nowrap gap-4">
        {/* Miniature du média */}
        <div className="w-full md:w-1/5 flex-shrink-0">
          {session.media?.thumbnailUrl ? (
            <img
              src={session.media.thumbnailUrl}
              alt={session.media?.title || "Média"}
              className="w-full h-24 object-cover rounded-md"
            />
          ) : (
            <div className="w-full h-24 bg-muted rounded-md flex items-center justify-center">
              <span className="text-muted-foreground">Aucune image</span>
            </div>
          )}
        </div>

        {/* Informations de la session */}
        <div className="flex-grow space-y-2">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold">
                {session.media?.title || "Contenu sans titre"}
              </h3>
              <p className="text-sm text-muted-foreground">
                Créée par: <span className="font-medium">{session.creator?.username || "Utilisateur inconnu"}</span>
                {session.creator?.handle && (
                  <span className="ml-1 text-muted-foreground">@{session.creator.handle}</span>
                )}
              </p>
            </div>
            {getStatusBadge()}
          </div>

          {/* Métadonnées et position de lecture */}
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>
              Temps actuel: <span className="font-mono">{formatTime(session.currentTime || 0)}</span>
            </span>
          </div>
          
          <div className="flex justify-between items-center mt-2">
            <p className="text-xs text-muted-foreground">
              Créée le {formatDate(new Date(session.createdAt))}
            </p>
            
            <Button
              onClick={onJoin}
              disabled={isCurrentSession}
              variant={isCurrentSession ? "outline" : "default"}
              size="sm"
              className={isCurrentSession ? "pointer-events-none" : "bg-gradient-to-r from-indigo-500 to-purple-600 text-white"}
            >
              {isCurrentSession ? (
                "Session active"
              ) : (
                <>
                  <Play className="h-4 w-4 mr-1" />
                  Rejoindre
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}