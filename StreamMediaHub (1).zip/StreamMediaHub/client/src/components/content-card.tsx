import React from 'react';
import { Card } from './ui/card';
import { PlayIcon, LiveBadge } from './ui/icons';
import { Button } from './ui/button';
import { Media } from '@shared/schema';
import { MoreVertical, Users } from 'lucide-react';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';

interface ContentCardProps {
  content: Media;
  onClick?: (content: Media) => void;
  onWatchTogetherClick?: (content: Media) => void;
  className?: string;
}

export function ContentCard({ content, onClick, onWatchTogetherClick, className = '' }: ContentCardProps) {
  const isLive = content.type === 'channel';
  
  const handleClick = () => {
    if (onClick) {
      onClick(content);
    }
  };
  
  const handleWatchTogetherClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onWatchTogetherClick) {
      onWatchTogetherClick(content);
    }
  };
  
  return (
    <div className={`w-56 transition-all duration-500 ${className} group`}>
      <div 
        className="relative rounded-xl overflow-hidden h-72 mb-3 shadow-lg shadow-black/20 group-hover:shadow-primary/10 transition-all duration-300" 
        onClick={handleClick}
      >
        {/* Main image */}
        <img 
          src={content.thumbnailUrl} 
          alt={content.title} 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
        />
        
        {/* Gradient overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80"></div>
        
        {/* Live badge if applicable */}
        {isLive && (
          <div className="absolute top-3 right-3 text-primary">
            <LiveBadge className="w-10 h-5" />
          </div>
        )}
        
        {/* Menu contextuel */}
        {!isLive && onWatchTogetherClick && (
          <div className="absolute top-3 right-3 z-30">
            <DropdownMenu.Root>
              <DropdownMenu.Trigger asChild>
                <button className="rounded-full w-8 h-8 flex items-center justify-center bg-black/40 backdrop-blur-sm border border-white/10 text-white/70 hover:text-white hover:bg-primary/40 hover:border-primary/30 transition-all duration-300">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </DropdownMenu.Trigger>
              
              <DropdownMenu.Portal>
                <DropdownMenu.Content
                  className="min-w-[180px] bg-black/80 backdrop-blur-md border border-white/10 rounded-lg p-1 shadow-lg shadow-black/30 animate-in fade-in-80 data-[side=bottom]:slide-in-from-top-5 z-50"
                  sideOffset={5}
                >
                  <DropdownMenu.Item
                    className="flex items-center py-2 px-3 text-sm text-white hover:bg-primary/20 rounded-md cursor-pointer transition-colors duration-300"
                    onClick={handleWatchTogetherClick}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    Regarder ensemble
                  </DropdownMenu.Item>
                </DropdownMenu.Content>
              </DropdownMenu.Portal>
            </DropdownMenu.Root>
          </div>
        )}
        
        {/* Content info at bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-white group-hover:text-primary transition-colors duration-300 truncate">
                {content.title}
              </h3>
              <p className="text-xs text-white/70">
                {content.year ? `${content.year} • ` : ''}{content.genre}
                {content.type === 'series' && content.seasons && ` • ${content.seasons} ${content.seasons > 1 ? 'Saisons' : 'Saison'}`}
              </p>
            </div>
            
            {/* Play button */}
            <Button 
              className="bg-primary/90 rounded-full w-9 h-9 flex items-center justify-center hover:bg-primary hover:scale-110 transition-all duration-300 shadow-md shadow-black/30"
              onClick={handleClick}
            >
              <PlayIcon className="h-4 w-4 text-white" />
            </Button>
          </div>
        </div>
        
        {/* Hover overlay with glowing effect */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
          <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent opacity-30"></div>
          <div className="absolute -inset-1 rounded-xl bg-gradient-to-tr from-primary/10 via-purple-500/0 to-primary/10 blur-xl opacity-0 group-hover:opacity-40 transform group-hover:scale-105 transition-all duration-500"></div>
        </div>
      </div>
    </div>
  );
}

interface ChannelCardProps {
  content: Media;
  onClick?: (content: Media) => void;
  className?: string;
}

export function ChannelCard({ content, onClick, className = '' }: ChannelCardProps) {
  const handleClick = () => {
    if (onClick) {
      onClick(content);
    }
  };
  
  return (
    <div className={`w-56 transition-all duration-500 ${className} group`}>
      <div 
        className="relative rounded-xl overflow-hidden h-32 mb-3 bg-black/50 backdrop-blur-sm flex items-center justify-center border border-white/5 group-hover:border-primary/20 shadow-lg shadow-black/20 transition-all duration-300"
        onClick={handleClick}
      >
        {/* Channel logo */}
        <div className="relative z-10 transform group-hover:scale-110 transition-all duration-500">
          <img 
            src={content.thumbnailUrl} 
            alt={content.title} 
            className="max-w-[60%] max-h-[60%] object-contain mx-auto"
          />
        </div>
        
        {/* Live badge */}
        <div className="absolute top-3 right-3 z-20">
          <div className="flex items-center space-x-1 bg-primary/20 backdrop-blur-md px-2 py-1 rounded-full border border-primary/30">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            <span className="text-xs font-medium text-primary">LIVE</span>
          </div>
        </div>
        
        {/* Decorative background effects */}
        <div className="absolute inset-0 opacity-50">
          <div className="absolute -inset-1 rounded-xl bg-gradient-to-tr from-primary/5 via-purple-500/0 to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
        </div>
      </div>
      
      <div className="px-1">
        <h3 className="font-medium text-base group-hover:text-primary transition-colors duration-300 truncate">{content.title}</h3>
        <p className="text-xs text-white/60">{content.genre}</p>
      </div>
    </div>
  );
}
