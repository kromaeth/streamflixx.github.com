import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { mediaTypes } from '@shared/schema';

// Schéma pour le formulaire de recherche
const searchSchema = z.object({
  query: z.string().optional(),
  type: z.enum(['all', ...mediaTypes as any]).optional(),
  genre: z.string().optional(),
  year: z.string().optional(),  // On le garde en string dans le formulaire
  sortBy: z.enum(['none', 'title', 'year', 'createdAt']).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
});

type SearchFormValues = z.infer<typeof searchSchema>;

interface AdvancedSearchProps {
  onSearch: (values: SearchFormValues) => void;
  isLoading?: boolean;
}

const genreOptions = [
  { value: 'Action', label: 'Action' },
  { value: 'Thriller', label: 'Thriller' },
  { value: 'Drame', label: 'Drame' },
  { value: 'Comédie', label: 'Comédie' },
  { value: 'Science-Fiction', label: 'Science-Fiction' },
  { value: 'Historique', label: 'Historique' },
  { value: 'Documentaire', label: 'Documentaire' },
  { value: 'Sport', label: 'Sport' },
  { value: 'Actualités', label: 'Actualités' },
  { value: 'Cinéma', label: 'Cinéma' },
];

export function AdvancedSearch({ onSearch, isLoading = false }: AdvancedSearchProps) {
  const form = useForm<SearchFormValues>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      query: '',
      type: 'all',
      genre: 'all',
      year: '',
      sortBy: 'none',
      sortOrder: 'asc',
    },
  });

  const onSubmit = (values: SearchFormValues) => {
    onSearch(values);
  };

  return (
    <div className="p-4 md:p-6 bg-black/20 backdrop-blur-sm rounded-xl border border-primary/20">
      <h2 className="text-xl font-bold mb-6 text-center bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent">
        Recherche Avancée
      </h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Recherche textuelle */}
            <FormField
              control={form.control}
              name="query"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rechercher</FormLabel>
                  <FormControl>
                    <Input placeholder="Titre, description..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Type de média */}
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Tous les types" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="all">Tous les types</SelectItem>
                      <SelectItem value="movie">Films</SelectItem>
                      <SelectItem value="series">Séries</SelectItem>
                      <SelectItem value="channel">Chaînes TV</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Genre */}
            <FormField
              control={form.control}
              name="genre"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Genre</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Tous les genres" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="all">Tous les genres</SelectItem>
                      {genreOptions.map(genre => (
                        <SelectItem key={genre.value} value={genre.value}>
                          {genre.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Année */}
            <FormField
              control={form.control}
              name="year"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Année</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="Ex: 2023" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Tri */}
            <FormField
              control={form.control}
              name="sortBy"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Trier par</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Par défaut" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">Par défaut</SelectItem>
                      <SelectItem value="title">Titre</SelectItem>
                      <SelectItem value="year">Année</SelectItem>
                      <SelectItem value="createdAt">Date d'ajout</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Ordre de tri */}
            <FormField
              control={form.control}
              name="sortOrder"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ordre</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                    disabled={!form.watch('sortBy')}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Croissant" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="asc">Croissant (A-Z, 0-9)</SelectItem>
                      <SelectItem value="desc">Décroissant (Z-A, 9-0)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="mt-6 flex justify-center">
            <Button 
              type="submit" 
              size="lg"
              className="bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <span className="animate-spin mr-2">⏳</span>
                  Recherche en cours...
                </>
              ) : (
                'Rechercher'
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}