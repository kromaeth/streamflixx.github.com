import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertMediaSchema, Media, mediaTypes } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { useMutation } from '@tanstack/react-query';

// Extend the insertMediaSchema with validations
const formSchema = insertMediaSchema.extend({
  title: z.string().min(1, "Le titre est requis"),
  description: z.string().min(10, "Description trop courte (minimum 10 caractères)"),
  thumbnailUrl: z.string().url("URL invalide"),
  contentUrl: z.string().url("URL invalide"),
  year: z.number().int().min(1900).max(new Date().getFullYear() + 5).optional().nullable(),
  seasons: z.number().int().min(1).optional().nullable(),
});

interface ContentFormProps {
  initialData?: Media;
  type?: 'movie' | 'series' | 'channel';
  onSuccess?: () => void;
}

export function ContentForm({ initialData, type, onSuccess }: ContentFormProps) {
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: initialData || {
      title: '',
      description: '',
      type: type || 'movie',
      genre: '',
      year: new Date().getFullYear(),
      thumbnailUrl: '',
      contentUrl: '',
      seasons: type === 'series' ? 1 : undefined,
      featured: false,
    }
  });
  
  const selectedType = form.watch('type');
  
  const mutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const url = initialData 
        ? `/api/media/${initialData.id}` 
        : '/api/media';
      const method = initialData ? 'PATCH' : 'POST';
      
      const res = await apiRequest(method, url, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: initialData ? "Contenu mis à jour" : "Contenu créé",
        description: initialData 
          ? "Le contenu a été mis à jour avec succès." 
          : "Le nouveau contenu a été ajouté avec succès.",
      });
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ['/api/media'] });
      if (selectedType) {
        queryClient.invalidateQueries({ queryKey: [`/api/media/${selectedType}`] });
      }
      
      if (onSuccess) {
        onSuccess();
      }
      
      if (!initialData) {
        form.reset();
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    // If the type is not series, remove the seasons field
    if (data.type !== 'series') {
      data.seasons = undefined;
    }
    
    mutation.mutate(data);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Titre</FormLabel>
                <FormControl>
                  <Input placeholder="Titre du contenu" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {!type && (
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select 
                    value={field.value} 
                    onValueChange={field.onChange}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez un type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {mediaTypes.map(type => (
                        <SelectItem key={type} value={type}>
                          {type === 'movie' && 'Film'}
                          {type === 'series' && 'Série'}
                          {type === 'channel' && 'Chaîne TV'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          <FormField
            control={form.control}
            name="genre"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Genre</FormLabel>
                <FormControl>
                  <Input placeholder="Genre (ex: Action, Comédie, etc.)" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {selectedType !== 'channel' && (
            <FormField
              control={form.control}
              name="year"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Année</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="Année de sortie"
                      {...field}
                      onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : null)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          {selectedType === 'series' && (
            <FormField
              control={form.control}
              name="seasons"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre de saisons</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="Nombre de saisons"
                      {...field}
                      onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : null)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          <FormField
            control={form.control}
            name="thumbnailUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL de la vignette</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/image.jpg" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="contentUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL du contenu</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/video.mp4" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="featured"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between space-y-0 rounded-md border p-4">
                <div>
                  <FormLabel>Mettre en avant</FormLabel>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Description du contenu" 
                  rows={5}
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Traitement en cours...
            </>
          ) : initialData ? 'Mettre à jour' : 'Ajouter'}
        </Button>
      </form>
    </Form>
  );
}
