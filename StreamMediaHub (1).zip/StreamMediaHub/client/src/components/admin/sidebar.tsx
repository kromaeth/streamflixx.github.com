import React from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Logo } from '@/components/ui/icons';
import {
  LayoutDashboard,
  Film,
  Tv,
  Radio,
  Users,
  Settings,
  LogOut
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export function AdminSidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  
  const routes = [
    {
      path: '/admin',
      label: 'Dashboard',
      icon: LayoutDashboard,
      exact: true
    },
    {
      path: '/admin/movies',
      label: 'Films',
      icon: Film
    },
    {
      path: '/admin/series',
      label: 'Séries',
      icon: Tv
    },
    {
      path: '/admin/channels',
      label: 'Chaînes TV',
      icon: Radio
    },
    {
      path: '/admin/users',
      label: 'Utilisateurs',
      icon: Users
    }
  ];
  
  const isActive = (route: { path: string, exact?: boolean }) => {
    if (route.exact) {
      return route.path === location;
    }
    return location.startsWith(route.path);
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div className={cn("w-64 bg-sidebar h-screen flex flex-col", className)}>
      <div className="p-6">
        <Link href="/">
          <a className="inline-block">
            <Logo className="h-8 w-auto text-sidebar-primary" />
          </a>
        </Link>
        <div className="text-sidebar-foreground/50 mt-1">Admin Panel</div>
      </div>
      
      <ScrollArea className="flex-1 px-4">
        <nav className="space-y-2">
          {routes.map((route) => (
            <Link key={route.path} href={route.path}>
              <a
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                  isActive(route)
                    ? "bg-sidebar-accent text-sidebar-primary"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary"
                )}
              >
                <route.icon className="h-4 w-4" />
                {route.label}
              </a>
            </Link>
          ))}
        </nav>
      </ScrollArea>
      
      <div className="border-t border-sidebar-border p-4 space-y-2">
        <Button
          variant="ghost"
          className="w-full justify-start flex items-center gap-3 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary"
        >
          <Settings className="h-4 w-4" />
          Paramètres
        </Button>
        <Button
          variant="ghost"
          className="w-full justify-start flex items-center gap-3 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary"
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4" />
          Se déconnecter
        </Button>
      </div>
    </div>
  );
}
