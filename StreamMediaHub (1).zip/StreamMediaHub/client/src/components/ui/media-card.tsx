import { cn } from "@/lib/utils";

interface MediaCardProps {
  title: string;
  posterUrl: string;
  year?: number;
  duration?: number;
  seasons?: number;
  rating?: number;
  category?: string;
  progress?: number;
  remainingTime?: string;
  onClick?: () => void;
  className?: string;
  aspectRatio?: "poster" | "thumbnail" | "landscape";
}

export const MediaCard = ({
  title,
  posterUrl,
  year,
  duration,
  seasons,
  rating,
  category,
  progress,
  remainingTime,
  onClick,
  className,
  aspectRatio = "poster"
}: MediaCardProps) => {
  const aspectRatioClass = {
    poster: "h-64",
    thumbnail: "h-40",
    landscape: "h-36"
  }[aspectRatio];
  
  return (
    <div 
      className={cn(
        "relative group cursor-pointer card-zoom", 
        className
      )}
      onClick={onClick}
    >
      <div className="relative">
        <img 
          src={posterUrl} 
          alt={`${title} poster`} 
          className={cn(
            "w-full object-cover rounded-lg transition-all", 
            aspectRatioClass
          )}
        />
        {rating && (
          <div className="absolute top-2 right-2 bg-primary text-white text-xs px-2 py-1 rounded">
            {rating / 10}
          </div>
        )}
        {progress !== undefined && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
            <div 
              className="h-full bg-primary" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        )}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-12 w-12 text-white" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10"></circle>
              <polygon points="10 8 16 12 10 16 10 8"></polygon>
            </svg>
          </div>
        </div>
      </div>
      <div className="mt-2">
        <h3 className="text-sm font-medium text-white truncate">{title}</h3>
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400">
            {year && `${year}`}
            {duration && ` • ${Math.floor(duration / 60)}h${duration % 60 > 0 ? `${duration % 60}m` : ''}`}
            {seasons && ` • ${seasons} saison${seasons > 1 ? 's' : ''}`}
          </span>
          {category && (
            <span className="text-xs text-gray-400">{category}</span>
          )}
        </div>
        {remainingTime && (
          <p className="text-xs text-gray-400">{remainingTime}</p>
        )}
      </div>
    </div>
  );
};
