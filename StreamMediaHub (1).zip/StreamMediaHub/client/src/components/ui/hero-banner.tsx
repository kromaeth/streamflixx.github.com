import { Button } from "@/components/ui/button";
import { PlayCircle, Info } from "lucide-react";

interface HeroBannerProps {
  imageUrl: string;
  title: string;
  description: string;
  year?: string;
  seasons?: string;
  rating?: string;
  badge?: string;
  onPlay?: () => void;
  onInfo?: () => void;
}

export const HeroBanner = ({
  imageUrl,
  title,
  description,
  year,
  seasons,
  rating,
  badge,
  onPlay,
  onInfo
}: HeroBannerProps) => {
  return (
    <div className="relative rounded-xl overflow-hidden mb-8">
      <img 
        src={imageUrl} 
        alt={`${title} banner`} 
        className="w-full h-64 md:h-96 object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
      <div className="absolute bottom-0 left-0 p-6 md:p-10">
        {badge && (
          <span className="inline-block bg-secondary px-2 py-1 text-xs font-medium text-white rounded mb-2">
            {badge}
          </span>
        )}
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{title}</h1>
        <p className="text-sm md:text-base text-gray-200 mb-4 max-w-xl">{description}</p>
        
        {(year || seasons || rating) && (
          <div className="flex space-x-3 mb-2 text-gray-400 text-sm">
            {year && <span>{year}</span>}
            {seasons && <span>{seasons}</span>}
            {rating && <span>{rating}</span>}
          </div>
        )}
        
        <div className="flex space-x-4">
          <Button 
            className="bg-accent hover:bg-accent/90 text-white"
            onClick={onPlay}
          >
            <PlayCircle className="mr-2 h-4 w-4" />
            Regarder
          </Button>
          
          <Button 
            variant="outline"
            className="bg-gray-800 hover:bg-gray-700 text-white" 
            onClick={onInfo}
          >
            <Info className="mr-2 h-4 w-4" />
            Plus d'infos
          </Button>
        </div>
      </div>
    </div>
  );
};
