import { cn } from "@/lib/utils";

export interface CategoryOption {
  id: string;
  label: string;
}

interface CategoryFilterProps {
  categories: CategoryOption[];
  selectedCategory: string;
  onChange: (categoryId: string) => void;
  className?: string;
}

export const CategoryFilter = ({
  categories,
  selectedCategory,
  onChange,
  className
}: CategoryFilterProps) => {
  return (
    <div className={cn("flex overflow-x-auto space-x-4 pb-4 mb-6", className)}>
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onChange(category.id)}
          className={cn(
            "px-4 py-2 rounded-full whitespace-nowrap transition-colors",
            selectedCategory === category.id
              ? "bg-primary text-white"
              : "bg-gray-800 text-gray-300 hover:bg-gray-700"
          )}
        >
          {category.label}
        </button>
      ))}
    </div>
  );
};
