import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { CheckCircle, Home, PlayCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';

export default function SubscriptionSuccessPage() {
  const [_, setLocation] = useLocation();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [subscriptionInfo, setSubscriptionInfo] = useState<any>(null);

  useEffect(() => {
    // Verify the subscription status on page load
    const checkSubscription = async () => {
      try {
        const response = await apiRequest('GET', '/api/subscription/verify');
        const data = await response.json();
        setSubscriptionInfo(data);
        setIsLoading(false);
      } catch (err) {
        console.error('Error verifying subscription:', err);
        setError("Nous n'avons pas pu vérifier votre abonnement. Veuillez vérifier votre compte.");
        setIsLoading(false);
      }
    };

    checkSubscription();
  }, []);

  if (error) {
    return (
      <div className="min-h-screen pt-20 bg-gradient-to-br from-gray-900 via-black to-black">
        <div className="container mx-auto px-4">
          <Card className="max-w-md mx-auto bg-black/80 backdrop-blur-sm border-white/10">
            <CardContent className="pt-6 text-center">
              <div className="flex justify-center mb-4">
                <div className="h-16 w-16 bg-red-500/20 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-8 w-8 text-red-500" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Une erreur est survenue</h1>
              <p className="text-white/60 mb-6">{error}</p>
              <div className="flex flex-col gap-3">
                <Button onClick={() => setLocation('/subscription')}>
                  Vérifier mon abonnement
                </Button>
                <Button 
                  variant="outline" 
                  className="border-white/10"
                  onClick={() => setLocation('/')}
                >
                  <Home className="mr-2 h-4 w-4" />
                  Retour à l'accueil
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen pt-20 bg-gradient-to-br from-gray-900 via-black to-black">
        <div className="container mx-auto px-4">
          <Card className="max-w-md mx-auto bg-black/80 backdrop-blur-sm border-white/10">
            <CardContent className="pt-6 text-center">
              <div className="flex justify-center">
                <div className="h-16 w-16 animate-pulse bg-primary/20 rounded-full"></div>
              </div>
              <h1 className="text-2xl font-bold text-white mb-2 mt-4">Vérification de votre abonnement...</h1>
              <p className="text-white/60">Veuillez patienter pendant que nous traitons votre paiement.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Default success view
  return (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-gray-900 via-black to-black">
      <div className="container mx-auto px-4">
        <Card className="max-w-md mx-auto bg-black/80 backdrop-blur-sm border-white/10">
          <CardContent className="pt-6 text-center">
            <div className="flex justify-center mb-6">
              <div className="h-20 w-20 bg-green-500/20 rounded-full flex items-center justify-center">
                <CheckCircle className="h-10 w-10 text-green-500" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-white mb-3">Abonnement Réussi !</h1>
            <div className="bg-primary/10 rounded-lg p-4 mb-6">
              <p className="text-white text-lg font-medium mb-1">
                Bienvenue sur StreamFlix Premium
              </p>
              <p className="text-white/70">
                Votre période d'essai de 7 jours commence aujourd'hui.
                Profitez dès maintenant de tous nos contenus exclusifs !
              </p>
            </div>
            <p className="text-white/60 mb-8">
              Vous pouvez annuler à tout moment depuis votre espace abonnement.
              Aucun frais ne sera appliqué pendant votre période d'essai.
            </p>
            <div className="space-y-3">
              <Button 
                className="w-full bg-gradient-to-r from-primary to-violet-600 hover:brightness-110"
                onClick={() => setLocation('/')}
              >
                <PlayCircle className="mr-2 h-5 w-5" />
                Commencer à regarder
              </Button>
              <Button 
                variant="outline" 
                className="w-full border-white/10"
                onClick={() => setLocation('/subscription')}
              >
                Gérer mon abonnement
              </Button>
            </div>
          </CardContent>
          <CardFooter className="border-t border-white/10 flex justify-center bg-black/50">
            <p className="text-white/40 text-xs">
              StreamFlix – Votre accès complet est activé
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}