import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Film, Tv, Users, Video, Activity, BarChart2, TrendingUp } from "lucide-react";
import { Movie, Series, TvChannel, User } from "@shared/schema";

const AdminPage = () => {
  const { isAdmin } = useAuth();
  const [, navigate] = useLocation();

  // Redirect non-admin users
  useEffect(() => {
    if (isAdmin === false) {
      navigate("/");
    }
  }, [isAdmin, navigate]);

  // Fetch counts for dashboard
  const { data: movies, isLoading: isLoadingMovies } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const { data: seriesList, isLoading: isLoadingSeries } = useQuery<Series[]>({
    queryKey: ["/api/series"],
  });

  const { data: channels, isLoading: isLoadingChannels } = useQuery<TvChannel[]>({
    queryKey: ["/api/tv-channels"],
  });

  const { data: users, isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  if (isLoadingMovies || isLoadingSeries || isLoadingChannels || isLoadingUsers) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">Panel Administrateur</h1>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Films</p>
                  <h3 className="text-2xl font-bold text-white">{movies?.length || 0}</h3>
                </div>
                <div className="h-12 w-12 bg-primary/20 rounded-full flex items-center justify-center">
                  <Film className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Séries</p>
                  <h3 className="text-2xl font-bold text-white">{seriesList?.length || 0}</h3>
                </div>
                <div className="h-12 w-12 bg-secondary/20 rounded-full flex items-center justify-center">
                  <Video className="h-6 w-6 text-secondary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Chaînes TV</p>
                  <h3 className="text-2xl font-bold text-white">{channels?.length || 0}</h3>
                </div>
                <div className="h-12 w-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <Tv className="h-6 w-6 text-blue-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Utilisateurs</p>
                  <h3 className="text-2xl font-bold text-white">{users?.length || 0}</h3>
                </div>
                <div className="h-12 w-12 bg-purple-500/20 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-purple-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-gray-800 border-gray-700 card-zoom">
            <CardHeader className="pb-0">
              <CardTitle className="flex items-center">
                <Film className="h-5 w-5 mr-2 text-primary" />
                Gestion des Films
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-gray-400 text-sm mb-4">
                Ajoutez, modifiez ou supprimez les films disponibles sur la plateforme.
              </p>
              <div className="flex">
                <Link href="/admin/movies">
                  <Button className="w-full">Gérer les films</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 card-zoom">
            <CardHeader className="pb-0">
              <CardTitle className="flex items-center">
                <Video className="h-5 w-5 mr-2 text-secondary" />
                Gestion des Séries
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-gray-400 text-sm mb-4">
                Gérez les séries et leurs épisodes disponibles sur la plateforme.
              </p>
              <div className="flex">
                <Link href="/admin/series">
                  <Button className="w-full">Gérer les séries</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 card-zoom">
            <CardHeader className="pb-0">
              <CardTitle className="flex items-center">
                <Tv className="h-5 w-5 mr-2 text-blue-500" />
                Gestion des Chaînes TV
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-gray-400 text-sm mb-4">
                Ajoutez et configurez les chaînes de télévision en direct.
              </p>
              <div className="flex">
                <Link href="/admin/tv">
                  <Button className="w-full">Gérer les chaînes</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 card-zoom">
            <CardHeader className="pb-0">
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-purple-500" />
                Gestion des Utilisateurs
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-gray-400 text-sm mb-4">
                Gérez les comptes utilisateurs, leurs permissions et statuts.
              </p>
              <div className="flex">
                <Link href="/admin/users">
                  <Button className="w-full">Gérer les utilisateurs</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 card-zoom">
            <CardHeader className="pb-0">
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2 text-green-500" />
                Statistiques
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-gray-400 text-sm mb-4">
                Consultez les statistiques d'utilisation de la plateforme.
              </p>
              <div className="flex">
                <Button className="w-full" variant="outline">Consulter les statistiques</Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 card-zoom">
            <CardHeader className="pb-0">
              <CardTitle className="flex items-center">
                <BarChart2 className="h-5 w-5 mr-2 text-yellow-500" />
                Rapports
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <p className="text-gray-400 text-sm mb-4">
                Générez des rapports détaillés sur l'utilisation du service.
              </p>
              <div className="flex">
                <Button className="w-full" variant="outline">Générer des rapports</Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="mt-8">
          <h2 className="text-xl font-bold text-white mb-4">Activité récente</h2>
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="space-y-4">
                {[
                  { action: "Nouvel utilisateur inscrit", time: "Il y a 5 minutes", user: "johndoe" },
                  { action: "Film ajouté", time: "Il y a 2 heures", user: "admin" },
                  { action: "Chaîne TV mise à jour", time: "Il y a 1 jour", user: "admin" }
                ].map((activity, index) => (
                  <div key={index} className="flex items-center justify-between border-b border-gray-700 pb-3">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                        <TrendingUp className="h-4 w-4 text-gray-400" />
                      </div>
                      <div>
                        <p className="text-white text-sm">{activity.action}</p>
                        <p className="text-gray-400 text-xs">Utilisateur: {activity.user}</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-400">{activity.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
