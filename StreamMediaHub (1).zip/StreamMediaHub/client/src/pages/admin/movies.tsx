import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Movie, insertMovieSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Edit, Trash2, Plus } from "lucide-react";

// Extended movie schema for form validation
const movieFormSchema = insertMovieSchema.extend({
  id: z.number().optional(),
});

type MovieFormValues = z.infer<typeof movieFormSchema>;

const AdminMoviesPage = () => {
  const { isAdmin } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [editingMovie, setEditingMovie] = useState<Movie | null>(null);
  const [page, setPage] = useState(1);
  const [movieToDelete, setMovieToDelete] = useState<Movie | null>(null);
  const itemsPerPage = 10;

  // Redirect non-admin users
  useEffect(() => {
    if (isAdmin === false) {
      navigate("/");
    }
  }, [isAdmin, navigate]);

  // Fetch movies
  const { data: movies, isLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  // Form for adding/editing movies
  const form = useForm<MovieFormValues>({
    resolver: zodResolver(movieFormSchema),
    defaultValues: {
      title: "",
      description: "",
      year: undefined,
      duration: undefined,
      category: "",
      rating: undefined,
      posterUrl: "",
      videoUrl: "",
    },
  });

  // Reset form when editing movie changes
  useEffect(() => {
    if (editingMovie) {
      form.reset({
        id: editingMovie.id,
        title: editingMovie.title,
        description: editingMovie.description || "",
        year: editingMovie.year,
        duration: editingMovie.duration,
        category: editingMovie.category || "",
        rating: editingMovie.rating,
        posterUrl: editingMovie.posterUrl || "",
        videoUrl: editingMovie.videoUrl || "",
      });
    } else {
      form.reset({
        title: "",
        description: "",
        year: undefined,
        duration: undefined,
        category: "",
        rating: undefined,
        posterUrl: "",
        videoUrl: "",
      });
    }
  }, [editingMovie, form]);

  // Add movie mutation
  const addMovieMutation = useMutation({
    mutationFn: async (movie: MovieFormValues) => {
      const res = await apiRequest("POST", "/api/movies", movie);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      toast({
        title: "Film ajouté",
        description: "Le film a été ajouté avec succès.",
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de l'ajout du film.",
        variant: "destructive",
      });
    },
  });

  // Update movie mutation
  const updateMovieMutation = useMutation({
    mutationFn: async (movie: MovieFormValues) => {
      const { id, ...movieData } = movie;
      const res = await apiRequest("PUT", `/api/movies/${id}`, movieData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      toast({
        title: "Film mis à jour",
        description: "Le film a été mis à jour avec succès.",
      });
      setEditingMovie(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de la mise à jour du film.",
        variant: "destructive",
      });
    },
  });

  // Delete movie mutation
  const deleteMovieMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/movies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      toast({
        title: "Film supprimé",
        description: "Le film a été supprimé avec succès.",
      });
      setMovieToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de la suppression du film.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: MovieFormValues) => {
    if (editingMovie) {
      updateMovieMutation.mutate({ ...data, id: editingMovie.id });
    } else {
      addMovieMutation.mutate(data);
    }
  };

  // Calculate pagination
  const totalPages = movies ? Math.ceil(movies.length / itemsPerPage) : 1;
  const paginatedMovies = movies
    ? movies.slice((page - 1) * itemsPerPage, page * itemsPerPage)
    : [];

  // Available categories derived from existing movies
  const categories = movies
    ? Array.from(new Set(movies.map(movie => movie.category).filter(Boolean)))
    : [];

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">Gestion des Films</h1>
          <Button onClick={() => navigate("/admin")}>
            Retour au tableau de bord
          </Button>
        </div>

        {/* Add/Edit Movie Form */}
        <Card className="bg-gray-800 border-gray-700 mb-8">
          <CardHeader>
            <CardTitle>{editingMovie ? "Modifier le film" : "Ajouter un nouveau film"}</CardTitle>
            <CardDescription>
              {editingMovie
                ? "Modifiez les informations du film existant."
                : "Remplissez le formulaire pour ajouter un nouveau film."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem className="space-y-2">
                        <FormLabel>Titre</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Titre du film"
                            className="bg-gray-700 border-gray-600"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem className="space-y-2">
                        <FormLabel>Année</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Année de sortie"
                            className="bg-gray-700 border-gray-600"
                            {...field}
                            onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem className="space-y-2">
                        <FormLabel>Catégorie</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-gray-700 border-gray-600">
                              <SelectValue placeholder="Sélectionnez une catégorie" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-gray-800 border-gray-700">
                            {categories.map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                            <SelectItem value="Action">Action</SelectItem>
                            <SelectItem value="Aventure">Aventure</SelectItem>
                            <SelectItem value="Animation">Animation</SelectItem>
                            <SelectItem value="Comédie">Comédie</SelectItem>
                            <SelectItem value="Crime">Crime</SelectItem>
                            <SelectItem value="Documentaire">Documentaire</SelectItem>
                            <SelectItem value="Drame">Drame</SelectItem>
                            <SelectItem value="Famille">Famille</SelectItem>
                            <SelectItem value="Fantastique">Fantastique</SelectItem>
                            <SelectItem value="Horreur">Horreur</SelectItem>
                            <SelectItem value="Romance">Romance</SelectItem>
                            <SelectItem value="Science Fiction">Science Fiction</SelectItem>
                            <SelectItem value="Thriller">Thriller</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem className="space-y-2">
                        <FormLabel>Durée (minutes)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Durée en minutes"
                            className="bg-gray-700 border-gray-600"
                            {...field}
                            onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                      <FormItem className="space-y-2">
                        <FormLabel>Note (0-100)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Note sur 100"
                            className="bg-gray-700 border-gray-600"
                            {...field}
                            onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                            min={0}
                            max={100}
                          />
                        </FormControl>
                        <FormDescription>
                          Note du film sur 100 (ex: 85 pour 8.5/10)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="posterUrl"
                    render={({ field }) => (
                      <FormItem className="space-y-2">
                        <FormLabel>URL de l'affiche</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="URL de l'image d'affiche"
                            className="bg-gray-700 border-gray-600"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="videoUrl"
                    render={({ field }) => (
                      <FormItem className="space-y-2">
                        <FormLabel>URL de la vidéo</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="URL du fichier vidéo"
                            className="bg-gray-700 border-gray-600"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem className="space-y-2">
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Description du film"
                          className="bg-gray-700 border-gray-600 resize-none min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-4">
                  {editingMovie && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setEditingMovie(null);
                        form.reset();
                      }}
                    >
                      Annuler
                    </Button>
                  )}
                  <Button
                    type="submit"
                    disabled={addMovieMutation.isPending || updateMovieMutation.isPending}
                  >
                    {(addMovieMutation.isPending || updateMovieMutation.isPending) && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    {editingMovie ? "Mettre à jour" : "Ajouter"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Movies List */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Liste des films</CardTitle>
            <CardDescription>
              {`Affichage de ${paginatedMovies.length} film(s) sur ${movies?.length || 0} au total`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : movies?.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <p>Aucun film disponible. Ajoutez votre premier film en utilisant le formulaire ci-dessus.</p>
              </div>
            ) : (
              <>
                <div className="rounded-md border border-gray-700">
                  <Table>
                    <TableHeader className="bg-gray-900">
                      <TableRow>
                        <TableHead>Titre</TableHead>
                        <TableHead>Catégorie</TableHead>
                        <TableHead>Année</TableHead>
                        <TableHead>Durée</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedMovies.map((movie) => (
                        <TableRow key={movie.id} className="border-gray-700">
                          <TableCell className="font-medium flex items-center">
                            {movie.posterUrl && (
                              <img
                                src={movie.posterUrl}
                                alt={movie.title}
                                className="h-10 w-10 rounded object-cover mr-3"
                              />
                            )}
                            <span className="truncate max-w-[200px]">{movie.title}</span>
                          </TableCell>
                          <TableCell>
                            {movie.category ? (
                              <span className="px-2 py-1 rounded-full text-xs bg-primary bg-opacity-20 text-primary">
                                {movie.category}
                              </span>
                            ) : (
                              <span className="text-gray-500">-</span>
                            )}
                          </TableCell>
                          <TableCell>{movie.year || "-"}</TableCell>
                          <TableCell>
                            {movie.duration ? `${movie.duration} min` : "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setEditingMovie(movie)}
                                title="Modifier"
                              >
                                <Edit className="h-4 w-4 text-primary" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    title="Supprimer"
                                  >
                                    <Trash2 className="h-4 w-4 text-red-500" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent className="bg-gray-800 border-gray-700">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>
                                      Supprimer {movie.title}?
                                    </AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Cette action est irréversible. Le film sera
                                      définitivement supprimé de la plateforme.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel className="bg-gray-700 hover:bg-gray-600">
                                      Annuler
                                    </AlertDialogCancel>
                                    <AlertDialogAction
                                      className="bg-red-500 hover:bg-red-600"
                                      onClick={() => deleteMovieMutation.mutate(movie.id)}
                                    >
                                      {deleteMovieMutation.isPending ? (
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                      ) : (
                                        "Supprimer"
                                      )}
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <Pagination className="mt-4">
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious
                          onClick={() => setPage((p) => Math.max(1, p - 1))}
                          disabled={page === 1}
                        />
                      </PaginationItem>
                      {Array.from({ length: totalPages }).map((_, i) => (
                        <PaginationItem key={i}>
                          <PaginationLink
                            isActive={page === i + 1}
                            onClick={() => setPage(i + 1)}
                          >
                            {i + 1}
                          </PaginationLink>
                        </PaginationItem>
                      ))}
                      <PaginationItem>
                        <PaginationNext
                          onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                          disabled={page === totalPages}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminMoviesPage;
