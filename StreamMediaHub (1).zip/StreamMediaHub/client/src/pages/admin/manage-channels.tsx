import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Media } from '@shared/schema';
import { AdminSidebar } from '@/components/admin/sidebar';
import { ContentForm } from '@/components/admin/content-form';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Radio,
  Plus,
  Pencil,
  Trash2,
  Search,
  SlidersHorizontal
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';

export default function ManageChannels() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<Media | null>(null);
  
  const itemsPerPage = 10;
  
  const { data: channels = [], isLoading } = useQuery<Media[]>({
    queryKey: ['/api/media/channel'],
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/media/${id}`);
    },
    onSuccess: () => {
      toast({
        title: 'Chaîne supprimée',
        description: 'La chaîne a été supprimée avec succès.'
      });
      queryClient.invalidateQueries({ queryKey: ['/api/media/channel'] });
      queryClient.invalidateQueries({ queryKey: ['/api/media'] });
      setIsDeleteDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: 'Erreur',
        description: `Impossible de supprimer la chaîne: ${error.message}`,
        variant: 'destructive'
      });
    }
  });
  
  const filteredChannels = channels.filter(channel => 
    channel.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    channel.genre.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const paginatedChannels = filteredChannels.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );
  
  const totalPages = Math.ceil(filteredChannels.length / itemsPerPage);
  
  const handleEdit = (channel: Media) => {
    setSelectedChannel(channel);
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (channel: Media) => {
    setSelectedChannel(channel);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (selectedChannel) {
      deleteMutation.mutate(selectedChannel.id);
    }
  };
  
  return (
    <div className="flex min-h-screen">
      <AdminSidebar />
      
      <div className="flex-1">
        <div className="p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-1">Gestion des Chaînes TV</h1>
              <p className="text-muted-foreground">
                Ajoutez, modifiez ou supprimez des chaînes de télévision
              </p>
            </div>
            <Radio className="h-8 w-8 text-muted-foreground" />
          </div>
          
          <div className="flex justify-between items-center mb-6">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Rechercher une chaîne..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Button 
              onClick={() => setIsAddDialogOpen(true)}
              className="bg-primary hover:bg-primary/90"
            >
              <Plus className="mr-2 h-4 w-4" /> Ajouter une chaîne
            </Button>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredChannels.length === 0 ? (
            <div className="text-center py-12 border rounded-md">
              <Radio className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Aucune chaîne trouvée</h3>
              <p className="text-muted-foreground mb-4">
                Il n'y a pas de chaînes correspondant à votre recherche.
              </p>
              <Button 
                variant="outline" 
                onClick={() => setSearchQuery('')}
              >
                Réinitialiser la recherche
              </Button>
            </div>
          ) : (
            <>
              <div className="border rounded-md mb-4 overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">ID</TableHead>
                      <TableHead>Titre</TableHead>
                      <TableHead>Genre</TableHead>
                      <TableHead>URL de contenu</TableHead>
                      <TableHead>À la une</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedChannels.map((channel) => (
                      <TableRow key={channel.id}>
                        <TableCell className="font-medium">{channel.id}</TableCell>
                        <TableCell>{channel.title}</TableCell>
                        <TableCell>{channel.genre}</TableCell>
                        <TableCell className="max-w-[200px] truncate">
                          {channel.contentUrl}
                        </TableCell>
                        <TableCell>
                          {channel.featured ? 
                            <span className="px-2 py-1 bg-primary/20 text-primary rounded-full text-xs">
                              À la une
                            </span> : 
                            <span className="px-2 py-1 bg-muted text-muted-foreground rounded-full text-xs">
                              Non
                            </span>
                          }
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <SlidersHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleEdit(channel)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                Modifier
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                onClick={() => handleDelete(channel)}
                                className="text-red-600"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Supprimer
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {totalPages > 1 && (
                <div className="flex justify-center">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          href="#" 
                          onClick={(e) => {
                            e.preventDefault();
                            if (page > 1) setPage(page - 1);
                          }}
                          className={page === 1 ? 'pointer-events-none opacity-50' : ''}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: totalPages }).map((_, index) => (
                        <PaginationItem key={index}>
                          <PaginationLink 
                            href="#" 
                            onClick={(e) => {
                              e.preventDefault();
                              setPage(index + 1);
                            }}
                            isActive={page === index + 1}
                          >
                            {index + 1}
                          </PaginationLink>
                        </PaginationItem>
                      ))}
                      
                      <PaginationItem>
                        <PaginationNext 
                          href="#" 
                          onClick={(e) => {
                            e.preventDefault();
                            if (page < totalPages) setPage(page + 1);
                          }}
                          className={page === totalPages ? 'pointer-events-none opacity-50' : ''}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      
      {/* Add Channel Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Ajouter une nouvelle chaîne TV</DialogTitle>
            <DialogDescription>
              Remplissez le formulaire ci-dessous pour ajouter une chaîne de télévision à votre plateforme.
            </DialogDescription>
          </DialogHeader>
          
          <ContentForm 
            type="channel" 
            onSuccess={() => setIsAddDialogOpen(false)} 
          />
        </DialogContent>
      </Dialog>
      
      {/* Edit Channel Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Modifier la chaîne TV</DialogTitle>
            <DialogDescription>
              Mettez à jour les informations de la chaîne.
            </DialogDescription>
          </DialogHeader>
          
          {selectedChannel && (
            <ContentForm 
              initialData={selectedChannel} 
              onSuccess={() => setIsEditDialogOpen(false)} 
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer cette chaîne TV ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          
          {selectedChannel && (
            <div className="py-4">
              <p className="font-medium">{selectedChannel.title}</p>
              <p className="text-sm text-muted-foreground">{selectedChannel.genre}</p>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Annuler
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Suppression...
                </>
              ) : 'Supprimer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
