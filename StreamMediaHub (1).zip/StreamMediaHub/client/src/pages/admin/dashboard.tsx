import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { User, Media } from '@shared/schema';
import { AdminSidebar } from '@/components/admin/sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  LayoutDashboard, 
  Users, 
  Film, 
  Tv, 
  Radio,
  TrendingUp,
  Eye
} from 'lucide-react';
import { Link } from 'wouter';

export default function AdminDashboard() {
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });
  
  const { data: movies = [] } = useQuery<Media[]>({
    queryKey: ['/api/media/movie'],
  });
  
  const { data: series = [] } = useQuery<Media[]>({
    queryKey: ['/api/media/series'],
  });
  
  const { data: channels = [] } = useQuery<Media[]>({
    queryKey: ['/api/media/channel'],
  });

  const { data: activities = [] } = useQuery<any[]>({
    queryKey: ['/api/activities'],
  });

  const totalMedia = movies.length + series.length + channels.length;
  
  return (
    <div className="flex min-h-screen">
      <AdminSidebar />
      
      <div className="flex-1">
        <div className="p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-1">Dashboard</h1>
              <p className="text-muted-foreground">
                Vue d'ensemble de votre plateforme StreamFlix
              </p>
            </div>
            <LayoutDashboard className="h-8 w-8 text-muted-foreground" />
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Utilisateurs</p>
                    <h3 className="text-2xl font-bold">{users.length}</h3>
                  </div>
                  <div className="bg-blue-500 bg-opacity-20 p-3 rounded-full">
                    <Users className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Médias</p>
                    <h3 className="text-2xl font-bold">{totalMedia}</h3>
                  </div>
                  <div className="bg-green-500 bg-opacity-20 p-3 rounded-full">
                    <Film className="h-6 w-6 text-green-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Vues Aujourd'hui</p>
                    <h3 className="text-2xl font-bold">
                      {Math.floor(Math.random() * 10000)}
                    </h3>
                  </div>
                  <div className="bg-primary bg-opacity-20 p-3 rounded-full">
                    <Eye className="h-6 w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Content Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center">
                  <Film className="h-4 w-4 mr-2" /> Films
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{movies.length}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  <Link href="/admin/movies" className="text-primary hover:underline">
                    Gérer les films
                  </Link>
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center">
                  <Tv className="h-4 w-4 mr-2" /> Séries
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{series.length}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  <Link href="/admin/series" className="text-primary hover:underline">
                    Gérer les séries
                  </Link>
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center">
                  <Radio className="h-4 w-4 mr-2" /> Chaînes TV
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{channels.length}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  <Link href="/admin/channels" className="text-primary hover:underline">
                    Gérer les chaînes
                  </Link>
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Content Management Section */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Ajouter du contenu</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                <Link href="/admin/movies">
                  <a className="flex justify-between items-center p-4 hover:bg-secondary transition cursor-pointer">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-secondary rounded-md flex items-center justify-center mr-3">
                        <Film className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div>
                        <h4 className="font-medium">Ajouter un film</h4>
                        <p className="text-xs text-muted-foreground">Uploader ou lier un film à la plateforme</p>
                      </div>
                    </div>
                    <svg className="h-5 w-5 text-muted-foreground" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </a>
                </Link>
                
                <Link href="/admin/series">
                  <a className="flex justify-between items-center p-4 hover:bg-secondary transition cursor-pointer">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-secondary rounded-md flex items-center justify-center mr-3">
                        <Tv className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div>
                        <h4 className="font-medium">Ajouter une série</h4>
                        <p className="text-xs text-muted-foreground">Gérer les séries et leurs épisodes</p>
                      </div>
                    </div>
                    <svg className="h-5 w-5 text-muted-foreground" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </a>
                </Link>
                
                <Link href="/admin/channels">
                  <a className="flex justify-between items-center p-4 hover:bg-secondary transition cursor-pointer">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-secondary rounded-md flex items-center justify-center mr-3">
                        <Radio className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div>
                        <h4 className="font-medium">Ajouter une chaîne TV</h4>
                        <p className="text-xs text-muted-foreground">Configurer une source de streaming en direct</p>
                      </div>
                    </div>
                    <svg className="h-5 w-5 text-muted-foreground" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </a>
                </Link>
              </div>
            </CardContent>
          </Card>
          
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Activité récente</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {activities && activities.length > 0 ? (
                <table className="w-full">
                  <thead className="bg-muted text-muted-foreground text-left text-xs">
                    <tr>
                      <th className="p-4 font-medium">Utilisateur</th>
                      <th className="p-4 font-medium">Action</th>
                      <th className="p-4 font-medium">Date</th>
                      <th className="p-4 font-medium">Statut</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {activities.map((activity, index) => (
                      <tr key={index} className="hover:bg-muted/50 transition">
                        <td className="p-4 text-sm">{activity.username}</td>
                        <td className="p-4 text-sm">{activity.action}</td>
                        <td className="p-4 text-sm text-muted-foreground">{activity.date}</td>
                        <td className="p-4 text-sm">
                          <span className={`bg-${activity.status === 'success' ? 'green' : 'red'}-500 bg-opacity-20 text-${activity.status === 'success' ? 'green' : 'red'}-500 text-xs px-2 py-1 rounded-full`}>
                            {activity.status === 'success' ? 'Réussi' : 'Échec'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Aucune activité récente</p>
                </div>
              )}
            </CardContent>
          </Card>
          
        </div>
      </div>
    </div>
  );
}
