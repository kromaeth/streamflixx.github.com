import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Media } from '@shared/schema';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { ContentCard } from '@/components/content-card';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { VideoPlayer } from '@/components/ui/video-player';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { X } from 'lucide-react';

const genresList = [
  'Tous', 'Action', 'Comédie', 'Drame', 'Science-Fiction', 'Horreur', 
  'Aventure', 'Animation', 'Fantastique', 'Thriller'
];

export default function MoviesPage() {
  const [selectedMovie, setSelectedMovie] = useState<Media | null>(null);
  const [videoOpen, setVideoOpen] = useState(false);
  const [selectedGenre, setSelectedGenre] = useState('Tous');
  
  const { data: movies = [], isLoading } = useQuery<Media[]>({
    queryKey: ['/api/media/movie'],
  });
  
  const handleMovieClick = (movie: Media) => {
    setSelectedMovie(movie);
    setVideoOpen(true);
  };
  
  const filteredMovies = selectedGenre === 'Tous' 
    ? movies 
    : movies.filter(movie => movie.genre === selectedGenre);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <div className="container mx-auto py-8 px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Films</h1>
            <p className="text-muted-foreground">
              Découvrez notre vaste collection de films dans tous les genres
            </p>
          </div>
          
          <div className="mb-8 overflow-x-auto">
            <Tabs 
              defaultValue="Tous" 
              value={selectedGenre} 
              onValueChange={setSelectedGenre}
              className="w-full"
            >
              <TabsList className="mb-8 flex flex-nowrap">
                {genresList.map((genre) => (
                  <TabsTrigger 
                    key={genre} 
                    value={genre}
                    className="whitespace-nowrap"
                  >
                    {genre}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              <TabsContent value={selectedGenre} className="mt-0">
                {isLoading ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                    {Array(10).fill(0).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-secondary h-64 rounded-md mb-2"></div>
                        <div className="bg-secondary h-4 w-3/4 rounded mb-1"></div>
                        <div className="bg-secondary h-3 w-1/2 rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : filteredMovies.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-muted-foreground text-lg">
                      Aucun film disponible dans cette catégorie.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                    {filteredMovies.map((movie) => (
                      <ContentCard 
                        key={movie.id} 
                        content={movie} 
                        onClick={handleMovieClick}
                        className="w-full"
                      />
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      <Footer />
      
      {/* Video Player Dialog */}
      <Dialog open={videoOpen} onOpenChange={setVideoOpen}>
        <DialogContent className="max-w-4xl p-0 bg-black overflow-hidden" 
          onInteractOutside={(e) => e.preventDefault()}>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 z-50 text-white bg-black/50 rounded-full"
            onClick={() => setVideoOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
          
          {selectedMovie && (
            <VideoPlayer
              src={selectedMovie.contentUrl}
              title={selectedMovie.title}
              autoPlay={true}
              className="w-full aspect-video"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
