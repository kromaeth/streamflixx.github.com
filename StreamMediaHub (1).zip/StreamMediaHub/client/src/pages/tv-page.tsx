import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Media } from '@shared/schema';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { VideoPlayer } from '@/components/ui/video-player';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

export default function TvPage() {
  const [selectedChannel, setSelectedChannel] = useState<Media | null>(null);
  const [videoOpen, setVideoOpen] = useState(false);
  
  const { data: channels = [], isLoading } = useQuery<Media[]>({
    queryKey: ['/api/media/channel'],
  });
  
  const handleChannelClick = (channel: Media) => {
    setSelectedChannel(channel);
    setVideoOpen(true);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <div className="container mx-auto py-8 px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Chaînes TV en direct</h1>
            <p className="text-muted-foreground">
              Accédez à vos chaînes TV favorites du monde entier en direct 24/7
            </p>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
              {Array(12).fill(0).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-secondary h-28 rounded-md mb-2"></div>
                  <div className="bg-secondary h-4 w-3/4 rounded mb-1"></div>
                  <div className="bg-secondary h-3 w-1/2 rounded"></div>
                </div>
              ))}
            </div>
          ) : channels.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-muted-foreground text-lg">
                Aucune chaîne disponible pour le moment.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
              {channels.map((channel) => (
                <div 
                  key={channel.id} 
                  className="cursor-pointer transition-transform duration-300 hover:scale-105"
                  onClick={() => handleChannelClick(channel)}
                >
                  <div className="relative bg-secondary rounded-md h-28 flex items-center justify-center mb-2 overflow-hidden">
                    <div className="absolute top-2 right-2 bg-primary text-xs text-white px-2 py-1 rounded-sm">
                      LIVE
                    </div>
                    <img 
                      src={channel.thumbnailUrl} 
                      alt={channel.title}
                      className="max-w-[80%] max-h-[80%] object-contain"
                    />
                  </div>
                  <h3 className="font-medium">{channel.title}</h3>
                  <p className="text-xs text-muted-foreground">{channel.genre}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      {/* Video Player Dialog */}
      <Dialog open={videoOpen} onOpenChange={setVideoOpen}>
        <DialogContent className="max-w-4xl p-0 bg-black overflow-hidden" 
          onInteractOutside={(e) => e.preventDefault()}>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 z-50 text-white bg-black/50 rounded-full"
            onClick={() => setVideoOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
          
          {selectedChannel && (
            <VideoPlayer
              src={selectedChannel.contentUrl}
              title={selectedChannel.title}
              autoPlay={true}
              className="w-full aspect-video"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
