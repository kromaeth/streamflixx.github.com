import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { WatchTogetherProvider, useWatchTogether } from "@/hooks/use-watch-together";
import InvitationsList from "@/components/watch-together/invitations-list";
import SessionsList from "@/components/watch-together/sessions-list";
import SyncPlayer from "@/components/watch-together/sync-player";

// Composant du contenu principal avec accès au contexte WatchTogether
function WatchTogetherContent() {
  const { currentSession } = useWatchTogether();
  const [activeTab, setActiveTab] = useState(currentSession ? "player" : "sessions");
  
  // Changer automatiquement pour l'onglet du lecteur quand une session est active
  React.useEffect(() => {
    if (currentSession && activeTab !== "player") {
      setActiveTab("player");
    }
  }, [currentSession]);

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-indigo-400 to-purple-600 bg-clip-text text-transparent">
          Regarder Ensemble
        </h1>
        <p className="text-muted-foreground">
          Invitez vos amis et regardez du contenu simultanément, peu importe où ils se trouvent.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="invitations">Invitations</TabsTrigger>
          <TabsTrigger value="sessions">Sessions actives</TabsTrigger>
          <TabsTrigger value="player" disabled={!currentSession}>
            Lecteur{currentSession ? "" : " (aucune session)"}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="invitations" className="py-4">
          <Card>
            <CardHeader>
              <CardTitle>Invitations reçues</CardTitle>
              <CardDescription>
                Voici les invitations que d'autres utilisateurs vous ont envoyées
              </CardDescription>
            </CardHeader>
            <CardContent>
              <InvitationsList type="received" />
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Invitations envoyées</CardTitle>
              <CardDescription>
                Voici les invitations que vous avez envoyées à d'autres utilisateurs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <InvitationsList type="sent" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sessions" className="py-4">
          <Card>
            <CardHeader>
              <CardTitle>Vos sessions actives</CardTitle>
              <CardDescription>
                Rejoignez une session pour regarder du contenu avec d'autres utilisateurs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <SessionsList />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="player" className="py-4">
          <Card>
            <CardHeader>
              <CardTitle>Lecteur synchronisé</CardTitle>
              <CardDescription>
                Regardez du contenu en synchronisation avec d'autres utilisateurs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <SyncPlayer />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Page principale avec le provider
export default function WatchTogetherPage() {
  return (
    <WatchTogetherProvider>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <WatchTogetherContent />
        </main>
        <Footer />
      </div>
    </WatchTogetherProvider>
  );
}