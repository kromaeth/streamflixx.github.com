import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, Link } from 'wouter';
import { Media } from '@shared/schema';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { ContentRow, FeaturedContent } from '@/components/content-row';
import { TvIcon, MovieIcon, SeriesIcon } from '@/components/ui/icons';
import { VideoPlayer } from '@/components/ui/video-player';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { X, CreditCard, LockIcon, AlertTriangle, Users } from 'lucide-react';
import { useSubscription } from '@/hooks/use-subscription';
import { useWatchTogether } from '@/hooks/use-watch-together';
import { useAuth } from '@/hooks/use-auth';

export default function HomePage() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedContent, setSelectedContent] = useState<Media | null>(null);
  const [videoOpen, setVideoOpen] = useState(false);
  const [subscriptionDialogOpen, setSubscriptionDialogOpen] = useState(false);
  
  // Hooks pour les fonctionnalités
  const { hasActiveSubscription } = useSubscription();
  const { sendInvitation, searchUserByHandle } = useWatchTogether();
  
  const { data: featuredContent } = useQuery<Media>({
    queryKey: ['/api/media/featured'],
  });
  
  const { data: popularContent = [] } = useQuery<Media[]>({
    queryKey: ['/api/media/popular'],
  });
  
  const { data: liveChannels = [] } = useQuery<Media[]>({
    queryKey: ['/api/media/channel'],
  });
  
  const { data: newSeries = [] } = useQuery<Media[]>({
    queryKey: ['/api/media/series/new'],
  });
  
  const handleContentClick = (content: Media) => {
    // Si l'utilisateur n'a pas d'abonnement, afficher un message et bloquer l'accès
    if (!hasActiveSubscription) {
      showSubscriptionRequired();
    } else {
      setSelectedContent(content);
      setVideoOpen(true);
    }
  };
  
  const handleWatchNow = (content: Media) => {
    // Si l'utilisateur n'a pas d'abonnement, afficher un message et bloquer l'accès
    if (!hasActiveSubscription) {
      showSubscriptionRequired();
    } else {
      setSelectedContent(content);
      setVideoOpen(true);
    }
  };
  
  const handleMoreInfo = (content: Media) => {
    toast({
      title: content.title,
      description: content.description,
    });
  };
  
  // Gestionnaire pour la fonctionnalité "Regarder ensemble"
  const handleWatchTogether = (content: Media) => {
    // Vérifier si l'utilisateur est connecté et a un abonnement
    if (!user) {
      toast({
        title: "Connexion requise",
        description: "Vous devez être connecté pour inviter des amis à regarder ensemble.",
        variant: "destructive",
        action: (
          <Button 
            className="bg-primary text-white" 
            size="sm" 
            onClick={() => navigate('/auth')}
          >
            Se connecter
          </Button>
        ),
      });
      return;
    }
    
    if (!hasActiveSubscription) {
      showSubscriptionRequired();
      return;
    }
    
    // Rediriger vers la page watch-together avec le contenu sélectionné
    navigate(`/watch-together?mediaId=${content.id}`);
  };
  
  const navigateToCategory = (path: string) => {
    navigate(path);
  };
  
  // Afficher un message indiquant que l'abonnement est requis
  const showSubscriptionRequired = () => {
    toast({
      title: "Contenu Premium",
      description: "Ce contenu nécessite un abonnement. Abonnez-vous pour y accéder.",
      variant: "destructive",
      action: (
        <Button 
          className="bg-primary text-white" 
          size="sm" 
          onClick={() => navigate('/subscription')}
        >
          <CreditCard className="w-4 h-4 mr-1" />
          S'abonner
        </Button>
      ),
    });
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {featuredContent && (
          <FeaturedContent 
            content={featuredContent} 
            onWatchClick={handleWatchNow}
            onInfoClick={handleMoreInfo}
            onWatchTogetherClick={handleWatchTogether}
          />
        )}
        
        {/* Main Category Navigation */}
        <section className="py-12 px-4 md:px-8 container mx-auto">
          <h2 className="text-2xl font-bold mb-8">Explorez notre catalogue</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* TV Button */}
            <div 
              className="group relative rounded-xl overflow-hidden h-64 shadow-lg cursor-pointer"
              onClick={() => navigateToCategory('/tv')}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent z-10"></div>
              {!hasActiveSubscription && (
                <div className="absolute top-4 right-4 z-20 bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded-full flex items-center space-x-1">
                  <LockIcon className="h-3 w-3 text-yellow-400" />
                  <span className="text-xs font-semibold text-yellow-400">PREMIUM</span>
                </div>
              )}
              <img 
                src="https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80" 
                alt="Télévision" 
                className="w-full h-full object-cover transition group-hover:scale-110 duration-300"
              />
              <div className="absolute bottom-0 left-0 p-6 z-20 w-full">
                <h3 className="text-2xl font-bold mb-2">Télévision</h3>
                <p className="text-foreground text-sm mb-4 opacity-90">Chaînes en direct 24/7</p>
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  <TvIcon className="h-4 w-4 mr-2" /> Explorer
                </Button>
              </div>
            </div>

            {/* Movies Button */}
            <div 
              className="group relative rounded-xl overflow-hidden h-64 shadow-lg cursor-pointer"
              onClick={() => navigateToCategory('/movies')}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent z-10"></div>
              {!hasActiveSubscription && (
                <div className="absolute top-4 right-4 z-20 bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded-full flex items-center space-x-1">
                  <LockIcon className="h-3 w-3 text-yellow-400" />
                  <span className="text-xs font-semibold text-yellow-400">PREMIUM</span>
                </div>
              )}
              <img 
                src="https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-4.0.3&auto=format&fit=crop&w=1459&q=80" 
                alt="Films" 
                className="w-full h-full object-cover transition group-hover:scale-110 duration-300"
              />
              <div className="absolute bottom-0 left-0 p-6 z-20 w-full">
                <h3 className="text-2xl font-bold mb-2">Films</h3>
                <p className="text-foreground text-sm mb-4 opacity-90">Blockbusters et classiques</p>
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  <MovieIcon className="h-4 w-4 mr-2" /> Explorer
                </Button>
              </div>
            </div>

            {/* Series Button */}
            <div 
              className="group relative rounded-xl overflow-hidden h-64 shadow-lg cursor-pointer"
              onClick={() => navigateToCategory('/series')}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent z-10"></div>
              {!hasActiveSubscription && (
                <div className="absolute top-4 right-4 z-20 bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded-full flex items-center space-x-1">
                  <LockIcon className="h-3 w-3 text-yellow-400" />
                  <span className="text-xs font-semibold text-yellow-400">PREMIUM</span>
                </div>
              )}
              <img 
                src="https://images.unsplash.com/photo-1522869635100-187f6605241d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80" 
                alt="Séries" 
                className="w-full h-full object-cover transition group-hover:scale-110 duration-300"
              />
              <div className="absolute bottom-0 left-0 p-6 z-20 w-full">
                <h3 className="text-2xl font-bold mb-2">Séries</h3>
                <p className="text-foreground text-sm mb-4 opacity-90">Séries populaires et exclusivités</p>
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  <SeriesIcon className="h-4 w-4 mr-2" /> Explorer
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Notification d'abonnement */}
        {!hasActiveSubscription && (
          <section className="relative py-10 mt-4 overflow-hidden">
            <div className="container mx-auto px-4 md:px-8 relative z-10">
              <div className="bg-gradient-to-r from-amber-600/30 to-amber-500/20 rounded-xl p-4 md:p-6 flex flex-col md:flex-row items-center justify-between border border-amber-500/40 shadow-lg">
                <div className="flex items-center mb-4 md:mb-0">
                  <div className="h-12 w-12 bg-amber-500/20 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                    <AlertTriangle className="h-6 w-6 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">Accès Premium requis</h3>
                    <p className="text-white/80 text-sm">Un abonnement est nécessaire pour accéder aux films, séries et chaînes TV.</p>
                  </div>
                </div>
                <Button 
                  className="bg-gradient-to-r from-amber-500 to-amber-600 hover:brightness-110 text-white px-6 shadow-md" 
                  onClick={() => navigate('/subscription')}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  S'abonner maintenant
                </Button>
              </div>
            </div>
          </section>
        )}
        
        {/* Content Sections */}
        <section className="pb-12 px-4 md:px-8 container mx-auto">
          {popularContent.length > 0 && (
            <ContentRow 
              title="Populaire sur StreamFlix" 
              contents={popularContent} 
              viewAllLink="/popular" 
              onContentClick={handleContentClick}
              onWatchTogetherClick={handleWatchTogether}
            />
          )}
          
          {liveChannels.length > 0 && (
            <ContentRow 
              title="Chaînes TV en direct" 
              contents={liveChannels} 
              viewAllLink="/tv" 
              onContentClick={handleContentClick}
            />
          )}
          
          {newSeries.length > 0 && (
            <ContentRow 
              title="Nouvelles séries" 
              contents={newSeries} 
              viewAllLink="/series" 
              onContentClick={handleContentClick}
              onWatchTogetherClick={handleWatchTogether}
            />
          )}
        </section>
      </main>
      
      <Footer />
      
      {/* Video Player Dialog */}
      <Dialog open={videoOpen} onOpenChange={setVideoOpen}>
        <DialogContent className="max-w-4xl p-0 bg-black overflow-hidden" 
          onInteractOutside={(e) => e.preventDefault()}>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 z-50 text-white bg-black/50 rounded-full"
            onClick={() => setVideoOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
          
          {selectedContent && (
            <VideoPlayer
              src={selectedContent.contentUrl}
              title={selectedContent.title}
              autoPlay={true}
              className="w-full aspect-video"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
