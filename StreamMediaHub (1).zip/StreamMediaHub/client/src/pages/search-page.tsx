import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { AdvancedSearch } from "@/components/search/advanced-search";
import { ContentRow } from "@/components/content-row";
import { Media } from "@shared/schema";
import { Loader2, Search } from "lucide-react";
import { useLocation } from "wouter";

type SearchParams = {
  q?: string;  // Le paramètre de requête doit être 'q' pour l'API
  type?: string;
  genre?: string;
  year?: number;
  sortBy?: 'title' | 'year' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
};

export default function SearchPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [hasSearched, setHasSearched] = useState(false);
  
  // État pour les paramètres de recherche actuels
  const [currentParams, setCurrentParams] = useState<SearchParams>({});
  
  // Utilisation de react-query pour la recherche
  const { data: searchResults = [], isLoading, refetch } = useQuery<Media[], Error>({
    queryKey: ['/api/search', currentParams],
    enabled: hasSearched, // Ne pas exécuter automatiquement la requête au chargement
    queryFn: async ({ queryKey }) => {
      const [_, params] = queryKey;
      const searchParams = new URLSearchParams();
      
      // Ajout des paramètres à l'URL
      Object.entries(params as SearchParams).forEach(([key, value]) => {
        if (value !== undefined && value !== '') {
          searchParams.append(key, value.toString());
        }
      });
      
      const response = await fetch(`/api/search?${searchParams.toString()}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la recherche");
      }
      
      return response.json();
    },
  });
  
  const handleSearch = async (params: any) => {
    // On filtre les paramètres vides
    const filteredParams: SearchParams = {};
    
    Object.entries(params).forEach(([key, value]) => {
      // N'ajoutez pas les valeurs vides ou les valeurs "all" pour le type et le genre
      if (value !== undefined && value !== '' && value !== null) {
        // Ne pas inclure les valeurs "all" pour type et genre
        if ((key === 'type' || key === 'genre') && value === 'all') {
          return;
        }
        
        // Ne pas inclure la valeur "none" pour sortBy
        if (key === 'sortBy' && value === 'none') {
          return;
        }
        
        // Conversion du type si nécessaire
        if (key === 'year' && value) {
          filteredParams.year = parseInt(value.toString(), 10);
        } else if (key === 'sortBy' && typeof value === 'string' && value) {
          filteredParams.sortBy = value as 'title' | 'year' | 'createdAt';
        } else if (key === 'sortOrder' && typeof value === 'string' && value) {
          filteredParams.sortOrder = value as 'asc' | 'desc';
        } else if (key === 'type' || key === 'genre') {
          filteredParams[key] = value as string;
        } else if (key === 'query') {
          // Le paramètre de recherche textuelle doit être 'q' pour l'API
          filteredParams.q = value as string;
        }
      }
    });
    
    setCurrentParams(filteredParams);
    setHasSearched(true);
    
    try {
      await refetch();
    } catch (error) {
      toast({
        title: "Erreur de recherche",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };
  
  const handleContentClick = (content: Media) => {
    // Redirection vers la page de détail du contenu
    setLocation(`/watch/${content.id}`);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto mb-8">
          <h1 className="text-3xl font-bold mb-6 text-center">
            <span className="bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent">
              Rechercher du contenu
            </span>
          </h1>
          <p className="text-center text-muted-foreground mb-8">
            Utilisez notre outil de recherche avancée pour trouver exactement ce que vous cherchez
          </p>
          
          <AdvancedSearch onSearch={handleSearch} isLoading={isLoading} />
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2 text-lg">Recherche en cours...</span>
          </div>
        ) : hasSearched ? (
          <div className="mt-12">
            {searchResults.length > 0 ? (
              <>
                <h2 className="text-xl font-semibold mb-6">
                  {searchResults.length} résultat{searchResults.length > 1 ? 's' : ''} trouvé{searchResults.length > 1 ? 's' : ''}
                </h2>
                <ContentRow 
                  title="Résultats de recherche" 
                  contents={searchResults}
                  onContentClick={handleContentClick}
                />
              </>
            ) : (
              <div className="text-center py-12">
                <div className="text-5xl mb-4">🔍</div>
                <h2 className="text-xl font-semibold mb-2">Aucun résultat trouvé</h2>
                <p className="text-muted-foreground">
                  Essayez de modifier vos critères de recherche ou d'utiliser des termes plus généraux.
                </p>
              </div>
            )}
          </div>
        ) : null}
      </main>
      
      <Footer />
    </div>
  );
}