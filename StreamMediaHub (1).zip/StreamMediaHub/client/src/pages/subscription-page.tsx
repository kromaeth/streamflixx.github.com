import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';
import { Loader2, CreditCard, CheckCircle, AlertTriangle } from 'lucide-react';
import { formatDate } from '@/lib/utils';

export default function SubscriptionPage() {
  const [_, setLocation] = useLocation();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [subscriptionData, setSubscriptionData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSubscriptionData = async () => {
      try {
        setLoading(true);
        const response = await apiRequest('GET', '/api/subscription');
        const data = await response.json();
        setSubscriptionData(data);
        setError(null);
      } catch (err) {
        setError("Impossible de charger les informations d'abonnement.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchSubscriptionData();
  }, []);

  const handleStartSubscription = async () => {
    try {
      setLoading(true);
      const response = await apiRequest('POST', '/api/create-subscription-session');
      const data = await response.json();
      
      if (data && data.url) {
        console.log("Redirection vers l'URL Stripe:", data.url);
        
        // Créer un nouvel onglet avec l'URL Stripe
        window.open(data.url, '_blank');
        
        // Alternative: redirection directe dans le même onglet
        // window.location.href = data.url;
        
        // Réinitialiser le statut de chargement
        setLoading(false);
      } else {
        console.error("Réponse invalide de l'API", data);
        throw new Error("URL de Stripe manquante dans la réponse");
      }
    } catch (err) {
      setError("Une erreur est survenue lors de la création de l'abonnement.");
      console.error(err);
      setLoading(false);
    }
  };

  const handleCancelSubscription = async () => {
    if (!confirm("Êtes-vous sûr de vouloir annuler votre abonnement ?")) {
      return;
    }
    
    try {
      setLoading(true);
      await apiRequest('POST', '/api/cancel-subscription');
      // Reload subscription data
      const response = await apiRequest('GET', '/api/subscription');
      const data = await response.json();
      setSubscriptionData(data);
      setError(null);
    } catch (err) {
      setError("Une erreur est survenue lors de l'annulation de l'abonnement.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const renderSubscriptionStatus = () => {
    if (!subscriptionData) return null;
    
    const { status, nextBillingDate, isTrialing, trialEndDate, cancelAtPeriodEnd } = subscriptionData;
    
    if (status === 'active') {
      const isInTrial = isTrialing && trialEndDate && new Date(trialEndDate) > new Date();
      const endDate = nextBillingDate ? new Date(nextBillingDate) : new Date();
      
      return (
        <div className="space-y-6">
          <div className="flex flex-col items-center justify-center">
            <div className="mb-4 p-2 rounded-full bg-green-500/10">
              <CheckCircle className="h-12 w-12 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              {isInTrial ? 'Période d\'essai en cours' : 'Abonnement Actif'}
            </h2>
            {isInTrial ? (
              <p className="text-white/60 text-center">
                Votre période d'essai se termine le {formatDate(trialEndDate)}
              </p>
            ) : (
              <p className="text-white/60 text-center">
                Votre abonnement est actif jusqu'au {formatDate(endDate)}
              </p>
            )}
            {cancelAtPeriodEnd && (
              <div className="mt-4 bg-amber-500/10 p-3 rounded-lg flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-amber-500 font-medium">Abonnement en cours d'annulation</p>
                  <p className="text-white/60 text-sm mt-1">
                    Votre accès restera disponible jusqu'au {formatDate(endDate)}, puis votre abonnement sera annulé.
                  </p>
                </div>
              </div>
            )}
          </div>
          
          <div className="pt-6 border-t border-white/10">
            <h3 className="text-lg font-medium text-white mb-4">Détails de l'abonnement</h3>
            <dl className="space-y-2">
              <div className="flex justify-between">
                <dt className="text-white/60">Plan</dt>
                <dd className="font-medium text-white">StreamFlix Premium</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-white/60">Prix</dt>
                <dd className="font-medium text-white">2,99 € / mois</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-white/60">Date de renouvellement</dt>
                <dd className="font-medium text-white">{formatDate(endDate)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-white/60">État</dt>
                <dd className="font-medium">
                  {cancelAtPeriodEnd ? (
                    <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                      Annulation programmée
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                      Actif
                    </Badge>
                  )}
                </dd>
              </div>
            </dl>
          </div>
          
          <div className="pt-6 border-t border-white/10">
            <h3 className="text-lg font-medium text-white mb-4">Gérer mon abonnement</h3>
            <div className="flex flex-col space-y-3">
              {!cancelAtPeriodEnd ? (
                <Button 
                  variant="destructive" 
                  className="bg-red-500/10 text-red-500 hover:bg-red-500/20 hover:text-red-400"
                  onClick={handleCancelSubscription}
                  disabled={loading}
                >
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Annuler mon abonnement
                </Button>
              ) : (
                <Button 
                  className="bg-primary/10 text-primary hover:bg-primary/20"
                  onClick={() => {}}
                  disabled={loading}
                >
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Reprendre mon abonnement
                </Button>
              )}
              <Button 
                variant="outline" 
                className="border-white/10 hover:bg-white/5"
                onClick={() => setLocation('/')}
              >
                Retour à l'accueil
              </Button>
            </div>
          </div>
        </div>
      );
    } else {
      return (
        <div className="space-y-6">
          <div className="flex flex-col items-center justify-center">
            <div className="mb-4 p-2 rounded-full bg-amber-500/10">
              <AlertTriangle className="h-12 w-12 text-amber-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              Aucun abonnement actif
            </h2>
            <p className="text-white/60 text-center">
              Vous n'avez pas d'abonnement actif. Abonnez-vous pour profiter de tous nos contenus.
            </p>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-black pb-20">
      <div className="w-full h-[200px] lg:h-[300px] relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/20 to-black flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-white mb-2">Mon Abonnement</h1>
            <p className="text-white/60 max-w-2xl mx-auto">
              Gérez votre abonnement StreamFlix et accédez à tous nos contenus exclusifs
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 relative -mt-10 z-10">
        <Card className="bg-black/80 backdrop-blur-sm border-white/10 shadow-xl overflow-hidden">
          <CardContent className="pt-6">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="h-12 w-12 text-primary animate-spin mb-4" />
                <p className="text-white/60">Chargement de vos informations d'abonnement...</p>
              </div>
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-12">
                <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
                <p className="text-white/60 mb-4">{error}</p>
                <Button onClick={() => window.location.reload()}>Réessayer</Button>
              </div>
            ) : subscriptionData && subscriptionData.status === 'active' ? (
              renderSubscriptionStatus()
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold text-white mb-2">
                        Abonnez-vous à StreamFlix
                      </h2>
                      <p className="text-white/60">
                        Profitez de tous nos contenus exclusifs pour seulement 2,99 € par mois.
                      </p>
                    </div>
                    
                    <ul className="space-y-3">
                      <li className="flex">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-white/80">Accès à tous les films et séries</span>
                      </li>
                      <li className="flex">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-white/80">Plus de 100 chaînes en direct</span>
                      </li>
                      <li className="flex">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-white/80">Qualité HD et 4K</span>
                      </li>
                      <li className="flex">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-white/80">Sans engagement</span>
                      </li>
                      <li className="flex">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-white/80">Annulez à tout moment</span>
                      </li>
                    </ul>
                    
                    <div className="pt-4">
                      <Button 
                        className="w-full bg-gradient-to-br from-primary to-purple-600 hover:brightness-110 transition-all duration-300"
                        size="lg"
                        onClick={handleStartSubscription}
                        disabled={loading}
                      >
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CreditCard className="mr-2 h-4 w-4" />}
                        S'abonner pour 2,99 € / mois
                      </Button>
                      <p className="text-white/40 text-xs mt-2 text-center">
                        Le paiement sera traité par Stripe. Des conditions s'appliquent.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gradient-to-br from-primary/20 to-violet-900/20 rounded-xl p-6 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-4">Pourquoi s'abonner ?</h3>
                    <p className="text-white/70 mb-6">
                      StreamFlix vous offre une expérience de streaming inégalée avec un contenu exclusif et des fonctionnalités premium.
                    </p>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-black/30 backdrop-blur-sm rounded-lg p-4">
                        <h4 className="font-semibold text-white mb-1">Films Exclusifs</h4>
                        <p className="text-white/60 text-sm">Accédez à notre bibliothèque complète de films</p>
                      </div>
                      <div className="bg-black/30 backdrop-blur-sm rounded-lg p-4">
                        <h4 className="font-semibold text-white mb-1">Séries Complètes</h4>
                        <p className="text-white/60 text-sm">Toutes les saisons de vos séries préférées</p>
                      </div>
                      <div className="bg-black/30 backdrop-blur-sm rounded-lg p-4">
                        <h4 className="font-semibold text-white mb-1">TV en Direct</h4>
                        <p className="text-white/60 text-sm">Plus de 100 chaînes TV en streaming</p>
                      </div>
                      <div className="bg-black/30 backdrop-blur-sm rounded-lg p-4">
                        <h4 className="font-semibold text-white mb-1">Support 4K</h4>
                        <p className="text-white/60 text-sm">Qualité maximale sur tous vos appareils</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <div className="bg-black/50 backdrop-blur-sm rounded-lg p-4">
                      <p className="text-white font-medium mb-2">Abonnement sans engagement</p>
                      <p className="text-white/60 text-sm">
                        Profitez de StreamFlix Premium sans engagement. Vous pouvez annuler à tout moment.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}