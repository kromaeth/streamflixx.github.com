import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/hooks/use-auth';
import { Logo } from '@/components/ui/icons';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

// Login schema
const loginSchema = z.object({
  username: z.string().min(1, 'Nom d\'utilisateur requis'),
  password: z.string().min(1, 'Mot de passe requis'),
});

// Registration schema
const registerSchema = z.object({
  username: z.string().min(3, 'Le nom d\'utilisateur doit contenir au moins 3 caractères'),
  handle: z.string()
    .min(3, 'L\'identifiant @handle doit contenir au moins 3 caractères')
    .max(30, 'L\'identifiant @handle ne peut pas dépasser 30 caractères')
    .regex(/^[a-z0-9_]+$/, 'L\'identifiant @handle ne peut contenir que des lettres minuscules, chiffres et underscores')
    .transform(val => val.toLowerCase()),
  email: z.string().email('Email invalide'),
  password: z.string().min(6, 'Le mot de passe doit contenir au moins 6 caractères'),
  confirmPassword: z.string().min(1, 'Veuillez confirmer votre mot de passe'),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Les mots de passe ne correspondent pas',
  path: ['confirmPassword'],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<string>('login');
  const [location, navigate] = useLocation();
  const { user, loginMutation, registerMutation, isLoading } = useAuth();
  
  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);
  
  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });
  
  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      handle: '',
      email: '',
      password: '',
      confirmPassword: '',
    },
  });
  
  // Handle login submission
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };
  
  // Handle register submission
  const onRegisterSubmit = (data: RegisterFormValues) => {
    // Remove confirmPassword before sending to API
    const { confirmPassword, ...registerData } = data;
    registerMutation.mutate(registerData);
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-black/30">
      {/* Auth Form Side */}
      <div className="w-full md:w-1/2 flex items-center justify-center p-4 md:p-10 backdrop-blur-sm">
        <div className="w-full max-w-md">
          <div className="text-center mb-8 relative">
            <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-gradient-to-br from-primary to-primary/40 rounded-full blur-3xl opacity-20"></div>
            <Logo className="h-12 w-auto bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent mx-auto mb-4" />
            <h1 className="text-3xl font-bold bg-gradient-to-br from-white to-white/70 bg-clip-text text-transparent">Bienvenue sur StreamFlix</h1>
            <p className="text-muted-foreground mt-2">
              Votre plateforme de streaming IPTV
            </p>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-black/40 p-1 rounded-full">
              <TabsTrigger value="login" className="rounded-full text-sm">Connexion</TabsTrigger>
              <TabsTrigger value="register" className="rounded-full text-sm">Inscription</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login" className="animate-in fade-in-50 zoom-in-95">
              <Card className="bg-black/40 border-none backdrop-blur-md shadow-xl">
                <CardHeader>
                  <CardTitle className="text-xl text-white">Connexion</CardTitle>
                  <CardDescription className="text-gray-400">
                    Entrez vos identifiants pour accéder à votre compte
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Nom d'utilisateur</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="votre_nom" 
                                {...field} 
                                className="bg-black/40 border-gray-800 focus:border-primary/70"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Mot de passe</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                                className="bg-black/40 border-gray-800 focus:border-primary/70"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full mt-6 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white border-none"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Connexion en cours...
                          </>
                        ) : 'Se connecter'}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-center">
                  <Button 
                    variant="link" 
                    onClick={() => setActiveTab('register')}
                    className="text-gray-400 hover:text-primary"
                  >
                    Pas encore de compte? S'inscrire
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="register" className="animate-in fade-in-50 zoom-in-95">
              <Card className="bg-black/40 border-none backdrop-blur-md shadow-xl">
                <CardHeader>
                  <CardTitle className="text-xl text-white">Inscription</CardTitle>
                  <CardDescription className="text-gray-400">
                    Créez un nouveau compte pour accéder à la plateforme
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Nom d'utilisateur</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="votre_nom" 
                                {...field} 
                                className="bg-black/40 border-gray-800 focus:border-primary/70"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="handle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Identifiant @handle</FormLabel>
                            <FormControl>
                              <div className="flex">
                                <div className="flex items-center justify-center px-3 bg-primary/10 border-l border-y border-gray-800 rounded-l-md text-primary">
                                  @
                                </div>
                                <Input 
                                  placeholder="pseudo" 
                                  {...field} 
                                  className="bg-black/40 border-gray-800 focus:border-primary/70 rounded-l-none"
                                />
                              </div>
                            </FormControl>
                            <FormDescription className="text-xs text-gray-500">
                              Votre identifiant unique pour les invitations et le visionnage en groupe
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Email</FormLabel>
                            <FormControl>
                              <Input 
                                type="email" 
                                placeholder="votre@email.com" 
                                {...field} 
                                className="bg-black/40 border-gray-800 focus:border-primary/70"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Mot de passe</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                                className="bg-black/40 border-gray-800 focus:border-primary/70"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={registerForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Confirmer mot de passe</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                                className="bg-black/40 border-gray-800 focus:border-primary/70"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full mt-6 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white border-none"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Inscription en cours...
                          </>
                        ) : 'S\'inscrire'}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-center">
                  <Button 
                    variant="link" 
                    onClick={() => setActiveTab('login')}
                    className="text-gray-400 hover:text-primary"
                  >
                    Déjà un compte? Se connecter
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Hero Side */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-black via-primary/10 to-black items-center justify-center p-8 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-80 h-80 bg-primary/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-80 h-80 bg-purple-700/10 rounded-full blur-3xl"></div>
        </div>
        <div className="relative max-w-lg text-center z-10 backdrop-blur-sm bg-black/20 p-8 rounded-xl border border-white/5 shadow-2xl">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            Découvrez un monde de divertissement
          </h1>
          <p className="text-xl mb-8 text-gray-300">
            Films, séries et chaînes TV en streaming illimité sur StreamFlix
          </p>
          <ul className="space-y-5 text-left mx-auto max-w-md">
            <li className="flex items-center">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/20 mr-4">
                <svg className="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <span className="text-gray-200 text-lg">Accès à des milliers de films et séries</span>
            </li>
            <li className="flex items-center">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/20 mr-4">
                <svg className="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <span className="text-gray-200 text-lg">Chaînes TV en direct du monde entier</span>
            </li>
            <li className="flex items-center">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/20 mr-4">
                <svg className="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <span className="text-gray-200 text-lg">Interface moderne et intuitive</span>
            </li>
            <li className="flex items-center">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/20 mr-4">
                <svg className="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <span className="text-gray-200 text-lg">Compatible sur tous vos appareils</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
