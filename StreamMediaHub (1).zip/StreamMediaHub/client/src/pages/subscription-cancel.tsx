import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Home, AlertTriangle } from 'lucide-react';

export default function SubscriptionCancelPage() {
  const [_, setLocation] = useLocation();
  return (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-gray-900 via-black to-black">
      <div className="container mx-auto px-4">
        <Card className="max-w-md mx-auto bg-black/80 backdrop-blur-sm border-white/10">
          <CardContent className="pt-6 text-center">
            <div className="flex justify-center mb-6">
              <div className="h-20 w-20 bg-amber-500/20 rounded-full flex items-center justify-center">
                <AlertTriangle className="h-10 w-10 text-amber-500" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-white mb-3">Abonnement Annulé</h1>
            <p className="text-white/70 mb-6">
              Votre demande d'annulation d'abonnement a bien été prise en compte. 
              Vous aurez accès à StreamFlix Premium jusqu'à la fin de votre période en cours.
            </p>
            <div className="space-y-3">
              <Button 
                className="w-full"
                onClick={() => setLocation('/subscription')}
              >
                Gérer mon abonnement
              </Button>
              <Button 
                variant="outline" 
                className="w-full border-white/10"
                onClick={() => setLocation('/')}
              >
                <Home className="mr-2 h-5 w-5" />
                Retour à l'accueil
              </Button>
            </div>
          </CardContent>
          <CardFooter className="border-t border-white/10 flex justify-center bg-black/50 flex-col text-center space-y-1">
            <p className="text-white/40 text-xs">
              Vous avez changé d'avis ?
            </p>
            <p className="text-white/60 text-xs">
              Vous pouvez réactiver votre abonnement depuis votre espace personnel.
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}