import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./hooks/use-auth";
import { WatchTogetherProvider } from "./hooks/use-watch-together";
import { ProtectedRoute } from "./lib/protected-route";
import { SubscriptionRoute } from "./lib/subscription-route";

import HomePage from "@/pages/home-page";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import TvPage from "@/pages/tv-page";
import MoviesPage from "@/pages/movies-page";
import SeriesPage from "@/pages/series-page";
import SearchPage from "@/pages/search-page";
import SubscriptionPage from "@/pages/subscription-page";
import SubscriptionSuccessPage from "@/pages/subscription-success";
import SubscriptionCancelPage from "@/pages/subscription-cancel";
import WatchTogetherPage from "@/pages/watch-together-page";
import AdminDashboard from "@/pages/admin/dashboard";
import ManageMovies from "@/pages/admin/manage-movies";
import ManageSeries from "@/pages/admin/manage-series";
import ManageChannels from "@/pages/admin/manage-channels";
import ManageUsers from "@/pages/admin/manage-users";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={HomePage} />
      {/* Routes qui nécessitent un abonnement actif */}
      <SubscriptionRoute path="/tv" component={TvPage} />
      <SubscriptionRoute path="/movies" component={MoviesPage} />
      <SubscriptionRoute path="/series" component={SeriesPage} />
      {/* Routes qui ne nécessitent pas d'abonnement, seulement l'authentification */}
      <ProtectedRoute path="/search" component={SearchPage} />
      <ProtectedRoute path="/subscription" component={SubscriptionPage} />
      <ProtectedRoute path="/subscription/success" component={SubscriptionSuccessPage} />
      <ProtectedRoute path="/subscription/cancel" component={SubscriptionCancelPage} />
      <SubscriptionRoute path="/watch-together/:mediaId?" component={WatchTogetherPage} />
      {/* Routes administrateur */}
      <ProtectedRoute path="/admin" component={AdminDashboard} />
      <ProtectedRoute path="/admin/movies" component={ManageMovies} />
      <ProtectedRoute path="/admin/series" component={ManageSeries} />
      <ProtectedRoute path="/admin/channels" component={ManageChannels} />
      <ProtectedRoute path="/admin/users" component={ManageUsers} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <WatchTogetherProvider>
          <Router />
          <Toaster />
        </WatchTogetherProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
