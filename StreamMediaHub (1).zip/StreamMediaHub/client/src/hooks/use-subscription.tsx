import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

export interface SubscriptionData {
  status: 'active' | 'canceled' | 'none';
  isTrialing?: boolean;
  cancelAtPeriodEnd?: boolean;
  nextBillingDate?: string;
  trialEndDate?: string;
  message?: string;
}

export function useSubscription() {
  const { user } = useAuth();
  
  const {
    data: subscription,
    isLoading,
    error,
    refetch
  } = useQuery<SubscriptionData>({
    queryKey: ['/api/subscription'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/subscription');
      return await res.json();
    },
    enabled: !!user, // Only run if user is logged in
  });

  // Helper to check if subscription is active
  const hasActiveSubscription = subscription?.status === 'active';

  return {
    subscription,
    isLoading,
    error,
    hasActiveSubscription,
    refetch
  };
}