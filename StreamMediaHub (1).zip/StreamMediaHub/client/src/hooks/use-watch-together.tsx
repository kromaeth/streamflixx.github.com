import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

// Types pour l'invitation
export interface WatchInvitation {
  id: number;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
  createdAt: string;
  expiresAt: string;
  senderId: number;
  receiverId: number;
  mediaId: number;
  message: string;
  sender?: {
    id: number;
    username: string;
    handle: string;
  };
  receiver?: {
    id: number;
    username: string;
    handle: string;
  };
  media?: {
    id: number;
    title: string;
    thumbnailUrl: string;
    type: string;
  };
}

// Types pour la session de visionnage
export interface WatchSession {
  id: number;
  status: 'active' | 'paused' | 'ended';
  currentTime: number;
  createdAt: string;
  mediaId: number;
  creatorId: number;
  invitationId?: number;
  media?: {
    id: number;
    title: string;
    thumbnailUrl: string;
    type: string;
    contentUrl: string;
  };
  creator?: {
    id: number;
    username: string;
    handle: string;
  };
}

// Données du participant pour la session de visionnage
export interface Participant {
  id: number;
  username: string;
  handle: string;
  isConnected: boolean;
}

// Type de message WebSocket pour mise à jour de l'état du lecteur
export interface PlayerStateMessage {
  type: 'player_state';
  action: 'play' | 'pause' | 'seek';
  currentTime: number;
  userId: number;
  timestamp: string;
}

// Type de message WebSocket pour le chat
export interface ChatMessage {
  type: 'chat';
  message: string;
  userId: number;
  timestamp: string;
}

// Type pour les messages utilisateur entrant/sortant
export interface UserMessage {
  type: 'user_joined' | 'user_left';
  userId: number;
  timestamp: string;
}

type WatchTogetherContextType = {
  // Invitations
  receivedInvitations: WatchInvitation[];
  sentInvitations: WatchInvitation[];
  isLoadingInvitations: boolean;
  searchUserByHandle: UseMutationResult<any, Error, string>;
  sendInvitation: UseMutationResult<WatchInvitation, Error, { receiverId: number; mediaId: number; message?: string }>;
  respondToInvitation: UseMutationResult<any, Error, { invitationId: number; status: 'accepted' | 'declined' }>;
  
  // Sessions
  activeSessions: WatchSession[];
  isLoadingSessions: boolean;
  
  // Session courant et participants
  currentSession: WatchSession | null;
  participants: Participant[];
  chatMessages: (ChatMessage & { senderName?: string })[];
  isConnectedToSession: boolean;
  
  // Fonctions de contrôle de session
  joinSession: (sessionId: number) => Promise<void>;
  leaveSession: () => void;
  playMedia: () => void;
  pauseMedia: () => void;
  seekMedia: (time: number) => void;
  sendChatMessage: (message: string) => void;
  
  // État du lecteur partagé
  isPlaying: boolean;
  currentTime: number;
};

export const WatchTogetherContext = createContext<WatchTogetherContextType | null>(null);

export function WatchTogetherProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const { user } = useAuth();
  
  // États pour les invitations
  const [receivedInvitations, setReceivedInvitations] = useState<WatchInvitation[]>([]);
  const [sentInvitations, setSentInvitations] = useState<WatchInvitation[]>([]);
  
  // États pour les sessions
  const [activeSessions, setActiveSessions] = useState<WatchSession[]>([]);
  const [currentSession, setCurrentSession] = useState<WatchSession | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [chatMessages, setChatMessages] = useState<(ChatMessage & { senderName?: string })[]>([]);
  
  // États pour le WebSocket
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnectedToSession, setIsConnectedToSession] = useState(false);
  
  // États pour le lecteur
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  
  // Récupérer les invitations reçues
  const { 
    isLoading: isLoadingReceivedInvitations,
    refetch: refetchReceivedInvitations
  } = useQuery({ 
    queryKey: ['/api/watch-invitations/received'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/watch-invitations/received');
      const data = await res.json();
      setReceivedInvitations(data);
      return data;
    },
    enabled: !!user
  });
  
  // Récupérer les invitations envoyées
  const {
    isLoading: isLoadingSentInvitations,
    refetch: refetchSentInvitations
  } = useQuery({
    queryKey: ['/api/watch-invitations/sent'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/watch-invitations/sent');
      const data = await res.json();
      setSentInvitations(data);
      return data;
    },
    enabled: !!user
  });
  
  // Récupérer les sessions actives
  const {
    isLoading: isLoadingSessions,
    refetch: refetchSessions
  } = useQuery({
    queryKey: ['/api/watch-sessions/active'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/watch-sessions/active');
      const data = await res.json();
      setActiveSessions(data);
      return data;
    },
    enabled: !!user
  });
  
  // Mutation pour rechercher un utilisateur par son handle
  const searchUserByHandle = useMutation({
    mutationFn: async (handle: string) => {
      const res = await apiRequest('GET', `/api/users/handle/${handle}`);
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Utilisateur non trouvé",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Mutation pour envoyer une invitation
  const sendInvitation = useMutation({
    mutationFn: async (data: { receiverId: number; mediaId: number; message?: string }) => {
      const res = await apiRequest('POST', '/api/watch-invitations', data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Invitation envoyée",
        description: "Votre invitation a été envoyée avec succès.",
      });
      refetchSentInvitations();
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur d'envoi",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Mutation pour répondre à une invitation
  const respondToInvitation = useMutation({
    mutationFn: async ({ invitationId, status }: { invitationId: number; status: 'accepted' | 'declined' }) => {
      const res = await apiRequest('PATCH', `/api/watch-invitations/${invitationId}/respond`, { status });
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.session) {
        toast({
          title: "Invitation acceptée",
          description: "Vous avez rejoint la session de visionnage.",
        });
        setCurrentSession(data.session);
        // Ajouter le créateur comme participant
        if (data.session.creator) {
          setParticipants([
            {
              id: data.session.creator.id,
              username: data.session.creator.username,
              handle: data.session.creator.handle,
              isConnected: false
            }
          ]);
        }
        // Et l'utilisateur actuel
        if (user) {
          setParticipants(prev => [
            ...prev,
            {
              id: user.id,
              username: user.username,
              handle: user.handle || '',
              isConnected: true
            }
          ]);
        }
        // Se connecter automatiquement à la session
        joinSession(data.session.id);
      } else {
        toast({
          title: "Invitation refusée",
          description: "Vous avez refusé l'invitation.",
        });
      }
      refetchReceivedInvitations();
      refetchSessions();
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur de réponse",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Connecter à une session de visionnage
  const joinSession = async (sessionId: number) => {
    if (!user) {
      toast({
        title: "Erreur de connexion",
        description: "Vous devez être connecté pour rejoindre une session.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // Trouver la session dans la liste des sessions actives
      const session = activeSessions.find(s => s.id === sessionId);
      if (!session) {
        throw new Error("Session non trouvée");
      }
      
      setCurrentSession(session);
      
      // Initialiser la liste des participants
      const initialParticipants: Participant[] = [];
      if (session.creator) {
        initialParticipants.push({
          id: session.creator.id,
          username: session.creator.username,
          handle: session.creator.handle,
          isConnected: session.creator.id === user.id // Le créateur est-il l'utilisateur actuel?
        });
      }
      // Ajouter l'utilisateur actuel s'il n'est pas déjà ajouté
      if (!initialParticipants.some(p => p.id === user.id)) {
        initialParticipants.push({
          id: user.id,
          username: user.username,
          handle: user.handle || '',
          isConnected: true
        });
      }
      
      setParticipants(initialParticipants);
      
      // Initialiser le WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        console.log('WebSocket connecté');
        // Envoyer un message d'initialisation
        ws.send(JSON.stringify({
          type: 'init',
          sessionId,
          userId: user.id
        }));
      };
      
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          // Confirmation d'initialisation
          if (data.type === 'init_confirmed') {
            setIsConnectedToSession(true);
            toast({
              title: "Connexion établie",
              description: "Vous êtes maintenant connecté à la session de visionnage.",
            });
            
            // Initialiser l'état du lecteur
            setCurrentTime(session.currentTime || 0);
            setIsPlaying(session.status === 'active');
          }
          
          // Un utilisateur a rejoint la session
          else if (data.type === 'user_joined') {
            const joinedUserId = data.userId;
            // Mettre à jour l'état de connexion du participant
            setParticipants(prev => prev.map(p => 
              p.id === joinedUserId ? { ...p, isConnected: true } : p
            ));
            
            // Trouver le nom de l'utilisateur
            const participant = participants.find(p => p.id === joinedUserId);
            if (participant) {
              toast({
                title: "Nouvelle connexion",
                description: `${participant.username} a rejoint la session.`,
              });
            }
          }
          
          // Un utilisateur a quitté la session
          else if (data.type === 'user_left') {
            const leftUserId = data.userId;
            // Mettre à jour l'état de connexion du participant
            setParticipants(prev => prev.map(p => 
              p.id === leftUserId ? { ...p, isConnected: false } : p
            ));
            
            // Trouver le nom de l'utilisateur
            const participant = participants.find(p => p.id === leftUserId);
            if (participant) {
              toast({
                title: "Déconnexion",
                description: `${participant.username} a quitté la session.`,
              });
            }
          }
          
          // Mise à jour de l'état du lecteur
          else if (data.type === 'player_state') {
            if (data.action === 'play') {
              setIsPlaying(true);
            } else if (data.action === 'pause') {
              setIsPlaying(false);
            }
            
            if (data.currentTime !== undefined) {
              setCurrentTime(data.currentTime);
            }
            
            // Trouver le nom de l'utilisateur
            const participant = participants.find(p => p.id === data.userId);
            if (participant) {
              toast({
                title: "Lecture synchronisée",
                description: `${participant.username} a ${data.action === 'play' ? 'lancé' : 'mis en pause'} la lecture.`,
              });
            }
          }
          
          // Message de chat
          else if (data.type === 'chat') {
            // Trouver le nom de l'expéditeur
            const sender = participants.find(p => p.id === data.userId);
            setChatMessages(prev => [...prev, { 
              ...data,
              senderName: sender?.username
            }]);
          }
          
          // Message d'erreur
          else if (data.type === 'error') {
            toast({
              title: "Erreur de session",
              description: data.message,
              variant: "destructive",
            });
          }
        } catch (error) {
          console.error('Erreur lors du traitement du message WebSocket:', error);
        }
      };
      
      ws.onerror = (error) => {
        console.error('Erreur WebSocket:', error);
        toast({
          title: "Erreur de connexion",
          description: "Impossible de se connecter à la session.",
          variant: "destructive",
        });
        setIsConnectedToSession(false);
      };
      
      ws.onclose = () => {
        console.log('WebSocket fermé');
        setIsConnectedToSession(false);
        toast({
          title: "Déconnexion",
          description: "Vous avez été déconnecté de la session.",
        });
      };
      
      setSocket(ws);
      
    } catch (error) {
      console.error('Erreur lors de la connexion à la session:', error);
      toast({
        title: "Erreur de connexion",
        description: error instanceof Error ? error.message : "Erreur inconnue",
        variant: "destructive",
      });
    }
  };
  
  // Quitter une session de visionnage
  const leaveSession = () => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.close();
    }
    setSocket(null);
    setCurrentSession(null);
    setParticipants([]);
    setChatMessages([]);
    setIsConnectedToSession(false);
    setIsPlaying(false);
    setCurrentTime(0);
  };
  
  // Fonctions de contrôle du lecteur
  const playMedia = () => {
    if (socket && socket.readyState === WebSocket.OPEN && currentSession) {
      socket.send(JSON.stringify({
        type: 'player_state',
        action: 'play',
        currentTime,
        sessionId: currentSession.id,
        userId: user?.id
      }));
      setIsPlaying(true);
    }
  };
  
  const pauseMedia = () => {
    if (socket && socket.readyState === WebSocket.OPEN && currentSession) {
      socket.send(JSON.stringify({
        type: 'player_state',
        action: 'pause',
        currentTime,
        sessionId: currentSession.id,
        userId: user?.id
      }));
      setIsPlaying(false);
    }
  };
  
  const seekMedia = (time: number) => {
    if (socket && socket.readyState === WebSocket.OPEN && currentSession) {
      socket.send(JSON.stringify({
        type: 'player_state',
        action: isPlaying ? 'play' : 'pause',
        currentTime: time,
        sessionId: currentSession.id,
        userId: user?.id
      }));
      setCurrentTime(time);
    }
  };
  
  // Envoyer un message de chat
  const sendChatMessage = (message: string) => {
    if (socket && socket.readyState === WebSocket.OPEN && currentSession && user) {
      socket.send(JSON.stringify({
        type: 'chat',
        message,
        sessionId: currentSession.id,
        userId: user.id
      }));
      
      // Ajouter le message à la liste locale (sans attendre l'écho)
      setChatMessages(prev => [...prev, { 
        type: 'chat',
        message,
        userId: user.id,
        timestamp: new Date().toISOString(),
        senderName: user.username
      }]);
    }
  };
  
  // Nettoyer la connexion WebSocket lors du démontage
  useEffect(() => {
    return () => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [socket]);
  
  return (
    <WatchTogetherContext.Provider
      value={{
        // Invitations
        receivedInvitations,
        sentInvitations,
        isLoadingInvitations: isLoadingReceivedInvitations || isLoadingSentInvitations,
        searchUserByHandle,
        sendInvitation,
        respondToInvitation,
        
        // Sessions
        activeSessions,
        isLoadingSessions,
        
        // Session courante et participants
        currentSession,
        participants,
        chatMessages,
        isConnectedToSession,
        
        // Fonctions de contrôle de session
        joinSession,
        leaveSession,
        playMedia,
        pauseMedia,
        seekMedia,
        sendChatMessage,
        
        // État du lecteur partagé
        isPlaying,
        currentTime
      }}
    >
      {children}
    </WatchTogetherContext.Provider>
  );
}

export function useWatchTogether() {
  const context = useContext(WatchTogetherContext);
  if (!context) {
    throw new Error("useWatchTogether must be used within a WatchTogetherProvider");
  }
  return context;
}