import { useAuth } from "@/hooks/use-auth";
import { useSubscription } from "@/hooks/use-subscription";
import { Redirect, Route } from "wouter";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CreditCard } from "lucide-react";
import { Link } from "wouter";

export function SubscriptionRoute({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) {
  const { user, isLoading: authLoading } = useAuth();
  const { hasActiveSubscription, isLoading: subscriptionLoading } = useSubscription();
  
  const isLoading = authLoading || subscriptionLoading;

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 via-black to-black">
          <div className="flex flex-col items-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
            <p className="text-white/70">Vérification de votre abonnement...</p>
          </div>
        </div>
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  if (!hasActiveSubscription) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 via-black to-black">
          <Card className="max-w-md mx-auto bg-black/80 backdrop-blur-sm border-white/10 w-full">
            <CardContent className="p-6">
              <div className="text-center space-y-4 mb-6">
                <h1 className="text-2xl font-bold text-white">Contenu Premium</h1>
                <p className="text-white/70">
                  Ce contenu est réservé aux membres avec un abonnement actif.
                  Abonnez-vous pour débloquer tous nos contenus exclusifs.
                </p>
              </div>
              
              <div className="flex flex-col space-y-3">
                <Button 
                  className="bg-gradient-to-br from-primary to-purple-600 hover:brightness-110 w-full"
                  asChild
                >
                  <Link href="/subscription">
                    <CreditCard className="mr-2 h-4 w-4" />
                    S'abonner maintenant
                  </Link>
                </Button>
                
                <Button
                  variant="outline"
                  className="border-white/10 hover:bg-white/5"
                  asChild
                >
                  <Link href="/">
                    Retour à l'accueil
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </Route>
    );
  }

  return <Component />;
}