import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  handle: text("handle").notNull().unique(), // @ identifiant unique
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  subscriptionStatus: text("subscription_status").default("inactive"),
  trialEndsAt: timestamp("trial_ends_at"),
  subscriptionEndsAt: timestamp("subscription_ends_at"),
  status: text("status").default("offline"), // en ligne, hors ligne, occupé, etc.
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  handle: true,
  password: true,
  email: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const mediaTypes = ["movie", "series", "channel"] as const;
export type MediaType = typeof mediaTypes[number];

export const media = pgTable("media", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type", { enum: mediaTypes }).notNull(),
  genre: text("genre").notNull(),
  year: integer("year"),
  thumbnailUrl: text("thumbnail_url").notNull(),
  contentUrl: text("content_url").notNull(),
  seasons: integer("seasons"),
  featured: boolean("featured").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMediaSchema = createInsertSchema(media).omit({
  id: true,
  createdAt: true,
});

export type InsertMedia = z.infer<typeof insertMediaSchema>;
export type Media = typeof media.$inferSelect;

// Tables pour le visionnage simultané
export const watchInvitations = pgTable("watch_invitations", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").references(() => users.id).notNull(),
  receiverId: integer("receiver_id").references(() => users.id).notNull(),
  mediaId: integer("media_id").references(() => media.id).notNull(),
  status: text("status", { enum: ["pending", "accepted", "declined", "expired"] }).default("pending").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const insertWatchInvitationSchema = createInsertSchema(watchInvitations).omit({
  id: true,
  createdAt: true,
  status: true,
});

export type InsertWatchInvitation = z.infer<typeof insertWatchInvitationSchema>;
export type WatchInvitation = typeof watchInvitations.$inferSelect;

export const watchSessions = pgTable("watch_sessions", {
  id: serial("id").primaryKey(),
  invitationId: integer("invitation_id").references(() => watchInvitations.id),
  mediaId: integer("media_id").references(() => media.id).notNull(),
  creatorId: integer("creator_id").references(() => users.id).notNull(),
  currentTime: integer("current_time").default(0).notNull(),  // Temps en secondes
  status: text("status", { enum: ["active", "paused", "ended"] }).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),
});

export const watchSessionParticipants = pgTable("watch_session_participants", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").references(() => watchSessions.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  leftAt: timestamp("left_at"),
  status: text("status", { enum: ["active", "inactive"] }).default("active").notNull(),
});
