import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertMediaSchema } from "@shared/schema";
import { z } from "zod";
import Stripe from "stripe";
import { WebSocketServer, WebSocket } from "ws";

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn("Attention: STRIPE_SECRET_KEY n'est pas définie. Les fonctionnalités de paiement ne fonctionneront pas correctement.");
}

// La version de l'API Stripe à utiliser
const STRIPE_API_VERSION = "2025-03-31.basil" as const;

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: STRIPE_API_VERSION,
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // ==== Search Routes ====
  
  // Recherche avancée
  app.get('/api/search', async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const type = req.query.type as string;
      const genre = req.query.genre as string;
      const year = req.query.year ? parseInt(req.query.year as string) : undefined;
      const sortBy = req.query.sortBy as 'title' | 'year' | 'createdAt';
      const sortOrder = req.query.sortOrder as 'asc' | 'desc';
      
      // Validation des paramètres
      if (year && isNaN(year)) {
        return res.status(400).json({ message: "L'année doit être un nombre valide" });
      }
      
      const filters = {
        type,
        genre,
        year,
        sortBy,
        sortOrder
      };
      
      const results = await storage.searchMedia(query, filters);
      res.json(results);
    } catch (error: any) {
      console.error('Erreur lors de la recherche:', error.message);
      res.status(500).json({ message: "Erreur lors de la recherche", error: error.message });
    }
  });

  // ==== Media Routes ====
  
  // Get all media
  app.get("/api/media", async (req, res) => {
    try {
      const media = await storage.getAllMedia();
      res.json(media);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des médias" });
    }
  });

  // Get featured media
  app.get("/api/media/featured", async (req, res) => {
    try {
      const featuredMedia = await storage.getFeaturedMedia();
      if (!featuredMedia) {
        return res.status(404).json({ message: "Aucun contenu à la une trouvé" });
      }
      res.json(featuredMedia);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération du contenu à la une" });
    }
  });

  // Get popular media
  app.get("/api/media/popular", async (req, res) => {
    try {
      const popularMedia = await storage.getPopularMedia();
      res.json(popularMedia);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des médias populaires" });
    }
  });

  // Get new series
  app.get("/api/media/series/new", async (req, res) => {
    try {
      const newSeries = await storage.getNewSeries();
      res.json(newSeries);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des nouvelles séries" });
    }
  });

  // Get media by type (movie, series, channel)
  app.get("/api/media/:type", async (req, res) => {
    try {
      const type = req.params.type;
      const validTypes = ["movie", "series", "channel"];
      
      if (!validTypes.includes(type)) {
        return res.status(400).json({ message: "Type de média invalide" });
      }
      
      const mediaList = await storage.getMediaByType(type);
      res.json(mediaList);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des médias" });
    }
  });

  // Get media by ID
  app.get("/api/media/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID invalide" });
      }
      
      const mediaItem = await storage.getMedia(id);
      if (!mediaItem) {
        return res.status(404).json({ message: "Média non trouvé" });
      }
      
      res.json(mediaItem);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération du média" });
    }
  });

  // Create media (admin only)
  app.post("/api/media", requireAdmin, async (req, res) => {
    try {
      const validationResult = insertMediaSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: validationResult.error.message });
      }
      
      const newMedia = await storage.createMedia(validationResult.data);
      res.status(201).json(newMedia);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la création du média" });
    }
  });

  // Update media (admin only)
  app.patch("/api/media/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID invalide" });
      }
      
      // Partial validation of update data
      const updateSchema = insertMediaSchema.partial();
      const validationResult = updateSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: validationResult.error.message });
      }
      
      const existingMedia = await storage.getMedia(id);
      if (!existingMedia) {
        return res.status(404).json({ message: "Média non trouvé" });
      }
      
      const updatedMedia = await storage.updateMedia(id, validationResult.data);
      res.json(updatedMedia);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la mise à jour du média" });
    }
  });

  // Delete media (admin only)
  app.delete("/api/media/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID invalide" });
      }
      
      const existingMedia = await storage.getMedia(id);
      if (!existingMedia) {
        return res.status(404).json({ message: "Média non trouvé" });
      }
      
      await storage.deleteMedia(id);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression du média" });
    }
  });

  // ==== User Management Routes (admin only) ====
  
  // Get all users
  app.get("/api/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des utilisateurs" });
    }
  });

  // Create user (admin only)
  app.post("/api/users", requireAdmin, async (req, res) => {
    try {
      const userSchema = z.object({
        username: z.string().min(3, "Le nom d'utilisateur doit contenir au moins 3 caractères"),
        email: z.string().email("Email invalide"),
        password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
        isAdmin: z.boolean().optional().default(false)
      });
      
      const validationResult = userSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: validationResult.error.message });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(req.body.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Ce nom d'utilisateur est déjà pris" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(req.body.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Cet email est déjà utilisé" });
      }
      
      const newUser = await storage.createUser(req.body);
      res.status(201).json(newUser);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la création de l'utilisateur" });
    }
  });

  // Update user (admin only)
  app.patch("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID invalide" });
      }
      
      const updateSchema = z.object({
        username: z.string().min(3).optional(),
        email: z.string().email().optional(),
        password: z.string().min(6).optional(),
        isAdmin: z.boolean().optional()
      });
      
      const validationResult = updateSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: validationResult.error.message });
      }
      
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      // If username is changed, check if new username already exists
      if (req.body.username && req.body.username !== existingUser.username) {
        const existingUsername = await storage.getUserByUsername(req.body.username);
        if (existingUsername && existingUsername.id !== id) {
          return res.status(400).json({ message: "Ce nom d'utilisateur est déjà pris" });
        }
      }
      
      // If email is changed, check if new email already exists
      if (req.body.email && req.body.email !== existingUser.email) {
        const existingEmail = await storage.getUserByEmail(req.body.email);
        if (existingEmail && existingEmail.id !== id) {
          return res.status(400).json({ message: "Cet email est déjà utilisé" });
        }
      }
      
      const updatedUser = await storage.updateUser(id, req.body);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la mise à jour de l'utilisateur" });
    }
  });

  // Delete user (admin only)
  app.delete("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID invalide" });
      }
      
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      // Don't allow deleting the currently logged-in user
      if (req.user && req.user.id === id) {
        return res.status(400).json({ message: "Vous ne pouvez pas supprimer votre propre compte" });
      }
      
      await storage.deleteUser(id);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression de l'utilisateur" });
    }
  });
  
  // Manage user subscription (admin only)
  app.post("/api/users/:id/subscription", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID invalide" });
      }
      
      const subscriptionSchema = z.object({
        status: z.enum(['active', 'trialing', 'canceled', 'none']),
        trialDays: z.number().min(0).optional()
      });
      
      const validationResult = subscriptionSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: validationResult.error.message });
      }
      
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      const { status, trialDays } = validationResult.data;
      let updatedUser;
      
      if (status === 'trialing' && trialDays) {
        // Set trial period
        updatedUser = await storage.setTrialPeriod(id, trialDays);
      } else if (status === 'active') {
        // Set subscription as active
        updatedUser = await storage.updateSubscriptionStatus(id, 'active');
        
        // Set end date to 1 year from now
        const oneYearFromNow = new Date();
        oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);
        updatedUser = await storage.setSubscriptionEnd(id, oneYearFromNow);
      } else {
        // Set as inactive
        updatedUser = await storage.updateSubscriptionStatus(id, status);
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Erreur lors de la mise à jour de l'abonnement" });
    }
  });

  // ==== Activity Routes ====
  // This is simplified for the demo, just returns mock activities data
  app.get("/api/activities", requireAdmin, (req, res) => {
    const activities = [
      {
        username: "admin",
        action: "Ajout d'un film",
        date: "Il y a 10 minutes",
        status: "success"
      },
      {
        username: "moderator",
        action: "Mise à jour série",
        date: "Il y a 45 minutes",
        status: "success"
      },
      {
        username: "admin",
        action: "Suppression chaîne",
        date: "Il y a 3 heures",
        status: "error"
      }
    ];
    res.json(activities);
  });

  // ==== Stripe Subscription Routes ====

  // Create a subscription
  app.post("/api/subscription", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      // Vérifier si l'utilisateur a déjà un abonnement actif
      if (user && (user.subscriptionStatus === 'active' || user.subscriptionStatus === 'trialing')) {
        return res.status(400).json({ 
          message: "Vous avez déjà un abonnement actif"
        });
      }

      // Créer un client Stripe s'il n'existe pas déjà
      let customerId = user?.stripeCustomerId;
      if (!customerId && user) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.username,
          metadata: {
            userId: user.id.toString()
          }
        });
        
        customerId = customer.id;
        
        // Mettre à jour les informations du client dans notre DB
        await storage.updateUserStripeInfo(user.id, {
          customerId,
          subscriptionId: "" // Sera mis à jour après création de l'abonnement
        });
      }
      
      // Créer une session de paiement
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ['card'],
        mode: 'subscription',
        line_items: [
          {
            price_data: {
              currency: 'eur',
              product_data: {
                name: 'Abonnement StreamFlix Premium',
                description: 'Accédez à tout notre contenu en illimité',
              },
              unit_amount: 299, // 2,99€ en centimes
              recurring: {
                interval: 'month'
              }
            },
            quantity: 1,
          },
        ],
        // Pas de periode dessai gratuite
        success_url: `${req.protocol}://${req.get('host')}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.protocol}://${req.get('host')}/subscription/cancel`,
      });

      res.json({ url: session.url, sessionId: session.id });
    } catch (error: any) {
      console.error('Erreur lors de la création de l\'abonnement:', error.message);
      res.status(500).json({ message: "Erreur lors de la création de l'abonnement" });
    }
  });

  // Route pour créer une session de paiement (pour rester compatible avec notre frontend)
  app.post('/api/create-subscription-session', requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      // Vérifier si l'utilisateur a déjà un abonnement actif
      if (user?.subscriptionStatus === 'active' || user?.subscriptionStatus === 'trialing') {
        return res.status(400).json({ 
          message: "Vous avez déjà un abonnement actif"
        });
      }

      // Créer un client Stripe s'il n'existe pas déjà
      let customerId = user?.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user?.email || '',
          name: user?.username || '',
          metadata: {
            userId: user?.id.toString() || ''
          }
        });
        
        customerId = customer.id;
        
        // Mettre à jour les informations du client dans notre DB
        if (user) {
          await storage.updateUserStripeInfo(user.id, {
            customerId,
            subscriptionId: "" // Sera mis à jour après création de l'abonnement
          });
        }
      }
      
      // Créer une session de paiement
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ['card'],
        mode: 'subscription',
        success_url: `${req.protocol}://${req.get('host')}/subscription-success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.protocol}://${req.get('host')}/subscription-cancel`,
        line_items: [
          {
            price_data: {
              currency: 'eur',
              product_data: {
                name: 'Abonnement StreamFlix Premium',
                description: 'Accédez à tout notre contenu en illimité',
              },
              unit_amount: 299, // 2,99€ en centimes
              recurring: {
                interval: 'month'
              }
            },
            quantity: 1,
          },
        ],
        // Pas de periode dessai gratuite
      });

      res.json({ url: session.url, sessionId: session.id });
    } catch (error: any) {
      console.error('Erreur lors de la création de la session d\'abonnement:', error.message);
      res.status(500).json({ message: "Erreur lors de la création de la session d'abonnement" });
    }
  });
  
  // Vérifier une session d'abonnement après paiement
  app.get('/api/subscription/verify', requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      // Si l'utilisateur a un abonnement, renvoyer ses détails
      if (user?.stripeSubscriptionId) {
        try {
          const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
          
          return res.json({
            status: subscription.status,
            cancelAtPeriodEnd: subscription.cancel_at_period_end,
            currentPeriodEnd: subscription.current_period_end ? new Date(subscription.current_period_end * 1000) : null,
            trialEnd: subscription.trial_end ? new Date(subscription.trial_end * 1000) : null
          });
        } catch (err) {
          console.error('Erreur lors de la récupération de l\'abonnement:', err);
        }
      }
      
      // Par défaut, renvoyer un statut inactif
      return res.json({
        status: 'inactive',
        message: 'Aucun abonnement actif trouvé'
      });
    } catch (error: any) {
      console.error('Erreur lors de la vérification de la session:', error.message);
      res.status(500).json({ message: "Erreur lors de la vérification de la session" });
    }
  });
  
  // Webhook pour gérer les événements Stripe
  app.post('/api/webhook', async (req, res) => {
    const payload = req.body;
    const sig = req.headers['stripe-signature'] as string;

    let event;

    // Cette clé est normalement définie dans les variables d'environnement
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    
    try {
      if (webhookSecret) {
        event = stripe.webhooks.constructEvent(
          payload,
          sig,
          webhookSecret
        );
      } else {
        // Pour le développement, on accepte les événements sans signature
        event = payload;
      }
    } catch (err: any) {
      console.log(`Webhook error: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Gérer les différents événements
    try {
      switch (event.type) {
        case 'customer.subscription.created': {
          const subscription = event.data.object;
          const customerId = subscription.customer as string;
          
          // Trouver l'utilisateur par son customerId
          const users = await storage.getUsers();
          const user = users.find(u => u.stripeCustomerId === customerId);
          
          if (user) {
            // Mettre à jour les informations d'abonnement de l'utilisateur
            await storage.updateUserStripeInfo(user.id, {
              customerId,
              subscriptionId: subscription.id
            });
            
            // Pas de période d'essai
            
            // Mettre à jour le statut de l'abonnement
            await storage.updateSubscriptionStatus(user.id, subscription.status);
          }
          break;
        }
        case 'customer.subscription.updated': {
          const subscription = event.data.object;
          const customerId = subscription.customer as string;
          
          // Trouver l'utilisateur par son customerId
          const users = await storage.getUsers();
          const user = users.find(u => u.stripeCustomerId === customerId);
          
          if (user) {
            // Mettre à jour le statut de l'abonnement
            await storage.updateSubscriptionStatus(user.id, subscription.status);
            
            // Si l'abonnement a une date de fin, la mettre à jour
            if (subscription.cancel_at) {
              await storage.setSubscriptionEnd(user.id, new Date(subscription.cancel_at * 1000));
            }
          }
          break;
        }
        case 'customer.subscription.deleted': {
          const subscription = event.data.object;
          const customerId = subscription.customer as string;
          
          // Trouver l'utilisateur par son customerId
          const users = await storage.getUsers();
          const user = users.find(u => u.stripeCustomerId === customerId);
          
          if (user) {
            // Mettre à jour le statut de l'abonnement
            await storage.updateSubscriptionStatus(user.id, 'canceled');
          }
          break;
        }
        default:
          console.log(`Unhandled event type ${event.type}`);
      }

      res.json({ received: true });
    } catch (error) {
      console.error('Erreur lors du traitement du webhook:', error);
      res.status(500).json({ message: "Erreur lors du traitement du webhook" });
    }
  });

  // Vérifier le statut de l'abonnement
  app.get('/api/subscription', requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      // Si l'utilisateur n'a pas d'abonnement
      if (!user?.stripeSubscriptionId) {
        return res.json({
          status: 'none',
          message: 'Aucun abonnement'
        });
      }
      
      // Si l'utilisateur a un abonnement Stripe, récupérer les détails
      try {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        
        // Déterminer si l'utilisateur est en période d'essai
        const isTrialing = subscription.status === 'trialing';
        
        // Calculer les dates importantes
        let trialEndDate = null;
        if (isTrialing && subscription.trial_end) {
          trialEndDate = new Date(subscription.trial_end * 1000);
        }
        
        let nextBillingDate = null;
        if (subscription.current_period_end) {
          nextBillingDate = new Date(subscription.current_period_end * 1000);
        }
        
        return res.json({
          status: subscription.status,
          isTrialing,
          trialEndDate,
          nextBillingDate,
          plan: {
            amount: (subscription.items.data[0]?.price?.unit_amount || 0) / 100,
            currency: subscription.items.data[0]?.price?.currency || 'eur',
            interval: subscription.items.data[0]?.price?.recurring?.interval || 'month'
          }
        });
      } catch (error) {
        // Si l'abonnement n'existe plus chez Stripe, mettre à jour l'utilisateur
        await storage.updateSubscriptionStatus(user.id, 'canceled');
        
        return res.json({
          status: 'canceled',
          message: 'Abonnement non trouvé ou annulé'
        });
      }
    } catch (error: any) {
      console.error('Erreur lors de la vérification de l\'abonnement:', error.message);
      res.status(500).json({ message: "Erreur lors de la vérification de l'abonnement" });
    }
  });

  // Annuler un abonnement
  app.post('/api/subscription/cancel', requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      // Vérifier si l'utilisateur a un abonnement actif
      if (!user?.stripeSubscriptionId) {
        return res.status(400).json({ 
          message: "Aucun abonnement actif à annuler"
        });
      }
      
      // Annuler l'abonnement à la fin de la période de facturation
      const subscription = await stripe.subscriptions.update(
        user.stripeSubscriptionId,
        { cancel_at_period_end: true }
      );
      
      // Mettre à jour le statut dans la base de données
      if (subscription.cancel_at) {
        await storage.setSubscriptionEnd(user.id, new Date(subscription.cancel_at * 1000));
      }
      
      res.json({
        status: 'canceling',
        message: 'Votre abonnement sera annulé à la fin de la période de facturation',
        endDate: subscription.cancel_at ? new Date(subscription.cancel_at * 1000) : null
      });
    } catch (error: any) {
      console.error('Erreur lors de l\'annulation de l\'abonnement:', error.message);
      
      // Si l'abonnement n'existe plus chez Stripe
      if (error.code === 'resource_missing' && req.user) {
        await storage.updateSubscriptionStatus(req.user.id, 'canceled');
        return res.json({
          status: 'canceled',
          message: 'Abonnement déjà annulé'
        });
      }
      
      res.status(500).json({ message: "Erreur lors de l'annulation de l'abonnement" });
    }
  });

  // ==== Routes Admin ====
  
  // Mettre à jour le statut d'abonnement d'un utilisateur (admin only)
  app.post('/api/admin/update-subscription', requireAdmin, async (req, res) => {
    try {
      const { userId, status, trialDays } = req.body;
      
      if (!userId || !status) {
        return res.status(400).json({ message: "userId et status sont requis" });
      }
      
      // Mise à jour du statut d'abonnement
      await storage.updateSubscriptionStatus(userId, status);
      
      // Si une période d'essai est spécifiée, la mettre à jour
      if (trialDays) {
        await storage.setTrialPeriod(userId, trialDays);
      }
      
      // Récupérer l'utilisateur mis à jour
      const updatedUser = await storage.getUser(userId);
      
      return res.json({
        message: "Abonnement mis à jour avec succès",
        user: updatedUser
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'abonnement:', error);
      return res.status(500).json({ message: "Erreur lors de la mise à jour de l'abonnement" });
    }
  });

  // ==== Watch Together Routes ====

  // Rechercher un utilisateur par son handle
  app.get('/api/users/handle/:handle', requireAuth, async (req, res) => {
    try {
      const handle = req.params.handle;
      // Ne pas permettre de trouver son propre handle
      if (req.user && req.user.handle === handle) {
        return res.status(400).json({ message: "Vous ne pouvez pas vous inviter vous-même" });
      }
      
      const user = await storage.getUserByHandle(handle);
      if (!user) {
        return res.status(404).json({ message: "Aucun utilisateur trouvé avec ce handle" });
      }
      
      // Retourner seulement les informations essentielles
      res.json({
        id: user.id,
        username: user.username,
        handle: user.handle
      });
    } catch (error) {
      console.error('Erreur lors de la recherche d\'utilisateur:', error);
      res.status(500).json({ message: "Erreur lors de la recherche d'utilisateur" });
    }
  });

  // Créer une invitation pour regarder ensemble
  app.post('/api/watch-invitations', requireAuth, async (req, res) => {
    try {
      // Validation du corps de la requête
      const invitationSchema = z.object({
        receiverId: z.number(),
        mediaId: z.number(),
        message: z.string().optional()
      });
      
      const validationResult = invitationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: validationResult.error.message });
      }
      
      // Vérifier si l'utilisateur existe
      const receiver = await storage.getUser(req.body.receiverId);
      if (!receiver) {
        return res.status(404).json({ message: "Destinataire non trouvé" });
      }
      
      // Vérifier si le média existe
      const media = await storage.getMedia(req.body.mediaId);
      if (!media) {
        return res.status(404).json({ message: "Contenu non trouvé" });
      }
      
      // Préparer une date d'expiration (1 heure par défaut)
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 1);
      
      // Créer l'invitation
      const invitation = await storage.createWatchInvitation({
        senderId: req.user!.id,
        receiverId: req.body.receiverId,
        mediaId: req.body.mediaId,
        message: req.body.message || `${req.user!.username} vous invite à regarder "${media.title}" ensemble.`,
        expiresAt
      });
      
      res.status(201).json(invitation);
    } catch (error) {
      console.error('Erreur lors de la création de l\'invitation:', error);
      res.status(500).json({ message: "Erreur lors de la création de l'invitation" });
    }
  });

  // Récupérer mes invitations reçues
  app.get('/api/watch-invitations/received', requireAuth, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentification requise" });
      }
      
      const invitations = await storage.getWatchInvitationsByReceiver(req.user.id);
      
      // Enrichir les données avec les informations sur les expéditeurs et les médias
      const enrichedInvitations = await Promise.all(invitations.map(async (invitation) => {
        const sender = await storage.getUser(invitation.senderId);
        const media = await storage.getMedia(invitation.mediaId);
        
        return {
          ...invitation,
          sender: sender ? {
            id: sender.id,
            username: sender.username,
            handle: sender.handle
          } : null,
          media: media ? {
            id: media.id,
            title: media.title,
            thumbnailUrl: media.thumbnailUrl,
            type: media.type
          } : null
        };
      }));
      
      res.json(enrichedInvitations);
    } catch (error) {
      console.error('Erreur lors de la récupération des invitations:', error);
      res.status(500).json({ message: "Erreur lors de la récupération des invitations" });
    }
  });

  // Récupérer mes invitations envoyées
  app.get('/api/watch-invitations/sent', requireAuth, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentification requise" });
      }
      
      const invitations = await storage.getWatchInvitationsBySender(req.user.id);
      
      // Enrichir les données avec les informations sur les destinataires et les médias
      const enrichedInvitations = await Promise.all(invitations.map(async (invitation) => {
        const receiver = await storage.getUser(invitation.receiverId);
        const media = await storage.getMedia(invitation.mediaId);
        
        return {
          ...invitation,
          receiver: receiver ? {
            id: receiver.id,
            username: receiver.username,
            handle: receiver.handle
          } : null,
          media: media ? {
            id: media.id,
            title: media.title,
            thumbnailUrl: media.thumbnailUrl,
            type: media.type
          } : null
        };
      }));
      
      res.json(enrichedInvitations);
    } catch (error) {
      console.error('Erreur lors de la récupération des invitations:', error);
      res.status(500).json({ message: "Erreur lors de la récupération des invitations" });
    }
  });

  // Répondre à une invitation (accepter ou refuser)
  app.patch('/api/watch-invitations/:id/respond', requireAuth, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentification requise" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID d'invitation invalide" });
      }
      
      const { status } = req.body;
      if (status !== 'accepted' && status !== 'declined') {
        return res.status(400).json({ message: "Statut invalide. Utilisez 'accepted' ou 'declined'" });
      }
      
      const invitation = await storage.getWatchInvitation(id);
      if (!invitation) {
        return res.status(404).json({ message: "Invitation non trouvée" });
      }
      
      // Vérifier que l'utilisateur est bien le destinataire de l'invitation
      if (invitation.receiverId !== req.user.id) {
        return res.status(403).json({ message: "Vous n'êtes pas autorisé à répondre à cette invitation" });
      }
      
      // Vérifier que l'invitation est toujours en attente
      if (invitation.status !== 'pending') {
        return res.status(400).json({ message: `L'invitation a déjà été ${invitation.status === 'accepted' ? 'acceptée' : 'refusée ou expirée'}` });
      }
      
      const updatedInvitation = await storage.updateWatchInvitationStatus(id, status);
      
      // Si l'invitation est acceptée, créer une session de visionnage
      if (status === 'accepted') {
        const session = await storage.createWatchSession({
          mediaId: invitation.mediaId,
          creatorId: invitation.senderId,
          invitationId: invitation.id
        });
        
        // Ajouter le destinataire à la session
        await storage.addParticipantToSession(session.id, invitation.receiverId);
        
        // Retourner l'invitation mise à jour et la session créée
        return res.json({
          invitation: updatedInvitation,
          session
        });
      }
      
      res.json(updatedInvitation);
    } catch (error) {
      console.error('Erreur lors de la réponse à l\'invitation:', error);
      res.status(500).json({ message: "Erreur lors de la réponse à l'invitation" });
    }
  });

  // Récupérer les sessions de visionnage actives de l'utilisateur
  app.get('/api/watch-sessions/active', requireAuth, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentification requise" });
      }
      
      const sessions = await storage.getActiveWatchSessionsByUser(req.user.id);
      
      // Enrichir les données avec les informations sur les médias et les participants
      const enrichedSessions = await Promise.all(sessions.map(async (session) => {
        const media = await storage.getMedia(session.mediaId);
        
        // Pour une première version simplifiée, on ne récupère pas tous les participants
        // mais seulement le créateur
        const creator = await storage.getUser(session.creatorId);
        
        return {
          ...session,
          media: media ? {
            id: media.id,
            title: media.title,
            thumbnailUrl: media.thumbnailUrl,
            type: media.type,
            contentUrl: media.contentUrl
          } : null,
          creator: creator ? {
            id: creator.id,
            username: creator.username,
            handle: creator.handle
          } : null
        };
      }));
      
      res.json(enrichedSessions);
    } catch (error) {
      console.error('Erreur lors de la récupération des sessions:', error);
      res.status(500).json({ message: "Erreur lors de la récupération des sessions de visionnage" });
    }
  });

  // Mettre à jour l'état d'une session (temps, pause, etc.)
  app.patch('/api/watch-sessions/:id/status', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de session invalide" });
      }
      
      const { status, currentTime } = req.body;
      
      const session = await storage.getWatchSession(id);
      if (!session) {
        return res.status(404).json({ message: "Session non trouvée" });
      }
      
      // Mise à jour du temps si fourni
      if (typeof currentTime === 'number') {
        await storage.updateWatchSessionTime(id, currentTime);
      }
      
      // Mise à jour du statut si fourni
      if (status && ['active', 'paused', 'ended'].includes(status)) {
        await storage.updateWatchSessionStatus(id, status);
      }
      
      const updatedSession = await storage.getWatchSession(id);
      res.json(updatedSession);
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la session:', error);
      res.status(500).json({ message: "Erreur lors de la mise à jour de la session" });
    }
  });

  // Terminer une session de visionnage
  app.delete('/api/watch-sessions/:id', requireAuth, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentification requise" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de session invalide" });
      }
      
      const session = await storage.getWatchSession(id);
      if (!session) {
        return res.status(404).json({ message: "Session non trouvée" });
      }
      
      // Vérifier que l'utilisateur est le créateur de la session
      if (session.creatorId !== req.user.id) {
        return res.status(403).json({ message: "Seul le créateur peut terminer cette session" });
      }
      
      await storage.updateWatchSessionStatus(id, 'ended');
      res.status(204).end();
    } catch (error) {
      console.error('Erreur lors de la terminaison de la session:', error);
      res.status(500).json({ message: "Erreur lors de la terminaison de la session" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time watch sessions
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: '/ws'
  });
  
  // Map pour stocker les connexions WebSocket actives par session de visionnage
  // Key: ID de session, Value: Map des connexions par ID d'utilisateur
  const watchSessionConnections = new Map<number, Map<number, WebSocket>>();
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('Nouvelle connexion WebSocket établie');
    
    let sessionId: number | null = null;
    let userId: number | null = null;
    
    // Message handler
    ws.on('message', async (messageData) => {
      try {
        // Convertir le message en chaîne si ce n'est pas déjà le cas
        const messageStr = messageData.toString();
        const data = JSON.parse(messageStr);
        
        // Si c'est un message d'initialisation
        if (data.type === 'init') {
          sessionId = parseInt(data.sessionId);
          userId = parseInt(data.userId);
          
          if (isNaN(sessionId) || isNaN(userId)) {
            ws.send(JSON.stringify({
              type: 'error',
              message: 'sessionId et userId doivent être des nombres valides'
            }));
            return;
          }
          
          // Vérifier si la session existe
          const session = await storage.getWatchSession(sessionId);
          if (!session) {
            ws.send(JSON.stringify({
              type: 'error',
              message: 'Session non trouvée'
            }));
            return;
          }
          
          // Ajouter la connexion à la map
          if (!watchSessionConnections.has(sessionId)) {
            watchSessionConnections.set(sessionId, new Map());
          }
          
          const sessionConnections = watchSessionConnections.get(sessionId);
          if (sessionConnections) {
            sessionConnections.set(userId, ws);
          }
          
          // Confirmer l'initialisation
          ws.send(JSON.stringify({
            type: 'init_confirmed',
            sessionId,
            userId
          }));
          
          // Notifier les autres participants de la session qu'un nouveau participant est connecté
          if (sessionId !== null && userId !== null) {
            broadcastToSession(sessionId, userId, {
              type: 'user_joined',
              userId,
              timestamp: new Date().toISOString()
            });
          }
          
          console.log(`Utilisateur ${userId} a rejoint la session de visionnage ${sessionId}`);
        }
        
        // Si c'est une mise à jour de l'état du lecteur (pause, lecture, temps)
        else if (data.type === 'player_state' && sessionId !== null && userId !== null) {
          // Mettre à jour l'état dans la base de données
          if (data.action === 'pause' || data.action === 'play') {
            await storage.updateWatchSessionStatus(sessionId, data.action === 'pause' ? 'paused' : 'active');
          }
          
          if (typeof data.currentTime === 'number') {
            await storage.updateWatchSessionTime(sessionId, data.currentTime);
          }
          
          // Diffuser la mise à jour à tous les participants de la session
          broadcastToSession(sessionId, userId, {
            type: 'player_state',
            action: data.action,
            currentTime: data.currentTime,
            userId,
            timestamp: new Date().toISOString()
          });
          
          console.log(`Mise à jour de l'état du lecteur dans la session ${sessionId} par l'utilisateur ${userId}: ${data.action}, temps: ${data.currentTime}`);
        }
        
        // Si c'est un message de chat
        else if (data.type === 'chat' && sessionId !== null && userId !== null) {
          // Diffuser le message aux autres participants
          broadcastToSession(sessionId, userId, {
            type: 'chat',
            message: data.message,
            userId,
            timestamp: new Date().toISOString()
          });
          
          console.log(`Message de chat dans la session ${sessionId} de l'utilisateur ${userId}: ${data.message}`);
        }
      } catch (error) {
        console.error('Erreur lors du traitement du message WebSocket:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Erreur lors du traitement du message'
        }));
      }
    });
    
    // Connection close handler
    ws.on('close', () => {
      if (sessionId !== null && userId !== null) {
        // Supprimer la connexion de la map
        const sessionConnections = watchSessionConnections.get(sessionId);
        if (sessionConnections) {
          sessionConnections.delete(userId);
          
          // Si plus aucun participant dans la session, supprimer la session de la map
          if (sessionConnections.size === 0) {
            watchSessionConnections.delete(sessionId);
          } else {
            // Sinon, notifier les autres participants qu'un utilisateur s'est déconnecté
            broadcastToSession(sessionId, userId, {
              type: 'user_left',
              userId,
              timestamp: new Date().toISOString()
            });
          }
        }
        
        console.log(`Utilisateur ${userId} a quitté la session de visionnage ${sessionId}`);
      }
    });
  });
  
  // Fonction pour diffuser un message à tous les participants d'une session sauf à l'expéditeur
  function broadcastToSession(sessionId: number, senderId: number, message: any) {
    const sessionConnections = watchSessionConnections.get(sessionId);
    if (sessionConnections) {
      // Utiliser Array.from pour éviter les problèmes de compatibilité avec les itérateurs
      Array.from(sessionConnections.entries()).forEach(([userId, connection]) => {
        // Ne pas envoyer à l'expéditeur
        if (userId !== senderId && connection.readyState === WebSocket.OPEN) {
          connection.send(JSON.stringify(message));
        }
      });
    }
  }
  
  return httpServer;
}

// Middleware to require authentication
function requireAuth(req: any, res: any, next: any) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentification requise" });
  }
  next();
}

// Middleware to require admin privileges
function requireAdmin(req: any, res: any, next: any) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentification requise" });
  }
  if (!req.user.isAdmin) {
    return res.status(403).json({ message: "Privilèges administrateur requis" });
  }
  next();
}
