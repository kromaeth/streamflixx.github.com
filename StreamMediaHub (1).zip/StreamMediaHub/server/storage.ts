import { 
  users, type User, type InsertUser, 
  media, type Media, type InsertMedia,
  watchInvitations, type WatchInvitation, type InsertWatchInvitation,
  watchSessions, watchSessionParticipants
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { db } from "./db";
import { eq, and, asc, desc, sql, like, isNull, or, inArray } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByHandle(handle: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser & { email: string }): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser & { email: string; isAdmin: boolean }>): Promise<User>;
  deleteUser(id: number): Promise<void>;
  
  // Subscription operations
  updateUserStripeInfo(userId: number, stripeData: { customerId: string, subscriptionId: string }): Promise<User>;
  updateSubscriptionStatus(userId: number, status: string): Promise<User>;
  setTrialPeriod(userId: number, days: number): Promise<User>;
  setSubscriptionEnd(userId: number, date: Date): Promise<User>;
  
  // Media operations
  getMedia(id: number): Promise<Media | undefined>;
  getMediaByType(type: string): Promise<Media[]>;
  getFeaturedMedia(): Promise<Media | undefined>;
  getPopularMedia(): Promise<Media[]>;
  getNewSeries(): Promise<Media[]>;
  getAllMedia(): Promise<Media[]>;
  createMedia(media: InsertMedia): Promise<Media>;
  updateMedia(id: number, media: Partial<InsertMedia>): Promise<Media>;
  deleteMedia(id: number): Promise<void>;
  
  // Search operations
  searchMedia(query: string, filters?: {
    type?: string;
    genre?: string;
    year?: number;
    sortBy?: 'title' | 'year' | 'createdAt';
    sortOrder?: 'asc' | 'desc';
  }): Promise<Media[]>;
  
  // Watch Together operations
  createWatchInvitation(invitation: InsertWatchInvitation): Promise<WatchInvitation>;
  getWatchInvitation(id: number): Promise<WatchInvitation | undefined>;
  getWatchInvitationsByReceiver(receiverId: number): Promise<WatchInvitation[]>;
  getWatchInvitationsBySender(senderId: number): Promise<WatchInvitation[]>;
  updateWatchInvitationStatus(id: number, status: 'accepted' | 'declined' | 'expired'): Promise<WatchInvitation>;
  createWatchSession(data: { mediaId: number, creatorId: number, invitationId?: number }): Promise<any>;
  addParticipantToSession(sessionId: number, userId: number): Promise<any>;
  updateWatchSessionTime(sessionId: number, currentTime: number): Promise<any>;
  updateWatchSessionStatus(sessionId: number, status: 'active' | 'paused' | 'ended'): Promise<any>;
  getWatchSession(id: number): Promise<any>;
  getActiveWatchSessionsByUser(userId: number): Promise<any[]>;
  
  // Session store
  sessionStore: session.Store;
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private media: Map<number, Media>;
  private watchInvitations: Map<number, WatchInvitation>;
  private watchSessions: Map<number, any>;
  private watchSessionParticipants: Map<number, any>;
  public sessionStore: session.Store;
  private userId: number;
  private mediaId: number;
  private invitationId: number;
  private sessionId: number;
  private participantId: number;

  constructor() {
    this.users = new Map();
    this.media = new Map();
    this.watchInvitations = new Map();
    this.watchSessions = new Map();
    this.watchSessionParticipants = new Map();
    this.userId = 1;
    this.mediaId = 1;
    this.invitationId = 1;
    this.sessionId = 1;
    this.participantId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    
    // Create admin user by default
    this.createUser({
      username: "admin",
      handle: "admin",
      password: "admin",
      email: "admin@example.com",
      isAdmin: true
    });
    
    // Create some demo content
    this.initDemoContent();
  }
  
  async getUserByHandle(handle: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.handle === handle,
    );
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(userData: InsertUser & { email: string, isAdmin?: boolean }): Promise<User> {
    const id = this.userId++;
    const user: User = { 
      ...userData, 
      id, 
      isAdmin: userData.isAdmin ?? false,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      subscriptionStatus: "inactive",
      status: "active",
      trialEndsAt: null,
      subscriptionEndsAt: null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser & { email: string; isAdmin: boolean }>): Promise<User> {
    const existingUser = await this.getUser(id);
    if (!existingUser) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    const updatedUser = { ...existingUser, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<void> {
    if (!this.users.has(id)) {
      throw new Error(`User with ID ${id} not found`);
    }
    this.users.delete(id);
  }

  // Subscription operations
  async updateUserStripeInfo(userId: number, stripeData: { customerId: string, subscriptionId: string }): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const updatedUser = { 
      ...user, 
      stripeCustomerId: stripeData.customerId,
      stripeSubscriptionId: stripeData.subscriptionId
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateSubscriptionStatus(userId: number, status: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const updatedUser = { 
      ...user, 
      subscriptionStatus: status
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async setTrialPeriod(userId: number, days: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const trialEndDate = new Date();
    trialEndDate.setDate(trialEndDate.getDate() + days);
    
    const updatedUser = { 
      ...user, 
      trialEndsAt: trialEndDate
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async setSubscriptionEnd(userId: number, date: Date): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const updatedUser = { 
      ...user, 
      subscriptionEndsAt: date
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Media operations
  async getMedia(id: number): Promise<Media | undefined> {
    return this.media.get(id);
  }

  async getMediaByType(type: string): Promise<Media[]> {
    return Array.from(this.media.values()).filter(
      (item) => item.type === type,
    );
  }

  async getFeaturedMedia(): Promise<Media | undefined> {
    return Array.from(this.media.values()).find(
      (item) => item.featured,
    );
  }

  async getPopularMedia(): Promise<Media[]> {
    // For demo purposes, return first 6 items
    return Array.from(this.media.values()).slice(0, 6);
  }

  async getNewSeries(): Promise<Media[]> {
    // Return series sorted by createdAt (newest first)
    return Array.from(this.media.values())
      .filter(item => item.type === 'series')
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      })
      .slice(0, 6);
  }

  async getAllMedia(): Promise<Media[]> {
    return Array.from(this.media.values());
  }

  async createMedia(mediaData: InsertMedia): Promise<Media> {
    const id = this.mediaId++;
    const media: Media = { 
      ...mediaData, 
      id, 
      createdAt: new Date()
    };
    this.media.set(id, media);
    return media;
  }

  async updateMedia(id: number, mediaData: Partial<InsertMedia>): Promise<Media> {
    const existingMedia = await this.getMedia(id);
    if (!existingMedia) {
      throw new Error(`Media with ID ${id} not found`);
    }
    
    const updatedMedia = { ...existingMedia, ...mediaData };
    this.media.set(id, updatedMedia);
    return updatedMedia;
  }

  async deleteMedia(id: number): Promise<void> {
    if (!this.media.has(id)) {
      throw new Error(`Media with ID ${id} not found`);
    }
    this.media.delete(id);
  }
  
  // Search operations
  async searchMedia(query: string, filters?: {
    type?: string;
    genre?: string;
    year?: number;
    sortBy?: 'title' | 'year' | 'createdAt';
    sortOrder?: 'asc' | 'desc';
  }): Promise<Media[]> {
    const lowerCaseQuery = query.toLowerCase();
    
    let results = Array.from(this.media.values()).filter(item => {
      // Recherche textuelle dans le titre et la description
      const matchesQuery = query.length === 0 || 
        item.title.toLowerCase().includes(lowerCaseQuery) || 
        item.description.toLowerCase().includes(lowerCaseQuery);
        
      // Filtrage par type
      const matchesType = !filters?.type || item.type === filters.type;
      
      // Filtrage par genre
      const matchesGenre = !filters?.genre || item.genre.toLowerCase() === filters.genre.toLowerCase();
      
      // Filtrage par année
      const matchesYear = !filters?.year || item.year === filters.year;
      
      return matchesQuery && matchesType && matchesGenre && matchesYear;
    });
    
    // Tri des résultats
    if (filters?.sortBy) {
      results.sort((a, b) => {
        const isAsc = filters.sortOrder !== 'desc';
        
        switch (filters.sortBy) {
          case 'title':
            return isAsc 
              ? a.title.localeCompare(b.title)
              : b.title.localeCompare(a.title);
              
          case 'year':
            const yearA = a.year || 0;
            const yearB = b.year || 0;
            return isAsc ? yearA - yearB : yearB - yearA;
            
          case 'createdAt':
            const dateA = a.createdAt?.getTime() || 0;
            const dateB = b.createdAt?.getTime() || 0;
            return isAsc ? dateA - dateB : dateB - dateA;
            
          default:
            return 0;
        }
      });
    }
    
    return results;
  }

  // Watch Together operations
  async createWatchInvitation(invitationData: InsertWatchInvitation): Promise<WatchInvitation> {
    const id = this.invitationId++;
    const oneHourLater = new Date();
    oneHourLater.setHours(oneHourLater.getHours() + 1);
    
    const invitation: WatchInvitation = {
      ...invitationData,
      id,
      status: 'pending',
      createdAt: new Date(),
      expiresAt: invitationData.expiresAt || oneHourLater
    };
    
    this.watchInvitations.set(id, invitation);
    return invitation;
  }
  
  async getWatchInvitation(id: number): Promise<WatchInvitation | undefined> {
    return this.watchInvitations.get(id);
  }
  
  async getWatchInvitationsByReceiver(receiverId: number): Promise<WatchInvitation[]> {
    return Array.from(this.watchInvitations.values()).filter(
      invite => invite.receiverId === receiverId
    );
  }
  
  async getWatchInvitationsBySender(senderId: number): Promise<WatchInvitation[]> {
    return Array.from(this.watchInvitations.values()).filter(
      invite => invite.senderId === senderId
    );
  }
  
  async updateWatchInvitationStatus(id: number, status: 'accepted' | 'declined' | 'expired'): Promise<WatchInvitation> {
    const invitation = await this.getWatchInvitation(id);
    if (!invitation) {
      throw new Error(`Invitation with ID ${id} not found`);
    }
    
    const updatedInvitation = {
      ...invitation,
      status
    };
    
    this.watchInvitations.set(id, updatedInvitation);
    return updatedInvitation;
  }
  
  async createWatchSession(data: { mediaId: number, creatorId: number, invitationId?: number }): Promise<any> {
    const id = this.sessionId++;
    
    const session = {
      id,
      mediaId: data.mediaId,
      creatorId: data.creatorId,
      invitationId: data.invitationId,
      currentTime: 0,
      status: 'active',
      createdAt: new Date(),
      endedAt: null
    };
    
    this.watchSessions.set(id, session);
    
    // Ajouter automatiquement le créateur comme participant
    await this.addParticipantToSession(id, data.creatorId);
    
    return session;
  }
  
  async addParticipantToSession(sessionId: number, userId: number): Promise<any> {
    const session = this.watchSessions.get(sessionId);
    if (!session) {
      throw new Error(`Watch session with ID ${sessionId} not found`);
    }
    
    const participantId = this.participantId++;
    const participant = {
      id: participantId,
      sessionId,
      userId,
      joinedAt: new Date(),
      leftAt: null,
      status: 'active'
    };
    
    this.watchSessionParticipants.set(participantId, participant);
    return participant;
  }
  
  async updateWatchSessionTime(sessionId: number, currentTime: number): Promise<any> {
    const session = this.watchSessions.get(sessionId);
    if (!session) {
      throw new Error(`Watch session with ID ${sessionId} not found`);
    }
    
    const updatedSession = {
      ...session,
      currentTime
    };
    
    this.watchSessions.set(sessionId, updatedSession);
    return updatedSession;
  }
  
  async updateWatchSessionStatus(sessionId: number, status: 'active' | 'paused' | 'ended'): Promise<any> {
    const session = this.watchSessions.get(sessionId);
    if (!session) {
      throw new Error(`Watch session with ID ${sessionId} not found`);
    }
    
    const updatedSession = {
      ...session,
      status,
      endedAt: status === 'ended' ? new Date() : session.endedAt
    };
    
    this.watchSessions.set(sessionId, updatedSession);
    
    // Mettre à jour les participants si la session est terminée
    if (status === 'ended') {
      const participants = Array.from(this.watchSessionParticipants.values())
        .filter(p => p.sessionId === sessionId && p.status === 'active');
      
      for (const participant of participants) {
        const updatedParticipant = {
          ...participant,
          status: 'inactive',
          leftAt: new Date()
        };
        this.watchSessionParticipants.set(participant.id, updatedParticipant);
      }
    }
    
    return updatedSession;
  }
  
  async getWatchSession(id: number): Promise<any> {
    return this.watchSessions.get(id);
  }
  
  async getActiveWatchSessionsByUser(userId: number): Promise<any[]> {
    // Récupérer les IDs de session où l'utilisateur est un participant actif
    const participantSessions = Array.from(this.watchSessionParticipants.values())
      .filter(p => p.userId === userId && p.status === 'active')
      .map(p => p.sessionId);
    
    // Récupérer les sessions actives correspondantes
    return Array.from(this.watchSessions.values())
      .filter(session => 
        participantSessions.includes(session.id) && 
        (session.status === 'active' || session.status === 'paused')
      );
  }

  // Initialize demo content
  private async initDemoContent() {
    // Featured content
    await this.createMedia({
      title: "Découvrez un monde de divertissement",
      description: "Films, séries et chaînes TV en streaming illimité",
      type: "movie",
      genre: "Action",
      year: 2023,
      thumbnailUrl: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      featured: true
    });

    // Movies
    await this.createMedia({
      title: "Action Explosive",
      description: "Un film d'action plein de rebondissements",
      type: "movie",
      genre: "Action",
      year: 2023,
      thumbnailUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    });

    await this.createMedia({
      title: "Thriller Psychologique",
      description: "Un thriller qui vous tiendra en haleine",
      type: "movie",
      genre: "Thriller",
      year: 2022,
      thumbnailUrl: "https://images.unsplash.com/photo-1559583109-3e7968736000?ixlib=rb-4.0.3&auto=format&fit=crop&w=687&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
    });

    // Series
    await this.createMedia({
      title: "La Dynastie",
      description: "Une saga familiale épique",
      type: "series",
      genre: "Drame",
      year: 2023,
      thumbnailUrl: "https://images.unsplash.com/photo-1616530940355-351fabd9524b?ixlib=rb-4.0.3&auto=format&fit=crop&w=735&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      seasons: 3
    });

    await this.createMedia({
      title: "Créatures Nocturnes",
      description: "Une série de science-fiction sur des créatures mystérieuses",
      type: "series",
      genre: "Science-Fiction",
      year: 2023,
      thumbnailUrl: "https://images.unsplash.com/photo-1624138784614-87fd1b6528f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1633&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      seasons: 1
    });

    await this.createMedia({
      title: "Empire Déchu",
      description: "Une série historique sur la chute d'un empire",
      type: "series",
      genre: "Historique",
      year: 2022,
      thumbnailUrl: "https://images.unsplash.com/photo-1512070679279-8988d32161be?ixlib=rb-4.0.3&auto=format&fit=crop&w=738&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
      seasons: 2
    });

    // TV Channels
    await this.createMedia({
      title: "Info24",
      description: "Chaîne d'information en continu",
      type: "channel",
      genre: "Actualités",
      thumbnailUrl: "https://via.placeholder.com/200x100.png?text=Info24",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"
    });

    await this.createMedia({
      title: "SportLive",
      description: "La chaîne des passionnés de sport",
      type: "channel",
      genre: "Sport",
      thumbnailUrl: "https://via.placeholder.com/200x100.png?text=SportLive",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
    });

    await this.createMedia({
      title: "CinéClassic",
      description: "Le meilleur du cinéma classique",
      type: "channel",
      genre: "Cinéma",
      thumbnailUrl: "https://via.placeholder.com/200x100.png?text=CinéClassic",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4"
    });
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
    
    // Initialisation de la base de données
    this.initDatabase();
  }
  
  // Initialisation de la base de données
  private async initDatabase() {
    try {
      // Vérifier si l'utilisateur admin existe déjà
      const adminUser = await this.getUserByUsername("admin");
      
      if (!adminUser) {
        console.log("Création de l'utilisateur admin...");
        await this.createUser({
          username: "admin",
          handle: "admin",
          password: "admin",
          email: "admin@example.com",
          isAdmin: true
        });
      }
      
      // Vérifier si des médias existent
      const allMedia = await this.getAllMedia();
      if (allMedia.length === 0) {
        console.log("Initialisation du contenu de démonstration...");
        await this.initDemoContent();
      }
    } catch (error) {
      console.error("Erreur lors de l'initialisation de la base de données:", error);
    }
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByHandle(handle: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.handle, handle));
    return user;
  }

  async getUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async createUser(userData: InsertUser & { email: string, isAdmin?: boolean }): Promise<User> {
    const [user] = await db.insert(users).values({
      username: userData.username,
      handle: userData.handle,
      password: userData.password,
      email: userData.email,
      isAdmin: userData.isAdmin || false,
      status: 'active',
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      subscriptionStatus: "inactive",
      trialEndsAt: null,
      subscriptionEndsAt: null
    }).returning();
    
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser & { email: string; isAdmin: boolean }>): Promise<User> {
    const [updatedUser] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    return updatedUser;
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  // Subscription operations
  async updateUserStripeInfo(userId: number, stripeData: { customerId: string, subscriptionId: string }): Promise<User> {
    const [updatedUser] = await db.update(users)
      .set({
        stripeCustomerId: stripeData.customerId,
        stripeSubscriptionId: stripeData.subscriptionId
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return updatedUser;
  }
  
  async updateSubscriptionStatus(userId: number, status: string): Promise<User> {
    const [updatedUser] = await db.update(users)
      .set({
        subscriptionStatus: status
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return updatedUser;
  }
  
  async setTrialPeriod(userId: number, days: number): Promise<User> {
    const trialEndDate = new Date();
    trialEndDate.setDate(trialEndDate.getDate() + days);
    
    const [updatedUser] = await db.update(users)
      .set({
        trialEndsAt: trialEndDate
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return updatedUser;
  }
  
  async setSubscriptionEnd(userId: number, date: Date): Promise<User> {
    const [updatedUser] = await db.update(users)
      .set({
        subscriptionEndsAt: date
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return updatedUser;
  }

  // Media operations
  async getMedia(id: number): Promise<Media | undefined> {
    const [mediaItem] = await db.select().from(media).where(eq(media.id, id));
    return mediaItem;
  }

  async getMediaByType(type: string): Promise<Media[]> {
    return db.select().from(media).where(eq(media.type, type));
  }

  async getFeaturedMedia(): Promise<Media | undefined> {
    const [featuredMedia] = await db.select().from(media).where(eq(media.featured, true));
    return featuredMedia;
  }

  async getPopularMedia(): Promise<Media[]> {
    // Pour simplifier, nous retournons les 6 premiers éléments
    // Dans une implémentation réelle, nous pourrions utiliser un compteur de vues ou de likes
    return db.select().from(media).limit(6);
  }

  async getNewSeries(): Promise<Media[]> {
    return db.select()
      .from(media)
      .where(eq(media.type, 'series'))
      .orderBy(desc(media.createdAt))
      .limit(6);
  }

  async getAllMedia(): Promise<Media[]> {
    return db.select().from(media);
  }

  async createMedia(mediaData: InsertMedia): Promise<Media> {
    const [newMedia] = await db.insert(media).values({
      ...mediaData,
      createdAt: new Date()
    }).returning();
    
    return newMedia;
  }

  async updateMedia(id: number, mediaData: Partial<InsertMedia>): Promise<Media> {
    const [updatedMedia] = await db.update(media)
      .set(mediaData)
      .where(eq(media.id, id))
      .returning();
    
    if (!updatedMedia) {
      throw new Error(`Media with ID ${id} not found`);
    }
    
    return updatedMedia;
  }

  async deleteMedia(id: number): Promise<void> {
    await db.delete(media).where(eq(media.id, id));
  }
  
  // Search operations
  async searchMedia(query: string, filters?: {
    type?: string;
    genre?: string;
    year?: number;
    sortBy?: 'title' | 'year' | 'createdAt';
    sortOrder?: 'asc' | 'desc';
  }): Promise<Media[]> {
    // Construire la requête de base
    let dbQuery = db.select().from(media);
    
    // Ajouter la recherche textuelle si une requête est fournie
    if (query && query.length > 0) {
      const searchPattern = `%${query}%`;
      dbQuery = dbQuery.where(
        or(
          like(media.title, searchPattern),
          like(media.description, searchPattern)
        )
      );
    }
    
    // Ajouter les filtres
    if (filters?.type) {
      dbQuery = dbQuery.where(eq(media.type, filters.type));
    }
    
    if (filters?.genre) {
      dbQuery = dbQuery.where(like(media.genre, `%${filters.genre}%`));
    }
    
    if (filters?.year) {
      dbQuery = dbQuery.where(eq(media.year, filters.year));
    }
    
    // Ajouter le tri
    if (filters?.sortBy) {
      const sortDirection = filters.sortOrder === 'desc' ? desc : asc;
      
      switch (filters.sortBy) {
        case 'title':
          dbQuery = dbQuery.orderBy(sortDirection(media.title));
          break;
        case 'year':
          dbQuery = dbQuery.orderBy(sortDirection(media.year));
          break;
        case 'createdAt':
          dbQuery = dbQuery.orderBy(sortDirection(media.createdAt));
          break;
      }
    } else {
      // Tri par défaut
      dbQuery = dbQuery.orderBy(asc(media.title));
    }
    
    return dbQuery;
  }

  // Watch Together operations
  async createWatchInvitation(invitationData: InsertWatchInvitation): Promise<WatchInvitation> {
    const oneHourLater = new Date();
    oneHourLater.setHours(oneHourLater.getHours() + 1);
    
    const [invitation] = await db.insert(watchInvitations).values({
      senderId: invitationData.senderId,
      receiverId: invitationData.receiverId,
      mediaId: invitationData.mediaId,
      message: invitationData.message || null,
      status: 'pending',
      createdAt: new Date(),
      expiresAt: invitationData.expiresAt || oneHourLater
    }).returning();
    
    return invitation;
  }
  
  async getWatchInvitation(id: number): Promise<WatchInvitation | undefined> {
    const [invitation] = await db.select().from(watchInvitations).where(eq(watchInvitations.id, id));
    return invitation;
  }
  
  async getWatchInvitationsByReceiver(receiverId: number): Promise<WatchInvitation[]> {
    return db.select()
      .from(watchInvitations)
      .where(eq(watchInvitations.receiverId, receiverId));
  }
  
  async getWatchInvitationsBySender(senderId: number): Promise<WatchInvitation[]> {
    return db.select()
      .from(watchInvitations)
      .where(eq(watchInvitations.senderId, senderId));
  }
  
  async updateWatchInvitationStatus(id: number, status: 'accepted' | 'declined' | 'expired'): Promise<WatchInvitation> {
    const [updatedInvitation] = await db.update(watchInvitations)
      .set({ status })
      .where(eq(watchInvitations.id, id))
      .returning();
    
    if (!updatedInvitation) {
      throw new Error(`Invitation with ID ${id} not found`);
    }
    
    return updatedInvitation;
  }
  
  async createWatchSession(data: { mediaId: number, creatorId: number, invitationId?: number }): Promise<any> {
    const [session] = await db.insert(watchSessions).values({
      mediaId: data.mediaId,
      creatorId: data.creatorId,
      invitationId: data.invitationId || null,
      currentTime: 0,
      status: 'active',
      createdAt: new Date(),
      endedAt: null
    }).returning();
    
    // Ajouter automatiquement le créateur comme participant
    await this.addParticipantToSession(session.id, data.creatorId);
    
    return session;
  }
  
  async addParticipantToSession(sessionId: number, userId: number): Promise<any> {
    const [participant] = await db.insert(watchSessionParticipants).values({
      sessionId,
      userId,
      joinedAt: new Date(),
      leftAt: null,
      status: 'active'
    }).returning();
    
    return participant;
  }
  
  async updateWatchSessionTime(sessionId: number, currentTime: number): Promise<any> {
    const [updatedSession] = await db.update(watchSessions)
      .set({ currentTime })
      .where(eq(watchSessions.id, sessionId))
      .returning();
    
    if (!updatedSession) {
      throw new Error(`Watch session with ID ${sessionId} not found`);
    }
    
    return updatedSession;
  }
  
  async updateWatchSessionStatus(sessionId: number, status: 'active' | 'paused' | 'ended'): Promise<any> {
    const now = new Date();
    const [updatedSession] = await db.update(watchSessions)
      .set({ 
        status,
        endedAt: status === 'ended' ? now : null
      })
      .where(eq(watchSessions.id, sessionId))
      .returning();
    
    if (!updatedSession) {
      throw new Error(`Watch session with ID ${sessionId} not found`);
    }
    
    // Mettre à jour les participants si la session est terminée
    if (status === 'ended') {
      await db.update(watchSessionParticipants)
        .set({ 
          status: 'inactive',
          leftAt: now
        })
        .where(
          and(
            eq(watchSessionParticipants.sessionId, sessionId),
            eq(watchSessionParticipants.status, 'active')
          )
        );
    }
    
    return updatedSession;
  }
  
  async getWatchSession(id: number): Promise<any> {
    const [session] = await db.select()
      .from(watchSessions)
      .where(eq(watchSessions.id, id));
      
    return session;
  }
  
  async getActiveWatchSessionsByUser(userId: number): Promise<any[]> {
    // Récupérer les sessions actives où l'utilisateur est un participant
    const participantSessions = await db.select({
      sessionId: watchSessionParticipants.sessionId
    })
    .from(watchSessionParticipants)
    .where(
      and(
        eq(watchSessionParticipants.userId, userId),
        eq(watchSessionParticipants.status, 'active')
      )
    );
    
    if (participantSessions.length === 0) {
      return [];
    }
    
    // Récupérer les détails des sessions
    return db.select()
      .from(watchSessions)
      .where(
        and(
          inArray(watchSessions.id, participantSessions.map(p => p.sessionId)),
          or(
            eq(watchSessions.status, 'active'),
            eq(watchSessions.status, 'paused')
          )
        )
      );
  }
  
  // Initialisation du contenu de démonstration
  private async initDemoContent() {
    // Films
    await this.createMedia({
      title: "Découvrez un monde de divertissement",
      description: "Bienvenue sur notre plateforme de streaming",
      type: "movie",
      genre: "Aventure",
      year: 2023,
      thumbnailUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      featured: true
    });

    await this.createMedia({
      title: "La Quête Éternelle",
      description: "Un film d'aventure épique",
      type: "movie",
      genre: "Aventure",
      year: 2022,
      thumbnailUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1025&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    });

    await this.createMedia({
      title: "Horizons Lointains",
      description: "Un voyage au bout du monde",
      type: "movie",
      genre: "Documentaire",
      year: 2021,
      thumbnailUrl: "https://images.unsplash.com/photo-1516233758813-a38d024919c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=736&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
    });

    // Séries
    await this.createMedia({
      title: "La Dynastie",
      description: "Une saga familiale pleine de rebondissements",
      type: "series",
      genre: "Drame",
      year: 2023,
      thumbnailUrl: "https://images.unsplash.com/photo-1560169897-fc0cdbdfa4d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=772&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      seasons: 3
    });

    await this.createMedia({
      title: "Nouveau Monde",
      description: "Une série de science-fiction captivante",
      type: "series",
      genre: "Science-Fiction",
      year: 2023,
      thumbnailUrl: "https://images.unsplash.com/photo-1624138784614-87fd1b6528f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1633&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      seasons: 1
    });

    await this.createMedia({
      title: "Empire Déchu",
      description: "Une série historique sur la chute d'un empire",
      type: "series",
      genre: "Historique",
      year: 2022,
      thumbnailUrl: "https://images.unsplash.com/photo-1512070679279-8988d32161be?ixlib=rb-4.0.3&auto=format&fit=crop&w=738&q=80",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
      seasons: 2
    });

    // TV Channels
    await this.createMedia({
      title: "Info24",
      description: "Chaîne d'information en continu",
      type: "channel",
      genre: "Actualités",
      thumbnailUrl: "https://via.placeholder.com/200x100.png?text=Info24",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"
    });

    await this.createMedia({
      title: "SportLive",
      description: "La chaîne des passionnés de sport",
      type: "channel",
      genre: "Sport",
      thumbnailUrl: "https://via.placeholder.com/200x100.png?text=SportLive",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
    });

    await this.createMedia({
      title: "CinéClassic",
      description: "Le meilleur du cinéma classique",
      type: "channel",
      genre: "Cinéma",
      thumbnailUrl: "https://via.placeholder.com/200x100.png?text=CinéClassic",
      contentUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4"
    });
  }
}

// On utilise maintenant la version base de données au lieu de la version mémoire
export const storage = new DatabaseStorage();
